import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geolocator/geolocator.dart';

class CreateCrashService {
  static void createReport({
    required String url,
    required String code,
    required String reason,
    required String body,
    required String catchError,
    String stackTrace = "",
  }) async {
    String lat = "";
    String long = "";
    LocationPermission p = await Geolocator.requestPermission();
    if (p == LocationPermission.denied) {
      await Geolocator.requestPermission();

      if ((await Geolocator.requestPermission()) ==
          LocationPermission.deniedForever) {
        lat = "0.0";
        long = "0.0";
      } else if ((await Geolocator.requestPermission()) ==
              LocationPermission.always ||
          (await Geolocator.requestPermission()) ==
              LocationPermission.whileInUse) {
        Position position = await Geolocator.getCurrentPosition(
            desiredAccuracy: LocationAccuracy.high);
        lat = "${position.latitude}";
        long = "${position.longitude}";
      }
    } else if (p == LocationPermission.deniedForever) {
      lat = "0.0";
      long = "0.0";
    } else if (p == LocationPermission.always ||
        p == LocationPermission.whileInUse) {
      Position position = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high);
      lat = "${position.latitude}";
      long = "${position.longitude}";
    }

    await FirebaseFirestore.instance
        .collection("Error Report")
        .doc(
            "${DateTime.now().toUtc()} API: ${url.split("/").last.split("?").first}")
        .set(
      {
        "Param1 API": url,
        "Param2 Status code": code,
        "Param3 Reason phrase": reason,
        "Param4 Response body": body,
        "Catch error": catchError,
        "Stack trace": stackTrace,
        "LatLong": "$lat, $long",
      },
    );

    // FirebaseCrashlytics.instance.recordError(
    //   "$url\n$code\n$reason\n$body\n$catchError",
    //   StackTrace.current,
    //   information: {
    //     'Api error',
    //   },
    //   fatal: true,
    // );
  }
}
