import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../Models/book_models.dart';
import '../Models/user_details_class.dart';
import '../utils/api.dart';
import '../utils/colors.dart';
import 'package:http/http.dart' as http;

enum BookListFilterENUM { upcoming, past, today }

class BookController extends GetxController {
  /// on tap tab pr 2 var index call thai che

  int currentTabIndex = 0;
  bool isLoading = true;
  bool isListLoading = true;
  int currentPage = 1;
  List<OrderData>? orderData = [];
  BookListModel? bookListModel;
  bool isFirstLoading = false;
  bool isSecondLoading = true;
  bool isThirdLoading = true;

  BookListFilterENUM bookListFilterENUM = BookListFilterENUM.upcoming;
  int selectedType = 2;
  int selectedStatus = 1;

  ScrollController scrollController = ScrollController();

  UserDetailsClass userDetails = UserDetailsClass();

  @override
  void onInit() {
    super.onInit();
    getUserDetails();
    allListFetch();
    scrollController.addListener(() {
      if (scrollController.position.maxScrollExtent ==
          scrollController.position.pixels) {
        if (isListLoading) {
          allListFetch();
        }
      }
    });
  }

  getUserDetails() async {
    UserDetailsClass data = await UserDetailsClass().getUserDetails();
    userDetails = data;
  }

  /// type => 1 (past),2(upcoming),3(today)
  changeFilter(value) {
    if (value == BookListFilterENUM.upcoming) {
      selectedType = 2;
      reloadAllList();
    } else if (value == BookListFilterENUM.past) {
      selectedType = 1;
      reloadAllList();
    } else if (value == BookListFilterENUM.today) {
      selectedType = 3;
      reloadAllList();
    }
    bookListFilterENUM = value;
    update();
  }

  /// currentTabIndex = 0 -> All ,1 -> Pending 2 -> Rejected
  changeTabIndex(int value) {
    isLoading = true;
    update();
    currentTabIndex = value;
    if (value == 0) {
      selectedStatus = 1;
      isFirstLoading = false;
      isSecondLoading = true;
      isThirdLoading = true;
      reloadAllList();
    } else if (value == 1) {
      selectedStatus = 2;
      isFirstLoading = true;
      isSecondLoading = false;
      isThirdLoading = true;
      reloadAllList();
    } else if (value == 2) {
      selectedStatus = 4;
      isFirstLoading = true;
      isSecondLoading = true;
      isThirdLoading = false;
      reloadAllList();
    }
  }

  /// type => 1 (past),2(upcoming),3(today)
  /// status = > 1(all),2(pending),3(complete),4(reject)

  reloadAllList() {
    currentPage = 1;
    isLoading = true;
    isListLoading = true;
    orderData!.clear();
    update();
    allListFetch();
  }

  allListFetch() async {
    try {
      UserDetailsClass data = await UserDetailsClass().getUserDetails();
      userDetails = data;
      final response = await http.get(Uri.parse(SERVER_ADDRESS +
          getBookList +
          '?user_id=${userDetails.userId}&status=$selectedStatus&page=$currentPage'));
      // final response = await http.get(Uri.parse(SERVER_ADDRESS + getBookList + '?user_id=${userDetails.userId}&type=$selectedType&status=$selectedStatus&page=$currentPage'));
      if (response.statusCode == 200) {
        final jsonResponse = jsonDecode(response.body);
        if (jsonResponse['status'] == 1) {
          bookListModel = BookListModel.fromJson(jsonResponse);
          orderData!.addAll(bookListModel!.data!.data!);
          if (bookListModel!.data!.nextPageUrl == null) {
            isListLoading = false;
          } else {
            currentPage++;
          }
          isLoading = false;
          update();
        } else {
          Get.snackbar(
            "Error",
            "data not found",
            snackPosition: SnackPosition.BOTTOM,
            backgroundColor: redColor,
          );
          isLoading = false;
          isListLoading = false;
          update();
        }
      }
    } catch (e) {
      Get.snackbar(
        "Failed to load Data",
        "Something went wrong. Try again,",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: redColor,
      );
      isLoading = false;
      isListLoading = false;
      update();
    }
  }
}
