import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:leboratory/Models/address_list_model.dart';
import 'package:leboratory/Screens/Custome_Widgets/page_widget.dart';
import '../Models/cart_list_model.dart';
import '../Models/user_details_class.dart';
import '../Screens/Custome_Widgets/custome_widget.dart';
import '../Screens/View/BookScreens/book_details_screen.dart';
import '../Screens/View/InAppWebiewSubscribtionScreen.dart';
import '../utils/AllText.dart';
import '../utils/api.dart';
import '../utils/colors.dart';
import '../utils/strings.dart';

class CheckoutController extends GetxController {
  bool isLoading = false;
  bool isBooking = false;
  bool isAddressLoading = true;
  bool isAddressNull = true;
  DateTime selectedDate = DateTime.now();
  TimeOfDay selectedTime = TimeOfDay.now();
  TextEditingController selectDateController = TextEditingController();
  TextEditingController selectTimeController = TextEditingController();
  UserDetailsClass userDetails = UserDetailsClass();
  AddressListModel? addressListModel;
  Datum selectedAddress = Datum();

  onInit() {
    selectDateController.text =
        '${selectedDate.day}/${selectedDate.month}/${selectedDate.year}';
    selectTimeController.text =
        '${selectedTime.hour.toString().padLeft(2, "0")}:${selectedTime.minute.toString().padLeft(2, "0")}';
    super.onInit();
    init();
  }

  init() async {
    await getUserDetails();
    fetchAddress();
  }

  selectTime(BuildContext context) async {
    final TimeOfDay? timeOfDay = await showTimePicker(
        context: context,
        initialTime: selectedTime,
        initialEntryMode: TimePickerEntryMode.dial,
        builder: (context, child) {
          return MediaQuery(
              data:
                  MediaQuery.of(context).copyWith(alwaysUse24HourFormat: false),
              child: Theme(
                data: Theme.of(context).copyWith(
                  colorScheme: const ColorScheme.light(
                    primary: themeColor,
                  ),
                  textButtonTheme: TextButtonThemeData(
                    style: TextButton.styleFrom(
                      foregroundColor: themeColor, // button text color
                    ),
                  ),
                ),
                child: child!,
              ));
        });
    if (timeOfDay != null && timeOfDay != selectedTime) {
      selectedTime = timeOfDay;
      selectTimeController.text =
          '${selectedTime.hour.toString().padLeft(2, "0")}:${selectedTime.minute.toString().padLeft(2, "0")}';
    }
  }

  static List<String> values = <String>[
    'Braintree',
    'Paystack',
    'Cash On Delivery',
    'Stripe',
  ];

  setSelectedRadio(val) {
    selectedValue = val;
    update();
  }

  String selectedValue = values.first;

  Future<void> selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime.now(),
      lastDate: DateTime(2101),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: ColorScheme.light(
              primary: themeColor,
            ),
            textButtonTheme: TextButtonThemeData(
              style: TextButton.styleFrom(
                foregroundColor: themeColor, // button text color
              ),
            ),
          ),
          child: child!,
        );
      },
    );

    if (picked != null && picked != selectedDate) {
      selectedDate = picked;
      selectDateController.text =
          '${selectedDate.day}/${selectedDate.month}/${selectedDate.year}';
    }
    update();
  }

  getUserDetails() async {
    UserDetailsClass data = await UserDetailsClass().getUserDetails();
    userDetails = data;
  }

  /// Fetch Address

  Future fetchAddress() async {
    changeSelectedAddress(Datum());
    isAddressLoading = true;
    update();
    try {
      final response = await http.get(
          Uri.parse(SERVER_ADDRESS + "$getAddress?id=${userDetails.userId}"));
      // final response = await http.get(Uri.parse(SERVER_ADDRESS + "$getAddress?id=${3}"));
      if (response.statusCode == 200) {
        final jsonResponse = jsonDecode(response.body);
        if (jsonResponse['status'] == 1) {
          addressListModel = AddressListModel.fromJson(jsonResponse);
          for (var data in addressListModel!.data!) {
            if (data.isDefault == 1) {
              changeSelectedAddress(data);
              // selectedAddress = data;
            }
          }
          if (selectedAddress.id == null) {
            changeSelectedAddress(addressListModel!.data![0]);
            // selectedAddress = addressListModel!.data![0];
          }

          isAddressLoading = false;
          isAddressNull = false;
          update();
        } else if (jsonResponse['status'] == 0) {
          isAddressLoading = false;
          isAddressNull = true;
          update();
          // Get.snackbar(
          //   "Not Found",
          //   "${jsonResponse['msg']}",
          //   snackPosition: SnackPosition.BOTTOM,
          //   backgroundColor: redColor,
          // );
        } else {
          isAddressNull = true;
          isAddressLoading = false;
          Get.snackbar(
            "Error",
            "data not found",
            snackPosition: SnackPosition.BOTTOM,
            backgroundColor: redColor,
          );
          update();
        }
      }
    } catch (e) {
      Get.snackbar(
        "Failed to load Data",
        "Something went wrong. Try again,",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: redColor,
      );
      isAddressNull = true;
      isAddressLoading = false;
      update();
    }
  }

  changeSelectedAddress(data) {
    selectedAddress = data;
    update();
  }

  bookNow({
    required subTotal,
    required txt,
    required total,
    required Data data,
    String id = '',
  }) async {
    if (selectedAddress.id == null) {
      Get.snackbar(
        "Address is required",
        "First select address and then add to cart",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: redColor,
      );
      return;
    }
    // else if(selectedValue == "Braintree"  || selectedValue == "Paystack"){
    //
    //   String paymentLink = "";
    //   if(selectedValue == "Braintree"){
    //     // paymentLink = 'https://customise.freaktemplate.com/foodieclone/braintree-payment?payment_method=6&id=${widget.order_id}&user_address_id=${addressClass!=null?addressClass.data.innerData[0].id.toString() : ""}';
    //   }
    //   else{
    //     // paymentLink = 'https://customise.freaktemplate.com/foodieclone/braintree-payment?payment_method=6&id=${widget.order_id}&user_address_id=${addressClass!=null?addressClass.data.innerData[0].id.toString() : ""}';
    //   }
    //   var result = await Get.to(InAppWebViewScreen(
    //     url: paymentLink,
    //   ));
    //
    //   if (result == 'success') {
    //     Get.dialog(
    //       Center(
    //         child: Container(
    //           height: 280,
    //           margin: EdgeInsets.symmetric(horizontal: 20),
    //           padding: EdgeInsets.symmetric(vertical: 10),
    //           decoration: BoxDecoration(
    //             borderRadius: BorderRadius.circular(10),
    //             color: darkBlue,
    //           ),
    //           child: Column(
    //             children: [
    //               boldText(text: "", color: whiteColor, size: 26),
    //               SizedBox(height: 20,),
    //               regularText(
    //                   text: ORDER_SUCCESS_MSG2[LANGUAGE_TYPE],
    //                   color: subTextColor,
    //                   size: 16,
    //                   alignment: TextAlign.center
    //               ),
    //               SizedBox(height: 15,),
    //
    //               Padding(
    //                 padding: EdgeInsets.symmetric(horizontal: 20),
    //                 child: customeElevatedButton(
    //                     width * 0.9,
    //                     TRACK_ORDER[LANGUAGE_TYPE],
    //                     callback: () {
    //                       Get.to(()=>BookDetailsScreen(orderId: "".toString(),));
    //                     }),
    //               ),
    //               SizedBox(height: 15,),
    //               Padding(
    //                 padding: EdgeInsets.symmetric(horizontal: 20),
    //                 child: customeElevatedButtonOutLine(
    //                   width * 0.9,
    //                   BACK_TO_SHOP[LANGUAGE_TYPE],
    //                   color: themeSecondaryColor,
    //                   callback: () {
    //                     Get.offAll(()=>PagesWidget(selectedIndex: 0,));
    //                   },
    //                 ),
    //               ),
    //             ],
    //           ),
    //         ),
    //       ),
    //     );
    //   } else if (result == 'fail') {
    //
    //   }
    // }
    else {
      isBooking = true;
      update();
      String testJson = "{\"Testdata\":[";
      for (int i = 0; i < data.cart!.length; i++) {
        testJson =
            testJson + "{\"member_id\":${data.cart![i].memberId},\"items\":[";
        for (int j = 0; j < data.cart![i].testdata!.length; j++) {
          var data2 = data.cart![i].testdata![j];
          testJson = testJson +
              "{\"id\":${data2.typeId},\"type\":${data2.type},\"parameter\":${data2.parameter}}${data.cart![i].testdata!.length == j + 1 ? '' : ','}";
        }
        testJson = testJson + "]}${data.cart!.length == i + 1 ? '' : ','}";
      }
      testJson = testJson + "]}";

      var _body = {
        'user_id': userDetails.userId.toString(),
        'sample_collection_address_id': selectedAddress.id.toString(),
        // 'date': '${selectedDate.day}-${selectedDate.month}-${selectedDate.year}',
        'date': selectedDate.toString(),
        'time': '${selectedTime.hour}:${selectedTime.minute}',
        'payment_method':
            (selectedValue == 'Cash On Delivery' ? 'cod' : selectedValue)
                .toString()
                .toLowerCase(),
        'subtotal': subTotal.toString(),
        'tax': txt.toString(),
        'final_total': total.toString(),
        'test_json': testJson
      };
      var _body1 = {
        'user_id': userDetails.userId.toString(),
        'sample_collection_address_id': selectedAddress.id.toString(),
        'date': selectedDate.toString(),
        'time': '${selectedTime.hour}:${selectedTime.minute}',
        'payment_method': selectedValue.toString().toLowerCase(),
        'subtotal': subTotal.toString(),
        'tax': txt.toString(),
        'final_total': total.toString(),
        'test_json': testJson,
        'stripeToken': id
      };
      // try {
      final response = await http.post(
          Uri.parse(SERVER_ADDRESS + "$bookNowApi"),
          body: (selectedValue != 'Stripe') ? _body : _body1);




      if (response.statusCode == 200) {
        final jsonResponse = jsonDecode(response.body);


        if (jsonResponse['status'] == 1) {
          String paymentLink = "";
          if (selectedValue == 'Braintree' || selectedValue == 'Paystack') {

            if (selectedValue == 'Braintree') {
              paymentLink =
                  '${SERVER_ADDRESS.split("api/").first}make_app_payment?id=${jsonResponse['data']}';
            } else {
              paymentLink =
                  '${SERVER_ADDRESS.split("api/").first}paystack-payment?id=${jsonResponse['data']}';
            }
            var result = await Get.to(() => InAppWebViewScreen(
                  url: paymentLink,
                ));
            if (result == 'success') {
              Get.dialog(
                Center(
                  child: Container(
                    height: 280,
                    margin: EdgeInsets.symmetric(horizontal: 20),
                    padding: EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: darkBlue,
                    ),
                    child: Column(
                      children: [
                        boldText(
                            text: jsonResponse['msg'],
                            color: whiteColor,
                            size: 26),
                        SizedBox(
                          height: 20,
                        ),
                        regularText(
                            text: ORDER_SUCCESS_MSG2[LANGUAGE_TYPE],
                            color: subTextColor,
                            size: 16,
                            alignment: TextAlign.center),
                        SizedBox(
                          height: 15,
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 20),
                          child: customeElevatedButton(
                            Get.width * 0.9,
                            TRACK_ORDER[LANGUAGE_TYPE],
                            callback: () {
                              Get.offAll(
                                () => PagesWidget(
                                  selectedIndex: 0,
                                ),
                              );
                              Get.to(
                                () => BookDetailsScreen(
                                  orderId: jsonResponse['data'].toString(),
                                ),
                              );
                            },
                          ),
                        ),
                        SizedBox(
                          height: 15,
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 20),
                          child: customeElevatedButtonOutLine(
                            Get.width * 0.9,
                            BACK_TO_SHOP[LANGUAGE_TYPE],
                            color: themeSecondaryColor,
                            callback: () {
                              Get.offAll(() => PagesWidget(
                                    selectedIndex: 0,
                                  ));
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
              Get.snackbar(
                "Success",
                "${jsonResponse['msg']}",
                snackPosition: SnackPosition.BOTTOM,
                backgroundColor: Colors.green,
              );
            } else {
              Get.snackbar(
                "Payment Error",
                "Payment not done yet please try again!",
                snackPosition: SnackPosition.BOTTOM,
                backgroundColor: redColor,
              );
            }
          } else {

            Get.dialog(
              Center(
                child: Container(
                  height: 280,
                  margin: EdgeInsets.symmetric(horizontal: 20),
                  padding: EdgeInsets.symmetric(vertical: 10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: darkBlue,
                  ),
                  child: Column(
                    children: [
                      boldText(
                          text: jsonResponse['msg'],
                          color: whiteColor,
                          size: 26),
                      SizedBox(
                        height: 20,
                      ),
                      regularText(
                          text: ORDER_SUCCESS_MSG2[LANGUAGE_TYPE],
                          color: subTextColor,
                          size: 16,
                          alignment: TextAlign.center),
                      SizedBox(
                        height: 15,
                      ),
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 20),
                        child: customeElevatedButton(
                            Get.width * 0.9, TRACK_ORDER[LANGUAGE_TYPE],
                            callback: () {
                          Get.offAll(() => PagesWidget(
                                selectedIndex: 0,
                              ));
                          Get.to(() => BookDetailsScreen(
                                orderId: jsonResponse['data'].toString(),
                              ));
                        }),
                      ),
                      SizedBox(
                        height: 15,
                      ),
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 20),
                        child: customeElevatedButtonOutLine(
                          Get.width * 0.9,
                          BACK_TO_SHOP[LANGUAGE_TYPE],
                          color: themeSecondaryColor,
                          callback: () {
                            Get.offAll(() => PagesWidget(
                                  selectedIndex: 0,
                                ));
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
            Get.snackbar(
              "Success",
              "${jsonResponse['msg']}",
              snackPosition: SnackPosition.BOTTOM,
              backgroundColor: Colors.green,
            );
          }

          isBooking = false;
          update();
        } else {

          Get.snackbar(
            "Error",
            "data not found",
            snackPosition: SnackPosition.BOTTOM,
            backgroundColor: redColor,
          );
          isBooking = false;
          update();
        }
      }
      // } catch (e) {
      //   Get.snackbar(
      //     "Failed to load Data",
      //     "Something went wrong. Try again,",
      //     snackPosition: SnackPosition.BOTTOM,
      //     backgroundColor: redColor,
      //   );
      //   isBooking = false;
      //   update();
      // }
    }
  }

  String checkType(value) {
    if (value is String) {
      return 'String';
    } else if (value is int) {
      return 'int';
    }
    return 'Someting else';
  }

  Future DeleteAddress({id}) async {
    isAddressLoading = true;
    update();
    try {
      final response =
          await http.get(Uri.parse(SERVER_ADDRESS + "delete_address?id=${id}"));
      if (response.statusCode == 200) {
        final jsonResponse = jsonDecode(response.body);
        if (jsonResponse['status'] == 1) {
          // AddressList();
          fetchAddress();
          Get.snackbar(
            "Successful",
            "${jsonResponse['msg']}",
            snackPosition: SnackPosition.BOTTOM,
            backgroundColor: Colors.green,
          );
          // isLoading = false;
          update();
          // return categoryModelList;
        } else {
          isAddressLoading = false;
          Get.snackbar(
            "Error",
            "data not found",
            snackPosition: SnackPosition.BOTTOM,
            backgroundColor: redColor,
          );
          update();
        }
      }
    } catch (e) {
      Get.snackbar(
        "Failed to load Data",
        "Something went wrong. Try again,",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: redColor,
      );
      isAddressLoading = false;
      update();
    }
  }

  Map<String, dynamic>? paymentIntent;

  Future<void> displayPaymentSheet({
    required subTotal,
    required txt,
    required total,
    required Data data,
  }) async {
    try {
      await Stripe.instance.presentPaymentSheet();
      bookNow(
          subTotal: subTotal,
          txt: txt,
          total: total,
          data: data,
          id: paymentIntent!['id']);
      paymentIntent = null;
      // customDialog(
      //   s1: 'success'.tr,
      //   s2: 'payment_success'.tr,
      //   dismiss: false,
      //   onPressed: () {
      //     // Get.back();
      //     // bookAppointment(type: "stripe", tId: paymentIntent!['id']);
      //   },
      // );
    } on StripeException catch (e) {
      // customDialog(s1: 'fail'.tr, s2: "${'fail_description'.tr}\n$e");
      isBooking = true;
      update();
      Get.snackbar(
        "Payment Error",
        "Payment not done yet please try again!\n$e",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: redColor,
      );
    } catch (e) {
      isBooking = true;
      update();
      Get.snackbar(
        "Payment Error",
        "Payment not done yet please try again!\n$e",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: redColor,
      );
      // customDialog(s1: 'fail'.tr, s2: "${'fail_description'.tr}\n$e");
    }
  }
}
