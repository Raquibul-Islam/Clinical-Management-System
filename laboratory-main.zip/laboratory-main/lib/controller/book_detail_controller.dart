import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:map_launcher/map_launcher.dart';
import 'package:url_launcher/url_launcher.dart';

import '../Models/booking_detail_model.dart';
import '../Models/user_details_class.dart';
import '../Screens/View/BookScreens/book_details_screen.dart';
import '../utils/AllText.dart';
import '../utils/api.dart';
import '../utils/colors.dart';
import '../utils/strings.dart';

class BookDetailController extends GetxController {
  bool isLoading = true;
  bool isFeedbackLoading = false;
  final String orderId;
  BookingDetailModel? bookingDetailModel;
  bool isGoogleMapLoading = false;
  BitmapDescriptor? pinLocationIcon;
  UserDetailsClass userDetails = UserDetailsClass();

  BookDetailController(this.orderId);

  List<TimeLineDetail> timeLineDetail = [
    TimeLineDetail(
        time: '00:00',
        title: 'Process',
        des: 'On the Mange Orders page, an order with a status of pending',
        isTrue: false),
    TimeLineDetail(
        time: '',
        title: 'Accepted',
        des: 'Your order Accepted For delivery.',
        isTrue: false),
    TimeLineDetail(
        time: '',
        title: 'Sample Collected',
        des: 'Need an efficient way to collect order',
        isTrue: false),
    TimeLineDetail(
        time: '',
        title: 'Complete',
        des: 'your order has been delivered today.',
        isTrue: false),
  ];

  List<TimeLineDetail> rejectTimeLineDetail = [
    TimeLineDetail(
        time: '00:00',
        title: 'Process',
        des: 'On the Mange Orders page, an order with a status of pending',
        isTrue: false),
    TimeLineDetail(
        time: '',
        title: 'Reject',
        des: 'Your order is Rejected.',
        isTrue: false),
    TimeLineDetail(
        time: '',
        title: 'Refund',
        des: 'Refund add your account in 5 to 7 working days',
        isTrue: false),
  ];

  onInit() {
    super.onInit();
    init();
  }

  init() {
    getUserDetails();
    BitmapDescriptor.fromAssetImage(ImageConfiguration(), 'assets/pin.png')
        .then((onValue) {
      pinLocationIcon = onValue;
    });
    getBookDetail();
  }

  getUserDetails() async {
    UserDetailsClass data = await UserDetailsClass().getUserDetails();
    userDetails = data;
  }

  String latlong = "";

  getBookDetail() async {
    // try {
    final response = await http.get(
        Uri.parse(SERVER_ADDRESS + getBookDetailApi + '?order_id=$orderId'));
    if (response.statusCode == 200) {
      print("response :: ${response.request?.url}");
      final jsonResponse = jsonDecode(response.body);
      if (jsonResponse['status'] == 1) {
        bookingDetailModel = BookingDetailModel.fromJson(jsonResponse);
        await makeTimeLineList(bookingDetailModel!);
        center = bookingDetailModel!.data!.useraddressdetails == null
            ? LatLng(21.237874, 72.888988)
            : LatLng(bookingDetailModel!.data!.useraddressdetails!.lat!,
                bookingDetailModel!.data!.useraddressdetails!.long!);
        coords = bookingDetailModel!.data!.useraddressdetails == null
            ? Coords(21.237874, 72.888988)
            : Coords(bookingDetailModel!.data!.useraddressdetails!.lat!,
                bookingDetailModel!.data!.useraddressdetails!.long!);
        latlong = bookingDetailModel!.data!.useraddressdetails == null
            ? "21.237874, 72.888988"
            : "${bookingDetailModel!.data!.useraddressdetails!.lat!}, ${bookingDetailModel!.data!.useraddressdetails!.long!}";
        // center = LatLng(21.237874, 72.888988);
        locateMarker(center!);
        isLoading = false;
        update();
      } else {
        Get.snackbar(
          "Error",
          "data not found",
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: redColor,
        );
        isLoading = false;
        update();
      }
    }
    // } catch (e) {
    //   Get.snackbar(
    //     "Failed to load Data",
    //     "Something went wrong. Try again,",
    //     snackPosition: SnackPosition.BOTTOM,
    //     backgroundColor: redColor,
    //   );
    //   isLoading = false;
    //   update();
    // }
  }

  getTime(value) {
    if (value != null && value != '') {
      DateFormat dateFormat = DateFormat("yyyy-MM-dd HH:mm:ss");
      DateTime dateTime = dateFormat.parse(value);
      String formattedDate = DateFormat('kk:mm').format(dateTime);
      return formattedDate;
    }
    return '00:00';
  }

  Future<void> makeTimeLineList(BookingDetailModel bookingDetailModel) async {
    if (bookingDetailModel.data!.status == 3 ||
        bookingDetailModel.data!.status == 4) {
      if (bookingDetailModel.data!.status! >= 1) {
        rejectTimeLineDetail[0].isTrue = true;
        rejectTimeLineDetail[0].time =
            getTime(bookingDetailModel.data!.orderplaceDate);
      }
      if (bookingDetailModel.data!.status! >= 3) {
        rejectTimeLineDetail[1].isTrue = true;
        rejectTimeLineDetail[1].time =
            getTime(bookingDetailModel.data!.rejectDatetime);
        rejectTimeLineDetail[1].des =
            bookingDetailModel.data!.rejectDescription ?? '';
      }
      if (bookingDetailModel.data!.status! >= 4) {
        rejectTimeLineDetail[2].isTrue = true;
        rejectTimeLineDetail[2].time =
            getTime(bookingDetailModel.data!.refundDatetime);
      }
      // if()
    } else {
      if (bookingDetailModel.data!.status! >= 1) {
        timeLineDetail[0].isTrue = true;
        timeLineDetail[0].time =
            getTime(bookingDetailModel.data!.orderplaceDate);
      }
      if (bookingDetailModel.data!.status! >= 2) {
        timeLineDetail[1].isTrue = true;
        timeLineDetail[1].time =
            getTime(bookingDetailModel.data!.acceptDatetime);
      }
      if (bookingDetailModel.data!.status! >= 5) {
        timeLineDetail[2].isTrue = true;
        timeLineDetail[2].time =
            getTime(bookingDetailModel.data!.collectedDatetime);
      }
      if (bookingDetailModel.data!.status! >= 7) {
        timeLineDetail[3].isTrue = true;
        timeLineDetail[3].time =
            getTime(bookingDetailModel.data!.completeDatetime);
      }
    }
    return;
  }

  late GoogleMapController mapController;
  LatLng? center;
  Coords? coords;

  void onMapCreated(GoogleMapController controller) {
    mapController = controller;
  }

  onMapTap(LatLng latLng) {
    center = latLng;
    // getAddress();
    locateMarker(latLng);
  }

  final Map<String, Marker> markers = {};

  locateMarker(LatLng latLng) async {
    final marker = Marker(
      draggable: true,
      alpha: 1,
      // anchor: Offset(0.5,0.5),
      markerId: const MarkerId("curr_loc"),
      position: latLng,
      infoWindow: InfoWindow(title: Your_Location[LANGUAGE_TYPE]),
      icon: pinLocationIcon!,
    );
    markers["Current Location"] = marker;
    update();
  }

  void launchMap() async {
    final String url =
        "https://maps.google.com/maps/search/?api=AIzaSyCNpORheccb5Q9MiJho629DV5N8nCeoFXA&query=$latlong";
    if (await canLaunch(url)) {
      print("Can launch");
      canLaunch(
          "https://maps.google.com/maps/search/?api=AIzaSyCNpORheccb5Q9MiJho629DV5N8nCeoFXA&query=$latlong");
      // void initState(){
      //   super.initState();
      //
      //   canLaunch( "https://maps.google.com/maps/search/?api=AIzaSyCNpORheccb5Q9MiJho629DV5N8nCeoFXA&query=$lat,$long");
      // }

      await launch(url);
    } else {
      print("Could not launch");
      throw 'Could not launch Maps';
    }
  }

  double selectedRating = 4.0;
  double iconSize = 40;
  TextEditingController tcFeedback = TextEditingController();

  String s1 = 'assets/book_detail/smile-select.png';
  String us1 = 'assets/book_detail/smile-unselect.png';
  String s2 = 'assets/book_detail/poor-select.png';
  String us2 = 'assets/book_detail/poor-unselect.png';
  String s3 = 'assets/book_detail/silent-select.png';
  String us3 = 'assets/book_detail/silent-unselect.png';
  String s4 = 'assets/book_detail/love-select.png';
  String us4 = 'assets/book_detail/love-unselect.png';
  String s5 = 'assets/book_detail/laughing-select.png';
  String us5 = 'assets/book_detail/laughing-unselect.png';

  submitFeedback() async {
    if (tcFeedback.text.isEmpty) {
      Get.snackbar('Enter Message', 'Message is required for submit',
          snackPosition: SnackPosition.BOTTOM, backgroundColor: redColor);
      return;
    }
    Get.back();
    isFeedbackLoading = true;
    update();
    try {
      final response =
          await http.post(Uri.parse(SERVER_ADDRESS + addFeedBack), body: {
        "user_id": userDetails.userId.toString(),
        "ratting": selectedRating.round().toString(),
        "order_id": orderId.toString(),
        "description": tcFeedback.text.toString()
      });
      if (response.statusCode == 200) {
        tcFeedback.clear();
        selectedRating = 4.0;
        final jsonResponse = jsonDecode(response.body);
        if (jsonResponse['status'] == 1) {
          Get.snackbar('Success', jsonResponse['msg'],
              snackPosition: SnackPosition.BOTTOM,
              backgroundColor: Colors.green);
          isFeedbackLoading = false;
          update();
        } else {
          Get.snackbar(
            "Error",
            "data not found",
            snackPosition: SnackPosition.BOTTOM,
            backgroundColor: redColor,
          );
          isFeedbackLoading = false;
          update();
        }
      }
    } catch (e) {
      Get.snackbar(
        "Failed to load Data",
        "Something went wrong. Try again,",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: redColor,
      );
      isFeedbackLoading = false;
      update();
    }
  }
}
