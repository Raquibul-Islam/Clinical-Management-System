import 'dart:convert';

import 'package:get/get.dart';
import 'package:leboratory/Models/categoryModel.dart';
import 'package:leboratory/utils/api.dart';
import 'package:http/http.dart' as http;
import 'package:leboratory/utils/colors.dart';

class CategoryController extends GetxController {
  CategoryModel? categoryModel;
  bool isLoading = true;
  List<CategoryModelList>? categoryModelList = [];

  Future getCategory() async {
    // update();
    try {
      final response = await http.get(Uri.parse(SERVER_ADDRESS + getcategory));
      if (response.statusCode == 200) {
        final jsonResponse = jsonDecode(response.body);
        if (jsonResponse['status'] == 1) {
          categoryModel = CategoryModel.fromJson(jsonResponse);
          // List<CategoryModelList>?  detail = categoryModel!.categoryModelList;
          categoryModelList = categoryModel!.categoryModelList;
          isLoading = false;
          update();
          // return categoryModelList;
        } else {
          isLoading = false;
          Get.snackbar(
            "Error",
            "data not found",
            snackPosition: SnackPosition.BOTTOM,
            backgroundColor: redColor,
          );
          update();
        }
      }
    } catch (e) {
      Get.snackbar(
        "Failed to load Data",
        "Something went wrong. Try again,",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: redColor,
      );
      isLoading = false;
      update();
    }
  }

  void searchData(String value) async {
    isLoading = true;
    try {
      final response = await http
          .get(Uri.parse(SERVER_ADDRESS + searchCategory + "?term=$value"));
      if (response.statusCode == 200) {
        final jsonResponse = jsonDecode(response.body);
        if (jsonResponse['status'] == 1) {
          categoryModel = CategoryModel.fromJson(jsonResponse);
          // List<CategoryModelList>?  detail = categoryModel!.categoryModelList;
          categoryModelList = categoryModel!.categoryModelList;
          isLoading = false;
          update();
          // return categoryModelList;
        } else {
          isLoading = false;
          Get.snackbar(
            "Error",
            "data not found",
            snackPosition: SnackPosition.BOTTOM,
            backgroundColor: redColor,
          );
          update();
        }
      }
    } catch (e) {
      Get.snackbar(
        "Failed to load Data",
        "Something went wrong. Try again,",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: redColor,
      );
      isLoading = false;
      update();
    }
  }

  /// Category Deta
}
