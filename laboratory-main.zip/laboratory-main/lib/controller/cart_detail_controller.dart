import 'dart:convert';

import 'package:get/get.dart';
import 'package:leboratory/Models/local_package_detail_model.dart';

import '../Models/cart_list_model.dart';
import '../Models/local_user_model.dart';
import '../Models/user_details_class.dart';
import '../Services/database.dart';
import 'package:http/http.dart' as http;

import '../utils/api.dart';
import '../utils/colors.dart';

class CartDetailController extends GetxController {
  bool isLoading = true;
  bool isDataNotFound = false;
  bool isCartEmpty = false;
  UserDetailsClass userDetails = UserDetailsClass();
  final dbHelper = DatabaseHelper.instance;
  List<CartUserPackageDetailModel> cartUserPackageDetailModel = [];
  CartListModel? cartListModel;
  int subTotal = 0;
  int total = 0;
  int saving = 0;

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    // getUserDetails();
  }

  getUserDetails() async {
    UserDetailsClass data = await UserDetailsClass().getUserDetails();
    userDetails = data;
    if (userDetails.isLoggedIn) {
      fetchCartList();
    }else{
      isLoading = false;
    }
    update();
  }


  fetchCartList() async {
    subTotal = 0;
    saving = 0;
    total = 0;
    isDataNotFound = false;
    isCartEmpty = false;
    isLoading = true;
    update();
    try {
      final response =
      await http.get(Uri.parse(SERVER_ADDRESS + getCartList + '?user_id=${userDetails.userId}'));
      if (response.statusCode == 200) {
        final jsonResponse = jsonDecode(response.body);
        if (jsonResponse['status'] == 1) {
          cartListModel = CartListModel.fromJson(jsonResponse);
          for(var cart in cartListModel!.data!.cart!){
            for(var test in cart.testdata!){
              subTotal += test.price!;
              // int differance = test.mrp! - test.price!;
              saving += (test.mrp! - test.price!);
            }
          }
          total = subTotal + cartListModel!.data!.txt!;
          isCartEmpty = false;
          isLoading = false;
          update();
        }else if(jsonResponse['status'] == 0){
          isCartEmpty = true;
          isLoading = false;
          update();
        }
        else {
          Get.snackbar(
            "Error",
            "data not found",
            snackPosition: SnackPosition.BOTTOM,
            backgroundColor: redColor,
          );
          isDataNotFound = true;
          isLoading = false;
          update();
          
        }
      }
    } catch (e) {
      Get.snackbar(
        "Failed to load Data",
        "Something went wrong. Try again,",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: redColor,
      );
      isDataNotFound = true;
      isLoading = false;
      update();
    }
  }

  deletePackage(Testdatum data,memberId) async{
    isLoading = true;
    update();
    try {
      final response =
          await http.get(Uri.parse(SERVER_ADDRESS + updateCart + '?user_id=${userDetails.userId}&member_id=${memberId}&type_id=${data.typeId}&type=${data.type}&parameter=${data.parameter}&action=1'));
      if (response.statusCode == 200) {
        final jsonResponse = jsonDecode(response.body);
        if (jsonResponse['status'] == 1) {
          fetchCartList();
          // cartListModel = CartListModel.fromJson(jsonResponse);
          // isCartEmpty = false;
          // isLoading = false;
          update();
        }
        else {
          Get.snackbar(
            "Error",
            "data not found",
            snackPosition: SnackPosition.BOTTOM,
            backgroundColor: redColor,
          );
          isLoading = false;
          update();
          
        }
      }
    } catch (e) {
      Get.snackbar(
        "Failed to load Data",
        "Something went wrong. Try again,",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: redColor,
      );
      isLoading = false;
      update();
    }
  }


  /// ========================================================

  /// Local Detail
  fetCartPackageDetailFromLocal() async {
    cartUserPackageDetailModel.clear();
    isLoading = true;
    update();
    // queryAllUserList();
    // queryAllPackageList();

    /// fetch user
    List<LocalUserModel> userData = await dbHelper.userModelQueryAll();
    /// fetch package
    List<LocalPackageModel> packageData = await dbHelper.packageModelQueryAll();
    /// store package user wise
    for (var user in userData) {
      List<LocalPackageModel> userPackage = [];
      for (var package in packageData) {
        if (package.userId == user.userId) {
         userPackage.add(package);
        }
      }
      if(userPackage.length!=0){
        cartUserPackageDetailModel.add(CartUserPackageDetailModel(localUserModel: user, localPackageDetail: userPackage));
      }
    }
    isLoading = false;
    update();

  }

  void deletePackageFromCart({required packageId,required packageType,required userId}) async{
    var deleteRow = await dbHelper.deletePackageFromCart(uid: userId, packageId: packageId, packageType: packageType);
    fetCartPackageDetailFromLocal();
  }

  void queryAllUserList() async {
    var allRows = await dbHelper.userQueryAll();
    allRows.forEach((row) {

    });
  }

  void queryAllPackageList() async {
    var allRows = await dbHelper.packageQueryAll();
    allRows.forEach((row) {
    });
  }


}

class CartUserPackageDetailModel {
  LocalUserModel localUserModel;
  List<LocalPackageModel> localPackageDetail;

  CartUserPackageDetailModel(
      {required this.localUserModel, required this.localPackageDetail});
}
