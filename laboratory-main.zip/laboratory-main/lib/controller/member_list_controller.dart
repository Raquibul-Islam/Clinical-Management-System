import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:leboratory/Models/local_package_detail_model.dart';
import 'package:leboratory/Services/database.dart';
import 'package:leboratory/Services/hive_database.dart';

import '../Models/family_member_list_model.dart';
import 'package:http/http.dart' as http;

import '../Models/user_details_class.dart';
import '../Screens/Custome_Widgets/page_widget.dart';
import '../utils/api.dart';
import '../utils/colors.dart';

class MemberListClass extends GetxController{

  bool isLoading = true;
  bool isButtonLoading = false;
  bool isDataNotFound = false;
  FamilyMemberListModel? familyMemberListModel;
  List<Datum> familyMemberList = [];
  List<Datum> selectedMemberList = [];
  UserDetailsClass userDetails = UserDetailsClass();

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    init();
  }

  init() async{
    await getUserDetails();
    getFamilyMemberList();
  }

  getUserDetails() async{
    UserDetailsClass data = await UserDetailsClass().getUserDetails();
    userDetails = data;
  }

  deleteMember({required int memberId}) async{
    isLoading = true;
    update();
    try {
      final response = await http.get(Uri.parse(SERVER_ADDRESS + "$deleteMemberApi?id=$memberId"));
      if (response.statusCode == 200) {
        final jsonResponse = jsonDecode(response.body);
        if (jsonResponse['status'] == 1) {
          getFamilyMemberList();
          Get.snackbar(
            "Success",
            "${jsonResponse['msg']}",
            snackPosition: SnackPosition.BOTTOM,
            backgroundColor: Colors.green,
          );
          // isLoading = false;
          update();
        } else {
          Get.snackbar(
            "Error",
            "data not found",
            snackPosition: SnackPosition.BOTTOM,
            backgroundColor: redColor,
          );
          isLoading = false;
          update();
          
        }
      }
    } catch (e) {
      Get.snackbar(
        "Failed to load Data",
        "Something went wrong. Try again,",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: redColor,
      );
      isLoading = false;
      update();
    }
  }

  setLoadingTrue(){
    isLoading = true;
    update();
  }

  getFamilyMemberList() async {
    isDataNotFound = false;
    familyMemberList.clear();
    try {
      final response =
      await http.get(Uri.parse(SERVER_ADDRESS + getMemberList + '?id=${userDetails.userId}'));
      if (response.statusCode == 200) {
        final jsonResponse = jsonDecode(response.body);
        if (jsonResponse['status'] == 1) {
          familyMemberListModel = FamilyMemberListModel.fromJson(jsonResponse);
          familyMemberList.addAll(familyMemberListModel!.data!);
          isDataNotFound = false;
          isLoading = false;
          update();
        } else if (jsonResponse['status'] == 0){
          isDataNotFound = true;
          isLoading = false;
          update();
        }else {
          Get.snackbar(
            "Error",
            "data not found",
            snackPosition: SnackPosition.BOTTOM,
            backgroundColor: redColor,
          );
          isDataNotFound = true;
          isLoading = false;
          update();
          
        }
      }
    } catch (e) {
      Get.snackbar(
        "Failed to load Data",
        "Something went wrong. Try again,",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: redColor,
      );
      isDataNotFound = true;
      isLoading = false;
      update();
    }
  }

  selectMember(int index,bool isSelected){
    familyMemberList[index].isSelected = isSelected;
    update();
  }

  final dbHelper = DatabaseHelper.instance;

  addToCart(LocalPackageModel localPackageModel) async{
    selectedMemberList.clear();
    List<int> selecteIdList = [];
    for(var data in familyMemberList){
      if(data.isSelected!){
        selectedMemberList.add(data);
        selecteIdList.add(data.id!);
      }
    }
    if(selectedMemberList.isEmpty){
      Get.snackbar(
        "Select Member",
        "It is mandatory to select at least one member to add to cart",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: redColor,
      );
      return;
    }

    String selectIdListString = selecteIdList.toString().replaceAll('[', '').replaceAll(']', '').removeAllWhitespace;

    isButtonLoading = true;
    update();
    try {
      final response = await http.get(Uri.parse(SERVER_ADDRESS + "$updaetCart?user_id=${userDetails.userId.toString()}&member_id=$selectIdListString&type_id=${localPackageModel.id}&type=${localPackageModel.packageType}&parameter=${localPackageModel.packageParameters}&action=0"));
      if (response.statusCode == 200) {
        final jsonResponse = jsonDecode(response.body);
        if (jsonResponse['status'] == 1) {
          Get.offAll(()=>PagesWidget(selectedIndex: 1,));
          Get.snackbar(
            "Success",
            "${jsonResponse['msg']}",
            snackPosition: SnackPosition.BOTTOM,
            backgroundColor: Colors.green,
          );
          isButtonLoading = false;
          update();
        }
        else {
          Get.snackbar(
            "Error",
            "data not found",
            snackPosition: SnackPosition.BOTTOM,
            backgroundColor: redColor,
          );
          isButtonLoading = false;
          update();
          
        }
      }
    }
    catch (e) {
      Get.snackbar(
        "Failed to load Data",
        "Something went wrong. Try again,",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: redColor,
      );
      isButtonLoading = false;
      update();
    }




    /// Local Databse Cart
    /// Insert User Data
    // for(var data in selectedMemberList){
    //   insertUserData(userId: data.id!, name: data.name!, age: data.age.toString(), relation: data.relation!, gender: data.gender!,localPackageModel: localPackageModel);
    // }
    // /// Fetch Data
    // queryAllUserList();
    //
    // /// Fetch Package Data;
    // queryAllPackageList();
  }


  void insertUserData({required int userId,required String name,required String age,required String relation,required String gender,required LocalPackageModel localPackageModel}) async {

    Map<String,dynamic> userRow = {
      DatabaseHelper.utUserId : userId,
      DatabaseHelper.utUserName : name,
      DatabaseHelper.utUserAge: age,
      DatabaseHelper.utUserRelation: relation,
      DatabaseHelper.utUserGender: gender,
    };

    List isUserExist = await dbHelper.checkUser(userRow[DatabaseHelper.utUserId]);

    /// Not Exist Then Add Or skip
    if(isUserExist.length==0){
      final id = await dbHelper.insertUserDetail(userRow);

    }else{

    }

    Map<String,dynamic> packageRow = {
      DatabaseHelper.pdtUserId : userId,
      DatabaseHelper.pdtPackageId : localPackageModel.packageId,
      DatabaseHelper.pdtPackageType : localPackageModel.packageType,
      DatabaseHelper.pdtPackageName : localPackageModel.packageName,
      DatabaseHelper.pdtPackageMrp : localPackageModel.packageMrp,
      DatabaseHelper.pdtPackagePrice : localPackageModel.packagePrice,
      DatabaseHelper.pdtPackageParameters : localPackageModel.packageParameters,
      DatabaseHelper.pdtPackageDiscount : localPackageModel.packageDiscount,
    };


    List isPackageExist = await dbHelper.checkPackageExist(uid: userId,packageId: packageRow[DatabaseHelper.pdtPackageId],packageType: packageRow[DatabaseHelper.pdtPackageType]);

    if(isPackageExist.length==0){
      final id = await dbHelper.insertPackageDetail(packageRow);

    }else{

    }

    /// Fetch Data
    queryAllUserList();

    /// Fetch Package Data;
    queryAllPackageList();

  }

  void queryAllUserList() async{
    var allRows = await dbHelper.userQueryAll();
    allRows.forEach((row) {

    });

  }

  void queryAllPackageList() async{
    var allRows = await dbHelper.packageQueryAll();

    allRows.forEach((row) {
    });
  }

  void deleteAllFieldFromDatabase(){
    // var deleteData =
  }

}