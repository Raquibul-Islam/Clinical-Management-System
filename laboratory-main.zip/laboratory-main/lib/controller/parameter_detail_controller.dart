import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
// import 'package:leboratory/Models/packageDetails.dart';
import 'package:leboratory/utils/api.dart';
import 'package:http/http.dart' as http;
import 'package:leboratory/utils/colors.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sn_progress_dialog/progress_dialog.dart';

import '../Models/parameter_detail_model.dart';
import '../Models/user_details_class.dart';

class ParameterDetailController extends GetxController {
  ParameterDetailModel? packageDetail;
  bool isLoading = true;
  bool isError = false;
  Data? data;
  int selectedTabbar = 0;
  var dio = Dio();
  int index1 = 0;
  bool test = false;
  UserDetailsClass userDetails = UserDetailsClass();

  // int packageId;
  final parameterId;
  ParameterDetailController(this.parameterId);

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    init();
  }

  init() async {
    await getUserDetails();
    getParameterDetails();
  }

  getUserDetails() async {
    UserDetailsClass data = await UserDetailsClass().getUserDetails();
    userDetails = data;
  }

  /// type_id id ma pass krva nu
  /// type ma different api call krva ni
  /// 1=>package,2=>parameter,3=>profile

  Future getParameterDetails() async {
    // update();
    // try {
    final response = await http.get(
        Uri.parse(SERVER_ADDRESS + getParameterDetail + "?id=$parameterId"));

    if (response.statusCode == 200) {
      final jsonResponse = jsonDecode(response.body);
      if (jsonResponse['status'] == 1) {
        // try {
        packageDetail = ParameterDetailModel.fromJson(jsonResponse);
        // } catch (E) {
        //   print("E :: ${E.toString()}");
        // }
        data = packageDetail!.data;
        isLoading = false;
        update();
      } else {
        isLoading = false;
        isError = true;
        Get.snackbar(
          "Error",
          "data not found",
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: redColor,
        );
        update();
      }
    }
    // } catch (e) {
    //   Get.snackbar(
    //     "Failed to load Data",
    //     "Something went wrong. Try again,",
    //     snackPosition: SnackPosition.BOTTOM,
    //     backgroundColor: redColor,
    //   );
    //   isLoading = false;
    //   isError = true;
    //   update();
    // }
  }

  void changeTab(int index) {
    selectedTabbar = index;
    update();
  }

  Future download(
      Dio dio, String pdfPath, String labReport, ProgressDialog pd) async {
    update();
    try {
      var response = await dio.get(
        pdfPath,
        onReceiveProgress: (received, total) async {
          int progress = (((received / total) * 100).toInt());
          pd.update(value: progress - 5);
          await Future.delayed(const Duration(milliseconds: 100));
        },
        //Received data with List<int>
        options: Options(
            responseType: ResponseType.bytes,
            followRedirects: true,
            validateStatus: (status) {
              return status! < 500;
            }),
      );
      File file = File(labReport);
      pd.update(value: 100);
      // pd.close();
      addIndex();
      var raf = file.openSync(mode: FileMode.write);
      // response.data is List<int> type
      raf.writeFromSync(response.data);
      await raf.close();
      // pd.update(value: 100);
      // update();
    } catch (e) {}
  }

  void addIndex() {
    index1++;
    update();
  }
}
