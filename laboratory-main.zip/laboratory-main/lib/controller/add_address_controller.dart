import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:leboratory/main.dart';
import 'package:leboratory/utils/colors.dart';
import '../Models/address_list_model.dart';
import '../Models/user_details_class.dart';
import '../utils/AllText.dart';
import '../utils/api.dart';
import '../utils/strings.dart';
import 'package:http/http.dart' as http;

import 'address_list_controller.dart';

class AddAddressController extends GetxController {
  final Datum? address;

  AddAddressController(this.address);

  late GoogleMapController mapController;
  LatLng? center;
  BitmapDescriptor? pinLocationIcon;
  final Map<String, Marker> markers = {};
  bool isGoogleMapLoading = true;
  bool isDefaultAddress = true;
  bool isAddingAddress = false;
  bool isGettingManagersCity = false;
  UserDetailsClass userDetails = UserDetailsClass();

  TextEditingController tcAddress = TextEditingController();
  TextEditingController tcHouseNo = TextEditingController();
  TextEditingController tcState = TextEditingController();
  TextEditingController tcPincode = TextEditingController();
  TextEditingController tcCity = TextEditingController();
  TextEditingController tcPhone = TextEditingController();
  TextEditingController tcSaveAS = TextEditingController();
  int id = 0;
  List<CityList> managerCityList = [];
  ManageCityModel? manageCityModel;
  // EnumDefaultAddress isDefaultAddress = EnumDefaultAddress.isDefault;

  @override
  onInit() {
    super.onInit();
    init();
  }

  init() {
    isGoogleMapLoading = true;
    update();
    BitmapDescriptor.fromAssetImage(ImageConfiguration(), 'assets/pin.png')
        .then((onValue) {
      pinLocationIcon = onValue;
    });
    getUserDetails();
    setData();
    getAddress();
    getManagerCity();
  }

  setData() {
    if (address != null) {
      if (address!.isDefault == 1) {
        isDefaultAddress = true;
      } else {
        isDefaultAddress = false;
      }
      tcAddress.text = address!.address!;
      tcHouseNo.text = address!.houseNo!;
      tcState.text = address!.state!;
      tcPincode.text = address!.pincode!.toString();
      tcCity.text = address!.city!;
      tcPhone.text = address!.phone == null ? "" : address!.phone!.toString();
      tcSaveAS.text = address!.name!;
      center = LatLng(address!.lat!, address!.long!);
    } else {}
  }

  getUserDetails() async {
    UserDetailsClass data = await UserDetailsClass().getUserDetails();
    userDetails = data;
  }

  changeIsDefaultAddress() {
    isDefaultAddress = !isDefaultAddress;
    update();
  }

  void onMapCreated(GoogleMapController controller) {
    mapController = controller;
  }

  onMapTap(LatLng latLng) {
    center = latLng;
    getAddress();
    locateMarker(latLng);
  }

  Future<Position> determinePosition() async {
    bool serviceEnabled;
    LocationPermission permission;

    // Test if location services are enabled.
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      // Location services are not enabled don't continue
      // accessing the position and request users of the
      // App to enable the location services.

      showPermissionDialog();
      return Future.error('Location services are disabled.');
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        // Permissions are denied, next time you could try
        // requesting permissions again (this is also where
        // Android's shouldShowRequestPermissionRationale
        // returned true. According to Android guidelines
        // your App should show an explanatory UI now.
        showPermissionDialog();
        return Future.error(Location_Permissions_Denied[LANGUAGE_TYPE]);
      }
    }

    if (permission == LocationPermission.deniedForever) {
      // Permissions are denied forever, handle appropriately.
      showPermissionDialog();
      return Future.error(
          Location_Permissions_Permanently_Denied[LANGUAGE_TYPE]);
    }

    // When we reach here, permissions are granted and we can
    // continue accessing the position of the device.
    // return await getAddress();
    return await Geolocator.getCurrentPosition();
  }

  showPermissionDialog() {
    Get.defaultDialog(
      contentPadding: EdgeInsets.only(top: 0),
      backgroundColor: themeSecondaryColor,
      title: Give_Location_Permission[LANGUAGE_TYPE],
      // titleStyle: AppFontStyle.appBarTextStyle.copyWith(fontSize: 16, height: 2),
      content: Container(
        decoration: const BoxDecoration(color: themeSecondaryColor),
        child: Column(
          children: [
            // CustomButoonWithLbl(
            //     onTap: () async {
            //       Get.back();
            //       getAddress();
            //     },
            //     lbl: AppStrings.retry),
            GestureDetector(
              onTap: () async {
                Get.back();
                getAddress();
              },
              child: Container(
                height: 80,
                // width: 240,
                // margin: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                // alignment: Alignment.center,
                // decoration: const BoxDecoration(
                //     image: DecorationImage(
                //       image: AssetImage(
                //         AppImages.imageBtnBg,
                //       ),
                //       fit: BoxFit.fitHeight,
                //     )),
                child: Center(
                  child: Padding(
                    padding: const EdgeInsets.only(bottom: 5),
                    child: Text(
                      Retry[LANGUAGE_TYPE],
                      // style: GoogleFonts.poppins(
                      //     color: AppColor.white,
                      //     fontSize: 16,
                      //     fontWeight: FontWeight.w700),
                    ),
                  ),
                ),
              ),
            ),
            GestureDetector(
              onTap: () async {
                await Geolocator.openAppSettings();
                await Geolocator.openLocationSettings();
              },
              child: Container(
                height: 50,
                width: 220,
                // decoration: BoxDecoration(
                //   border: Border.all(color: AppColor.blue),
                //   borderRadius: BorderRadius.circular(30),
                // ),
                child: Center(
                  child: Text(
                    Open_Setting[LANGUAGE_TYPE],
                    // style: GoogleFonts.poppins(
                    //     color: AppColor.white,
                    //     // fontSize: MediaQuery.of().size.width>360?24:20,
                    //     fontSize: 14,
                    //     fontWeight: FontWeight.w700),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  getAddress() async {
    if (center == null) {
      var position = await determinePosition();
      center = LatLng(position.latitude, position.longitude);
      // center = LatLng(39.205303685162114, -76.69310232523343);
    }

    List<Placemark> placemarks =
        await placemarkFromCoordinates(center!.latitude, center!.longitude);
    Placemark place = placemarks.first;

    String address =
        '${place.street},${place.postalCode},${place.subLocality},${place.locality},${place.administrativeArea},${place.country}';
    tcAddress.text = address;
    locateMarker(center!);
    isGoogleMapLoading = false;
    update();
  }

  locateMarker(LatLng latLng) async {
    final marker = Marker(
      draggable: true,
      alpha: 1,
      // anchor: Offset(0.5,0.5),
      markerId: const MarkerId("curr_loc"),
      position: latLng,
      infoWindow: InfoWindow(title: Your_Location[LANGUAGE_TYPE]),
      icon: pinLocationIcon!,
    );
    markers["Current Location"] = marker;
    update();
  }

  getManagerCity({bool isEdit = false, addressId}) async {
    isGettingManagersCity = true;
    update();

    try {
      final response = await http.get(Uri.parse(SERVER_ADDRESS + "$getCity"));
      if (response.statusCode == 200) {
        final jsonResponse = jsonDecode(response.body);
        if (jsonResponse['status'] == 1) {
          manageCityModel = ManageCityModel.fromJson(jsonResponse);
          if (address == null) {
            tcCity.text = manageCityModel!.data![0]!.name!;
            id = manageCityModel!.data![0]!.id!;
          } else {
            var ind = "";

            for (int i = 0; i < manageCityModel!.data!.length; i++) {
              if (manageCityModel!.data![i]!.id == int.parse(address!.city!)) {
                ind = manageCityModel!.data![i]!.name!;
              }
            }

            if (ind == "") {
              tcCity.text = manageCityModel!.data![0]!.name!;
              id = manageCityModel!.data![0]!.id!;
            } else {
              tcCity.text = ind;
              id = int.parse(address!.city!);
            }
          }

          isGettingManagersCity = false;
          update();
        } else {
          Get.snackbar(
            "Error",
            "data not found",
            snackPosition: SnackPosition.BOTTOM,
            backgroundColor: redColor,
          );
          isGettingManagersCity = false;
          update();
        }
      }
    } catch (e) {
      Get.snackbar(
        "Failed to load Data",
        "Something went wrong. Try again,",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: redColor,
      );
      isGettingManagersCity = false;
      update();
    }
  }

  addAddress({bool isEdit = false, addressId}) async {
    isAddingAddress = true;
    update();

    int isDefaultInt;
    if (isDefaultAddress) {
      isDefaultInt = 1;
    } else {
      isDefaultInt = 0;
    }

    var _body;

    if (isEdit) {
      _body = {
        'id': addressId.toString(),
        'user_id': userDetails.userId.toString(),
        'name': tcSaveAS.text,
        'house_no': tcHouseNo.text,
        'pincode': tcPincode.text,
        'city': id.toString(),
        'state': tcState.text,
        'is_default': isDefaultInt.toString(),
        'address': tcAddress.text,
        'lat': center!.latitude.toString(),
        'long': center!.longitude.toString(),
        'phone_no': tcPhone.text,
      };
    } else {
      _body = {
        'id': 0.toString(),
        'user_id': userDetails.userId.toString(),
        'name': tcSaveAS.text,
        'house_no': tcHouseNo.text,
        'pincode': tcPincode.text,
        'city': id.toString(),
        'state': tcState.text,
        'is_default': isDefaultInt.toString(),
        'address': tcAddress.text,
        'lat': center!.latitude.toString(),
        'long': center!.longitude.toString(),
        'phone_no': tcPhone.text,
      };
    }

    try {
      final response = await http
          .post(Uri.parse(SERVER_ADDRESS + "$saveAddress"), body: _body);
      if (response.statusCode == 200) {
        final jsonResponse = jsonDecode(response.body);
        if (jsonResponse['status'] == 1) {
          Get.back(result: true);
          Get.snackbar(
            "Success",
            "${jsonResponse['msg']}",
            snackPosition: SnackPosition.BOTTOM,
            backgroundColor: Colors.green,
          );
          isAddingAddress = false;
          update();
        } else {
          Get.snackbar(
            "Error",
            "data not found",
            snackPosition: SnackPosition.BOTTOM,
            backgroundColor: redColor,
          );
          isAddingAddress = false;
          update();
        }
      }
    } catch (e) {
      Get.snackbar(
        "Failed to load Data",
        "Something went wrong. Try again,",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: redColor,
      );
      isAddingAddress = false;
      update();
    }
  }

  void changeCity(String? value) {
    int ind =
        manageCityModel!.data!.indexWhere((element) => element!.name == value);
    id = manageCityModel!.data![ind]!.id!;
    tcCity.text = value!;
    update();
  }
}
