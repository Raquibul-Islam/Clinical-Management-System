import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../Models/family_member_list_model.dart';
import '../Models/user_details_class.dart';
import 'package:http/http.dart' as http;

import '../utils/api.dart';
import '../utils/colors.dart';

enum genderEnum { Male, Female }

class AddFamilyMemberController extends GetxController {
  bool isLoading = true;
  bool isDataNotFound = false;
  bool isSaveLoading = false;
  UserDetailsClass userDetails = UserDetailsClass();

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    init();
  }

  init() async {
    relationController.text = 'Self';
    await getUserDetails();
  }

  getUserDetails() async {
    UserDetailsClass data = await UserDetailsClass().getUserDetails();
    userDetails = data;
    nameController.text = data.name ?? "";
    mobileNumberController.text = data.phone.toString() ?? "";
    emailController.text = data.email ?? "";
  }

  String ageFinal = '';

  TextEditingController nameController = TextEditingController();
  TextEditingController relationController = TextEditingController();
  TextEditingController mobileNumberController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController ageController = TextEditingController();
  TextEditingController dobController = TextEditingController();
  DateTime selectedDate = DateTime.now();
  String selectedGender = 'Male';

  genderEnum? gender = genderEnum.Male;

  setData(Datum data) {
    nameController.text = data.name!;
    relationController.text = data.relation!;
    mobileNumberController.text = data.mobileNo.toString();
    emailController.text = data.email!;
    ageController.text = data.age.toString();
    dobController.text = data.dob!;
    if (data.gender! == 'Male') {
      selectedGender = data.gender!;
      gender = genderEnum.Male;
    } else {
      selectedGender = data.gender!;
      gender = genderEnum.Female;
    }
    // update();
  }

  /// Select Date of Birth
  selectDate(date) {
    selectedDate = date;
    dobController.text =
        '${selectedDate.day}-${selectedDate.month}-${selectedDate.year}';
    update();
  }

  /// Select Gender
  selectGender(value) {
    gender = value;
    if (gender!.index == 0) {
      selectedGender = 'Male';
    } else {
      selectedGender = 'Female';
    }
    update();
  }

  resetForm() {
    nameController.text = '';
    relationController.text = 'Self';
    mobileNumberController.text = '';
    emailController.text = '';
    ageController.text = '';
    dobController.text = '';
    selectedGender = 'Male';
    gender = genderEnum.Male;
    update();
  }

  addNewMember({bool isEdit = false, memberId}) async {
    isSaveLoading = true;
    update();
    var _body;
    if (isEdit) {
      _body = {
        'id': memberId.toString(),
        'user_id': userDetails.userId.toString(),
        'name': nameController.text,
        'mobile_no': mobileNumberController.text,
        'age': ageController.text.split("Your Age is ").last.split(" ").first,
        'email': emailController.text,
        'dob': dobController.text,
        'relation': relationController.text,
        'gender': selectedGender,
      };
    } else {
      _body = {
        'id': 0.toString(),
        'user_id': userDetails.userId.toString(),
        'name': nameController.text,
        'mobile_no': mobileNumberController.text,
        'age': ageController.text.split("Your Age is ").last.split(" ").first,
        'email': emailController.text,
        'dob': dobController.text,
        'relation': relationController.text,
        'gender': selectedGender,
      };
    }

    try {
      final response =
          await http.post(Uri.parse(SERVER_ADDRESS + "$saveMember"), body: _body);
      if (response.statusCode == 200) {
        final jsonResponse = jsonDecode(response.body);
        if (jsonResponse['status'] == 1) {
          Get.back(result: true);
          Get.snackbar(
            "Success",
            "${jsonResponse['msg']}",
            snackPosition: SnackPosition.BOTTOM,
            backgroundColor: Colors.green,
          );
          isSaveLoading = false;
          update();
        } else {
          Get.snackbar(
            "Error",
            "data not found",
            snackPosition: SnackPosition.BOTTOM,
            backgroundColor: redColor,
          );
          isSaveLoading = false;
          update();
          
        }
      }
    } catch (e) {
      Get.snackbar(
        "Failed to load Data",
        "Something went wrong. Try again,",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: redColor,
      );
      isSaveLoading = false;
      update();
    }
  }
}
