import 'dart:convert';

import 'package:get/get.dart';
import 'package:leboratory/Models/categoryModel.dart';
import 'package:leboratory/Models/popularPackageModel.dart';
import 'package:leboratory/utils/api.dart';
import 'package:http/http.dart' as http;
import 'package:leboratory/utils/colors.dart';

class PopularPackageController extends GetxController {
  PopularPackageModel? popularPackageModel;
  bool isLoading = true;
  List<PopularPackageModelList>? popularPackageModelList=[];
  @override
  void onInit() {
    // TODO: implement onInit


    super.onInit();
    // getDoctorDashboardDetail();
    getCategory();
    update();
  }
  Future getCategory() async {
    update();
    try {
      final response = await http.get(Uri.parse(SERVER_ADDRESS + getpopularpackage));
      if (response.statusCode == 200) {
        final jsonResponse = jsonDecode(response.body);
        if (jsonResponse['status'] == 1) {
          popularPackageModel =
              PopularPackageModel.fromJson(jsonResponse);
          // List<CategoryModelList>?  detail = categoryModel!.categoryModelList;
          popularPackageModelList = popularPackageModel!.data;
          isLoading = false;
          update();
          // return categoryModelList;
        } else {
          isLoading = false;
          Get.snackbar(
            "Error",
            "data not found",
            snackPosition: SnackPosition.BOTTOM,
            backgroundColor: redColor,
          );
          update();
          
        }
      }
    }
    catch (e) {
      Get.snackbar(
        "Failed to load Data",
        "Something went wrong. Try again,",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: redColor,
      );
      isLoading = false;
      update();
    }
  }
}