import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../Models/category_detail_model.dart';
import 'package:http/http.dart' as http;

import '../utils/api.dart';
import '../utils/colors.dart';

class CategoryDetailController extends GetxController {
  final id;
  CategoryDetailController(this.id);

  bool isLoading = true;
  bool isListLoading = true;
  int currentPage = 1;
  CategoryDetailModel? categoryDetailModel;
  List<PackageDetailDate>? packageDetail = [];
  ScrollController scrollController = ScrollController();

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    scrollController.addListener(() {
      if (scrollController.position.maxScrollExtent ==
          scrollController.position.pixels) {
        if (isListLoading) {
          getPackageList();
        }
      }
    });
    getPackageList();
  }

  getPackageList() async {
    try {
      final response = await http.get(Uri.parse(SERVER_ADDRESS +
          getCategoryDetail +
          '?cat_id=$id&page=$currentPage'));
      if (response.statusCode == 200) {
        final jsonResponse = jsonDecode(response.body);

        if (jsonResponse['status'] == 1) {
          categoryDetailModel = CategoryDetailModel.fromJson(jsonResponse);
          packageDetail!
              .addAll(categoryDetailModel!.data!.packageDetail!.data!);
          if (categoryDetailModel!.data!.packageDetail!.nextPageUrl == null) {
            isListLoading = false;
          } else {
            currentPage++;
          }
          isLoading = false;
          update();
        } else {
          Get.snackbar(
            "Error",
            "data not found",
            snackPosition: SnackPosition.BOTTOM,
            backgroundColor: redColor,
          );
          isLoading = false;
          isListLoading = false;
          update();
        }
      }
    } catch (e) {
      // Get.snackbar(
      //   "Failed to load Data",
      //   "Something went wrong. Try again,",
      //   snackPosition: SnackPosition.BOTTOM,
      //   backgroundColor: redColor,
      // );
      isLoading = false;
      isListLoading = false;
      update();
    }
  }
}
