import 'dart:convert';

PopularPackageModel popularPackageFromJson(String str) => PopularPackageModel.fromJson(json.decode(str));

String popularPackageToJson(PopularPackageModel data) => json.encode(data.toJson());

class PopularPackageModel {
  PopularPackageModel({
    required this.status,
    required this.msg,
    required this.data,
  });

  int status;
  String msg;
  List<PopularPackageModelList> data;

  factory PopularPackageModel.fromJson(Map<String, dynamic> json) => PopularPackageModel(
    status: json["status"],
    msg: json["msg"],
    data: List<PopularPackageModelList>.from(json["data"].map((x) => PopularPackageModelList.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "msg": msg,
    "data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class PopularPackageModelList {
  PopularPackageModelList({
    required this.id,
    required this.name,
    required this.type,
    required this.typeId,
    this.deletedAt,
    required this.createdAt,
    required this.updatedAt,
    required this.paramaterData,
    required this.noOfParameter,
    required this.mrp,
    required this.price,
    required this.discount,
  });

  int id;
  String name;
  int type;
  int typeId;
  dynamic deletedAt;
  DateTime createdAt;
  DateTime updatedAt;
  List<String> paramaterData;
  int noOfParameter;
  int mrp;
  int price;
  int discount;

  factory PopularPackageModelList.fromJson(Map<String, dynamic> json) => PopularPackageModelList(
    id: json["id"],
    name: json["name"],
    type: json["type"],
    typeId: json["type_id"],
    deletedAt: json["deleted_at"],
    createdAt: DateTime.parse(json["created_at"]),
    updatedAt: DateTime.parse(json["updated_at"]),
    paramaterData: List<String>.from(json["paramater_data"].map((x) => x)),
    noOfParameter: json["no_of_parameter"],
    mrp: json["mrp"],
    price: json["price"],
      discount : json["discount"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "type": type,
    "type_id": typeId,
    "deleted_at": deletedAt,
    "created_at": createdAt.toIso8601String(),
    "updated_at": updatedAt.toIso8601String(),
    "paramater_data": List<dynamic>.from(paramaterData.map((x) => x)),
    "no_of_parameter": noOfParameter,
    "mrp": mrp,
    "price": price,
    "discount": discount,
  };
}

