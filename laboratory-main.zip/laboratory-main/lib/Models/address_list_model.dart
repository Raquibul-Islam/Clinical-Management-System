// To parse this JSON data, do
//
//     final addressListModel = addressListModelFromJson(jsonString);

import 'dart:convert';

AddressListModel addressListModelFromJson(String str) => AddressListModel.fromJson(json.decode(str));

String addressListModelToJson(AddressListModel data) => json.encode(data.toJson());

class AddressListModel {
  AddressListModel({
    this.status,
    this.msg,
    this.data,
  });

  int? status;
  String? msg;
  List<Datum>? data;

  factory AddressListModel.fromJson(Map<String, dynamic> json) => AddressListModel(
    status: json["status"],
    msg: json["msg"],
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "msg": msg,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    this.id,
    this.userId,
    this.name,
    this.houseNo,
    this.pincode,
    this.city,
    this.state,
    this.phone,
    this.isDefault,
    this.createdAt,
    this.updatedAt,
    this.deletedAt,
    this.address,
    this.lat,
    this.long,
  });

  int? id;
  int? userId;
  String? name;
  String? houseNo;
  String? pincode;
  String? city;
  String? state;
  int? phone;
  int? isDefault;
  String? createdAt;
  String? updatedAt;
  String? deletedAt;
  String? address;
  double? lat;
  double? long;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["id"],
    userId: json["user_id"],
    name: json["name"].toString(),
    houseNo: json["house_no"].toString(),
    pincode: json["pincode"].toString(),
    city: json["city"].toString(),
    state: json["state"].toString(),
    phone: json["phone"],
    isDefault: json["is_default"],
    createdAt: json["created_at"],
    updatedAt: json["updated_at"],
    deletedAt: json["deleted_at"],
    address: json["address"],
    lat: json["lat"].toDouble(),
    long: json["long"].toDouble(),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "user_id": userId,
    "name": name,
    "house_no": houseNo,
    "pincode": pincode,
    "city": city,
    "state": state,
    "phone": phone,
    "is_default": isDefault,
    "created_at": createdAt,
    "updated_at": updatedAt,
    "deleted_at": deletedAt,
    "address": address,
    "lat": lat,
    "long": long,
  };
}

// To parse this JSON data, do
//
//     final manageCityModel = manageCityModelFromJson(jsonString);


ManageCityModel? manageCityModelFromJson(String str) => ManageCityModel.fromJson(json.decode(str));

String manageCityModelToJson(ManageCityModel? data) => json.encode(data!.toJson());

class ManageCityModel {
  ManageCityModel({
    this.status,
    this.msg,
    this.data,
  });

  int? status;
  String? msg;
  List<CityList?>? data;

  factory ManageCityModel.fromJson(Map<String, dynamic> json) => ManageCityModel(
    status: json["status"],
    msg: json["msg"],
    data: json["data"] == null ? [] : List<CityList?>.from(json["data"]!.map((x) => CityList.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "msg": msg,
    "data": data == null ? [] : List<dynamic>.from(data!.map((x) => x!.toJson())),
  };
}

class CityList {
  CityList({
    this.id,
    this.name,
  });

  int? id;
  String? name;

  factory CityList.fromJson(Map<String, dynamic> json) => CityList(
    id: json["id"],
    name: json["name"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
  };
}

