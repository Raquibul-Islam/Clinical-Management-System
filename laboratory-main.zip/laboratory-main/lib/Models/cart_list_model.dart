// To parse this JSON data, do
//
//     final cartListModel = cartListModelFromJson(jsonString);

import 'dart:convert';

CartListModel cartListModelFromJson(String str) => CartListModel.fromJson(json.decode(str));

String cartListModelToJson(CartListModel data) => json.encode(data.toJson());

class CartListModel {
  CartListModel({
    this.status,
    this.msg,
    this.data,
  });

  int? status;
  String? msg;
  Data? data;

  factory CartListModel.fromJson(Map<String, dynamic> json) => CartListModel(
    status: json["status"],
    msg: json["msg"],
    data: Data.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "msg": msg,
    "data": data!.toJson(),
  };
}

class Data {
  Data({
    this.cart,
    this.txt,
    this.defaultAddress,
  });

  List<Cart>? cart;
  int? txt;
  dynamic defaultAddress;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    cart: List<Cart>.from(json["cart"].map((x) => Cart.fromJson(x))),
    txt: json["txt"],
    defaultAddress: json["default_address"],
  );

  Map<String, dynamic> toJson() => {
    "cart": List<dynamic>.from(cart!.map((x) => x.toJson())),
    "txt": txt,
    "default_address": defaultAddress,
  };
}

class Cart {
  Cart({
    this.memberId,
    this.memberName,
    this.relation,
    this.gender,
    this.age,
    this.testdata,
  });

  int? memberId;
  String? memberName;
  String? relation;
  String? gender;
  int? age;
  List<Testdatum>? testdata;

  factory Cart.fromJson(Map<String, dynamic> json) => Cart(
    memberId: json["member_id"],
    memberName: json["member_name"],
    relation: json["relation"],
    gender: json["gender"],
    age: json["age"],
    testdata: List<Testdatum>.from(json["testdata"].map((x) => Testdatum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "member_id": memberId,
    "member_name": memberName,
    "relation": relation,
    "gender": gender,
    "age": age,
    "testdata": List<dynamic>.from(testdata!.map((x) => x.toJson())),
  };
}

class Testdatum {
  Testdatum({
    this.testName,
    this.mrp,
    this.price,
    this.parameter,
    this.type,
    this.typeId,
  });

  String? testName;
  int? mrp;
  int? price;
  int? parameter;
  int? type;
  int? typeId;

  factory Testdatum.fromJson(Map<String, dynamic> json) => Testdatum(
    testName: json["test_name"],
    mrp: json["mrp"],
    price: json["price"],
    parameter: json["parameter"],
    type: json["type"],
    typeId: json["type_id"],
  );

  Map<String, dynamic> toJson() => {
    "test_name": testName,
    "mrp": mrp,
    "price": price,
    "parameter": parameter,
    "type": type,
    "type_id": typeId,
  };
}
