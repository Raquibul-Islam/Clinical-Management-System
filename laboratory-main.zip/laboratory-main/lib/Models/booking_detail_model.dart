// To parse this JSON data, do
//
//     final bookingDetailModel = bookingDetailModelFromJson(jsonString);

import 'dart:convert';

BookingDetailModel bookingDetailModelFromJson(String str) =>
    BookingDetailModel.fromJson(json.decode(str));

String bookingDetailModelToJson(BookingDetailModel data) =>
    json.encode(data.toJson());

class BookingDetailModel {
  BookingDetailModel({
    this.status,
    this.msg,
    this.data,
  });

  int? status;
  String? msg;
  Data? data;

  factory BookingDetailModel.fromJson(Map<String, dynamic> json) =>
      BookingDetailModel(
        status: json["status"],
        msg: json["msg"].toString(),
        data: Data.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "status": status,
        "msg": msg,
        "data": data!.toJson(),
      };
}

class Data {
  Data({
    this.id,
    this.userId,
    this.managerId,
    this.feedback,
    this.sampleCollectionAddressId,
    this.date,
    this.time,
    this.paymentMethod,
    this.token,
    this.subtotal,
    this.tax,
    this.finalTotal,
    this.status,
    this.orderplaceDate,
    this.acceptDatetime,
    this.rejectDatetime,
    this.rejectDescription,
    this.refundDatetime,
    this.collectedDatetime,
    this.completeDatetime,
    this.report,
    this.createdAt,
    this.updatedAt,
    this.phone,
    this.orderdata,
    this.useraddressdetails,
  });

  int? id;
  int? userId;
  dynamic managerId;
  int? feedback;
  int? sampleCollectionAddressId;
  DateTime? date;
  String? time;
  String? paymentMethod;
  String? token;
  int? subtotal;
  int? tax;
  int? finalTotal;
  int? status;
  String? orderplaceDate;
  dynamic acceptDatetime;
  dynamic rejectDatetime;
  dynamic rejectDescription;
  dynamic refundDatetime;
  dynamic collectedDatetime;
  dynamic completeDatetime;
  dynamic report;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? phone;
  List<Orderdatum>? orderdata;
  Useraddressdetails? useraddressdetails;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        id: json["id"],
        userId: json["user_id"],
        managerId: json["manager_id"],
        feedback: json["feedback"],
        sampleCollectionAddressId: json["sample_collection_address_id"],
        date: DateTime.parse(json["date"]),
        time: json["time"].toString(),
        paymentMethod: json["payment_method"].toString(),
        token: json["token"].toString(),
        subtotal: json["subtotal"],
        tax: json["tax"],
        finalTotal: json["final_total"],
        status: json["status"],
        // status: 7,
        orderplaceDate: json["orderplace_date"].toString(),
        acceptDatetime: json["accept_datetime"],
        rejectDatetime: json["reject_datetime"],
        rejectDescription: json["reject_description"],
        refundDatetime: json["refund_datetime"],
        collectedDatetime: json["collected_datetime"],
        completeDatetime: json["complete_datetime"],
        report: json["report"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        phone: json["phone"],
        orderdata: List<Orderdatum>.from(
            json["orderdata"].map((x) => Orderdatum.fromJson(x))),
        useraddressdetails: json["useraddressdetails"] == null
            ? null
            : Useraddressdetails.fromJson(json["useraddressdetails"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "user_id": userId,
        "manager_id": managerId,
        "feedback": feedback,
        "sample_collection_address_id": sampleCollectionAddressId,
        "date":
            "${date!.year.toString().padLeft(4, '0')}-${date!.month.toString().padLeft(2, '0')}-${date!.day.toString().padLeft(2, '0')}",
        "time": time,
        "payment_method": paymentMethod,
        "token": token,
        "subtotal": subtotal,
        "tax": tax,
        "final_total": finalTotal,
        "status": status,
        "orderplace_date": orderplaceDate,
        "accept_datetime": acceptDatetime,
        "reject_datetime": rejectDatetime,
        "reject_description": rejectDescription,
        "refund_datetime": refundDatetime,
        "collected_datetime": collectedDatetime,
        "complete_datetime": completeDatetime,
        "report": report,
        "created_at": createdAt!.toIso8601String(),
        "updated_at": updatedAt!.toIso8601String(),
        "phone": phone,
        "orderdata": List<dynamic>.from(orderdata!.map((x) => x.toJson())),
        "useraddressdetails": useraddressdetails!.toJson(),
      };
}

class Orderdatum {
  Orderdatum({
    this.memberId,
    this.memberName,
    this.relation,
    this.gender,
    this.age,
    this.testdata,
  });

  int? memberId;
  String? memberName;
  String? relation;
  String? gender;
  int? age;
  List<Testdatum>? testdata;

  factory Orderdatum.fromJson(Map<String, dynamic> json) => Orderdatum(
        memberId: json["member_id"],
        memberName: json["member_name"].toString(),
        relation: json["relation"].toString(),
        gender: json["gender"].toString(),
        age: json["age"],
        testdata: List<Testdatum>.from(
            json["testdata"].map((x) => Testdatum.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "member_id": memberId,
        "member_name": memberName,
        "relation": relation,
        "gender": gender,
        "age": age,
        "testdata": List<dynamic>.from(testdata!.map((x) => x.toJson())),
      };
}

class Testdatum {
  Testdatum({
    this.testName,
    this.mrp,
    this.price,
    this.parameter,
    this.type,
    this.typeId,
  });

  String? testName;
  int? mrp;
  int? price;
  int? parameter;
  int? type;
  int? typeId;

  factory Testdatum.fromJson(Map<String, dynamic> json) => Testdatum(
        testName: json["test_name"].toString(),
        mrp: json["mrp"],
        price: json["price"],
        parameter: json["parameter"],
        type: json["type"],
        typeId: json["type_id"],
      );

  Map<String, dynamic> toJson() => {
        "test_name": testName,
        "mrp": mrp,
        "price": price,
        "parameter": parameter,
        "type": type,
        "type_id": typeId,
      };
}

class Useraddressdetails {
  Useraddressdetails({
    this.id,
    this.userId,
    this.name,
    this.houseNo,
    this.pincode,
    this.city,
    this.state,
    this.isDefault,
    this.createdAt,
    this.updatedAt,
    this.deletedAt,
    this.address,
    this.lat,
    this.long,
    this.phone,
  });

  int? id;
  int? userId;
  String? name;
  dynamic houseNo;
  String? pincode;
  dynamic city;
  String? state;
  int? isDefault;
  DateTime? createdAt;
  DateTime? updatedAt;
  dynamic deletedAt;
  String? address;
  double? lat;
  double? long;
  int? phone;

  factory Useraddressdetails.fromJson(Map<String, dynamic> json) =>
      Useraddressdetails(
        id: json["id"],
        userId: json["user_id"],
        name: json["name"].toString(),
        houseNo: json["house_no"],
        pincode: json["pincode"].toString(),
        city: json["city"],
        state: json["state"],
        isDefault: json["is_default"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        deletedAt: json["deleted_at"],
        address: json["address"].toString(),
        lat: json["lat"].toDouble(),
        long: json["long"].toDouble(),
        phone: json["phone"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "user_id": userId,
        "name": name,
        "house_no": houseNo,
        "pincode": pincode,
        "city": city,
        "state": state,
        "is_default": isDefault,
        "created_at": createdAt!.toIso8601String(),
        "updated_at": updatedAt!.toIso8601String(),
        "deleted_at": deletedAt,
        "address": address,
        "lat": lat,
        "long": long,
        "phone": phone,
      };
}
