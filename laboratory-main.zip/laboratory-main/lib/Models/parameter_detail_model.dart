// To parse this JSON data, do
//
//     final parameterDetailModel = parameterDetailModelFromJson(jsonString);

import 'dart:convert';

ParameterDetailModel parameterDetailModelFromJson(String str) =>
    ParameterDetailModel.fromJson(json.decode(str));

String parameterDetailModelToJson(ParameterDetailModel data) =>
    json.encode(data.toJson());

class ParameterDetailModel {
  ParameterDetailModel({
    required this.status,
    required this.msg,
    required this.data,
  });

  int status;
  String msg;
  Data data;

  factory ParameterDetailModel.fromJson(Map<String, dynamic> json) =>
      ParameterDetailModel(
        status: json["status"],
        msg: json["msg"],
        data: Data.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "status": status,
        "msg": msg,
        "data": data.toJson(),
      };
}

class Data {
  Data({
    required this.id,
    required this.name,
    required this.categoryId,
    required this.shortDesc,
    required this.description,
    required this.mrp,
    required this.price,
    required this.sampleCollection,
    required this.sampleCollectionFee,
    required this.reportTime,
    required this.fastingTime,
    required this.fastTime,
    required this.testRecommendedFor,
    required this.testRecommendedForAge,
    required this.labReport,
    this.deletedAt,
    required this.createdAt,
    required this.updatedAt,
    required this.frqlist,
    required this.review,
    required this.totalreview,
    this.avgreview,
  });

  int id;
  String name;
  int categoryId;
  String shortDesc;
  String description;
  int mrp;
  int price;
  int sampleCollection;
  dynamic sampleCollectionFee;
  String reportTime;
  int fastingTime;
  dynamic fastTime;
  String testRecommendedFor;
  String testRecommendedForAge;
  String labReport;
  dynamic deletedAt;
  DateTime createdAt;
  DateTime updatedAt;
  List<Frqlist> frqlist;
  // List<dynamic> review;
  List<Review> review;
  int totalreview;
  dynamic avgreview;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        id: json["id"],
        name: json["name"],
        categoryId: json["category_id"],
        shortDesc: json["short_desc"],
        description: json["description"],
        mrp: json["mrp"],
        price: json["price"],
        sampleCollection: json["sample_collection"],
        sampleCollectionFee: json["sample_collection_fee"],
        reportTime: json["report_time"].toString(),
        fastingTime: json["fasting_time"],
        fastTime: json["fast_time"],
        testRecommendedFor: json["test_recommended_for"].toString(),
        testRecommendedForAge: json["test_recommended_for_age"].toString(),
        labReport: json["lab_report"].toString(),
        deletedAt: json["deleted_at"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        frqlist:
            List<Frqlist>.from(json["frqlist"].map((x) => Frqlist.fromJson(x))),
        // review: List<dynamic>.from(json["review"].map((x) => x)),
        review:
            List<Review>.from(json["review"].map((x) => Review.fromJson(x))),
        totalreview: json["totalreview"],
        avgreview: json["avgreview"] ?? '0',
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "category_id": categoryId,
        "short_desc": shortDesc,
        "description": description,
        "mrp": mrp,
        "price": price,
        "sample_collection": sampleCollection,
        "sample_collection_fee": sampleCollectionFee,
        "report_time": reportTime,
        "fasting_time": fastingTime,
        "fast_time": fastTime,
        "test_recommended_for": testRecommendedFor,
        "test_recommended_for_age": testRecommendedForAge,
        "lab_report": labReport,
        "deleted_at": deletedAt,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "frqlist": List<dynamic>.from(frqlist.map((x) => x.toJson())),
        // "review": List<dynamic>.from(review.map((x) => x)),
        "review": List<Review>.from(review.map((x) => x.toJson())),
        "totalreview": totalreview,
        "avgreview": avgreview,
      };
}

class Frqlist {
  Frqlist({
    required this.question,
    required this.ans,
  });

  String question;
  String ans;

  factory Frqlist.fromJson(Map<String, dynamic> json) => Frqlist(
        question: json["question"],
        ans: json["ans"],
      );

  Map<String, dynamic> toJson() => {
        "question": question,
        "ans": ans,
      };
}

class Review {
  Review({
    required this.userId,
    required this.ratting,
    required this.date,
    required this.description,
    required this.username,
    required this.profilePic,
  });

  int userId;
  dynamic ratting;
  String date;
  String description;
  String username;
  String profilePic;

  factory Review.fromJson(Map<String, dynamic> json) => Review(
        userId: json["user_id"],
        ratting: json["ratting"],
        date: json["date"],
        description: json["description"],
        username: json["username"],
        profilePic: json["profile_pic"],
      );

  Map<String, dynamic> toJson() => {
        "user_id": userId,
        "ratting": ratting,
        "date": date,
        "description": description,
        "username": username,
        "profile_pic": profilePic,
      };
}
