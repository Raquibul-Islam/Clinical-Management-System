class ProfileDetailModel {
  int? status;
  String? msg;
  Data? data;

  ProfileDetailModel({this.status, this.msg, this.data});

  ProfileDetailModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    msg = json['msg'];
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['msg'] = this.msg;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  int? id;
  String? name;
  String? shortDesc;
  int? categoryId;
  String? description;
  int? mrp;
  int? price;
  dynamic paramterIncluded;
  String? sampleCollection;
  dynamic sampleCollectionFee;
  String? reportTime;
  String? fastingTime;
  String? fastTime;
  String? testRecommendedFor;
  String? testRecommendedForAge;
  String? realtedPackage;
  String? labReport;
  String? deletedAt;
  String? createdAt;
  String? updatedAt;
  int? noOfParameter;
  List<ParameterList>? parameterList;
  List<Frqlist>? frqlist;
  List<Review>? review;
  String? discount;
  int? totalreview;
  String? avgreview;

  Data(
      {this.id,
      this.name,
      this.shortDesc,
      this.categoryId,
      this.description,
      this.mrp,
      this.price,
      this.paramterIncluded,
      this.sampleCollection,
      this.sampleCollectionFee,
      this.reportTime,
      this.fastingTime,
      this.fastTime,
      this.testRecommendedFor,
      this.testRecommendedForAge,
      this.realtedPackage,
      this.labReport,
      this.deletedAt,
      this.createdAt,
      this.updatedAt,
      this.noOfParameter,
      this.parameterList,
      this.frqlist,
      this.review,
      this.discount,
      this.totalreview,
      this.avgreview});

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    shortDesc = json['short_desc'];
    categoryId = json['category_id'];
    description = json['description'];
    mrp = json['mrp'];
    price = json['price'];
    paramterIncluded = json['paramter_included'];
    sampleCollection = json['sample_collection'];
    sampleCollectionFee = json['sample_collection_fee'];
    reportTime = json['report_time'];
    fastingTime = json['fasting_time'];
    fastTime = json['fast_time'];
    testRecommendedFor = json['test_recommended_for'];
    testRecommendedForAge = json['test_recommended_for_age'];
    realtedPackage = json['realted_package'];
    labReport = json['lab_report'];
    deletedAt = json['deleted_at'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    noOfParameter = json['no_of_parameter'];
    if (json['parameter_list'] != null) {
      parameterList = <ParameterList>[];
      json['parameter_list'].forEach((v) {
        parameterList!.add(new ParameterList.fromJson(v));
      });
    }
    if (json['frqlist'] != null) {
      frqlist = <Frqlist>[];
      json['frqlist'].forEach((v) {
        frqlist!.add(new Frqlist.fromJson(v));
      });
    }
    if (json['review'] != null) {
      review = <Review>[];
      json['review'].forEach((v) {
        review!.add(new Review.fromJson(v));
      });
    }
    discount = json['discount'];
    totalreview = json['totalreview'];
    avgreview = json['avgreview'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['short_desc'] = this.shortDesc;
    data['category_id'] = this.categoryId;
    data['description'] = this.description;
    data['mrp'] = this.mrp;
    data['price'] = this.price;
    data['paramter_included'] = this.paramterIncluded;
    data['sample_collection'] = this.sampleCollection;
    data['sample_collection_fee'] = this.sampleCollectionFee;
    data['report_time'] = this.reportTime;
    data['fasting_time'] = this.fastingTime;
    data['fast_time'] = this.fastTime;
    data['test_recommended_for'] = this.testRecommendedFor;
    data['test_recommended_for_age'] = this.testRecommendedForAge;
    data['realted_package'] = this.realtedPackage;
    data['lab_report'] = this.labReport;
    data['deleted_at'] = this.deletedAt;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['no_of_parameter'] = this.noOfParameter;
    if (this.parameterList != null) {
      data['parameter_list'] =
          this.parameterList!.map((v) => v.toJson()).toList();
    }
    if (this.frqlist != null) {
      data['frqlist'] = this.frqlist!.map((v) => v.toJson()).toList();
    }
    if (this.review != null) {
      data['review'] = this.review!.map((v) => v.toJson()).toList();
    }
    data['discount'] = this.discount;
    data['totalreview'] = this.totalreview;
    data['avgreview'] = this.avgreview;
    return data;
  }
}

class ParameterList {
  String? name;
  int? id;
  String? type;
  List<Parameter>? parameter;

  ParameterList({this.name, this.id, this.type, this.parameter});

  ParameterList.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    id = json['id'];
    type = json['type'];
    if (json['parameter'] != null) {
      parameter = <Parameter>[];
      json['parameter'].forEach((v) {
        parameter!.add(new Parameter.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = this.name;
    data['id'] = this.id;
    data['type'] = this.type;
    if (this.parameter != null) {
      data['parameter'] = this.parameter!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Parameter {
  String? name;
  String? id;

  Parameter({this.name, this.id});

  Parameter.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    id = json['id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = this.name;
    data['id'] = this.id;
    return data;
  }
}

class Frqlist {
  String? question;
  String? ans;

  Frqlist({this.question, this.ans});

  Frqlist.fromJson(Map<String, dynamic> json) {
    question = json['question'];
    ans = json['ans'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['question'] = this.question;
    data['ans'] = this.ans;
    return data;
  }
}

class Review {
  int? userId;
  dynamic ratting;
  String? date;
  String? description;
  String? username;
  String? profilePic;

  Review(
      {this.userId,
      this.ratting,
      this.date,
      this.description,
      this.username,
      this.profilePic});

  Review.fromJson(Map<String, dynamic> json) {
    userId = json['user_id'];
    ratting = json['ratting'];
    date = json['date'];
    description = json['description'];
    username = json['username'];
    profilePic = json['profile_pic'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['user_id'] = this.userId;
    data['ratting'] = this.ratting;
    data['date'] = this.date;
    data['description'] = this.description;
    data['username'] = this.username;
    data['profile_pic'] = this.profilePic;
    return data;
  }
}
