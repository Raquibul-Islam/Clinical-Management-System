// class AppConst{
//   static  bool lan=true;
//   static String LANGUAGE_TYPE = lan ? "en" : 'ar';
// }

const bool lan=true;
String LANGUAGE_TYPE = lan ? "en" : 'ar';

bool kISSTOREAPK = true;
const userId = 'user_id';
const username = 'name';
const userEmail = 'email';
const userPhone = 'phone';
const userProfile = 'profile_pic';