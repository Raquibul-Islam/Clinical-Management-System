import 'dart:io';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../Screens/View/BookScreens/book_details_screen.dart';

class NotificationHelper {
  String? title;
  String? body;
  String? payload;
  String? id;
  String? type;
  FlutterLocalNotificationsPlugin? flutterLocalNotificationsPlugin;

  NotificationHelper() {
    initialize();
  }

  initialize() async {
    flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();
    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('@mipmap/launcher_icon');
    final IOSInitializationSettings initializationSettingsIOS =
        IOSInitializationSettings(
            onDidReceiveLocalNotification: onDidReceiveLocalNotification);

    final InitializationSettings initializationSettings =
        InitializationSettings(
            android: initializationSettingsAndroid,
            iOS: initializationSettingsIOS);
    flutterLocalNotificationsPlugin!.initialize(initializationSettings,
        onSelectNotification: onSelectNotification);

    if (Platform.isAndroid) {
      flutterLocalNotificationsPlugin
          ?.resolvePlatformSpecificImplementation<
              AndroidFlutterLocalNotificationsPlugin>()
          ?.requestPermission();
    }

    await FirebaseMessaging.instance
        .setForegroundNotificationPresentationOptions(
      alert: true,
      badge: true,
      sound: true,
    );
  }

  showNotification({
    String? title,
    String? body,
    String? payload,
    String? id,
  }) async {
    AndroidNotificationDetails androidPlatformChannelSpecifics =
        new AndroidNotificationDetails(
      id!,
      body!,
      importance: Importance.max,
      priority: Priority.high,
      showWhen: true,
    );
    NotificationDetails platformChannelSpecifics =
        NotificationDetails(android: androidPlatformChannelSpecifics);
    // SharedPreferences sharedPreferences=await SharedPreferences.getInstance();
    // //if(sharedPreferences.getString("payload_id").isNotEmpty){}
    // sharedPreferences.setString("payload_id", payload!.split(",")[0]);
    // sharedPreferences.setString("payload_key", payload.split(",")[1]);
    await flutterLocalNotificationsPlugin!
        .show(0, title, body, platformChannelSpecifics, payload: payload);
  }

  Future onSelectNotification(String? payload) async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    sharedPreferences.setString("payload_id", payload!.split(",")[0]);
    sharedPreferences.setString("payload_key", payload.split(",")[1]);
    checkPayload();
  }

  Future<void> checkPayload() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();

    if (sharedPreferences.getString("payload_id") == null) {
    } else if (sharedPreferences.getString("payload_id")!.isNotEmpty) {
      String id = sharedPreferences.getString("payload_id").toString();
      if (sharedPreferences.getString("payload_key").toString() == "Booking") {
        Get.to(BookDetailsScreen(orderId: id));
      } else if (sharedPreferences.getString("payload_key").toString() ==
          "normal") {
        if (sharedPreferences.getString("payload_id")!.isNotEmpty) {
          Get.to(BookDetailsScreen(orderId: id));
          sharedPreferences.setString("payload_id", "");
          sharedPreferences.setString("payload_key", "");
        } else {
          sharedPreferences.setString("payload_id", "");
          sharedPreferences.setString("payload_key", "");
        }
      }
    }
  }

  Future onDidReceiveLocalNotification(
      int? id, String? title, String? body, String? payload) async {
    // display a dialog with the notification details, tap ok to go to another page
    // showDialog(
    //   context: context,
    //   builder: (BuildContext context) => CupertinoAlertDialog(
    //     title: Text(title),
    //     content: Text(body),
    //     actions: [
    //       CupertinoDialogAction(
    //         isDefaultAction: true,
    //         child: Text('Ok'),
    //         onPressed: () async {
    //           Navigator.of(context, rootNavigator: true).pop();
    //           //await Navigator.push(
    //           // context,
    //           // MaterialPageRoute(
    //           //   builder: (context) => SecondScreen(payload),
    //           // ),
    //           //);
    //         },
    //       )
    //     ],
    //   ),
    // );
  }
}
