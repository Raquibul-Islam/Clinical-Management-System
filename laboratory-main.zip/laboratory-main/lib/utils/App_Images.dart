class AppImages{
  static const String imageSERVER_ADDRESS = 'assets/';

  static const String defaultImage = imageSERVER_ADDRESS + 'login/bg.png';

  //package Details
  static const String gridImage1 = imageSERVER_ADDRESS + 'package_detail/parameter.png';
  static const String gridImage2 = imageSERVER_ADDRESS + 'package_detail/free_sample.png';
  static const String gridImage3 = imageSERVER_ADDRESS + 'package_detail/free_doctor.png';
  static const String gridImage4 = imageSERVER_ADDRESS + 'package_detail/booked.png';
  static const String gridImage5 = imageSERVER_ADDRESS + 'package_detail/report_time.png';
  static const String gridImage6 = imageSERVER_ADDRESS + 'package_detail/fasting_time.png';
  static const String gridImage7 = imageSERVER_ADDRESS + 'package_detail/test_recommended.png';
  static const String gridImage8 = imageSERVER_ADDRESS + 'package_detail/recommended_for_age.png';
}