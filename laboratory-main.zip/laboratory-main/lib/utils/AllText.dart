//onBordingScreen.dart
Map Skip = {
  'en': 'Skip',
  // 'ar': 'قابل الطبيب',
};
Map Need_A_Doctor = {
  'en': 'Need A Doctor',
  // 'ar': 'قابل الطبيب',
};
Map Need_A_Doctor_Des = {
  'en':
      "HomeCare's doctor at home service provides\nExpert care for you and family that\nencompassesDay-to-day health needs as well\nas long term assistance",
};

Map Health_Advice = {
  'en': 'Health Advice',
};

Map Health_Advice_Des = {
  'en':
      "Everyday Health inspires and empowers\nPeople to live healthiest lives,every day,\nThrough trusted, medically reviewed\ninformation and expert. ",
};

Map Home_Service = {
  'en': '24 X 7 Home Services',
};

Map Home_Service_Des = {
  'en':
      "We provide low cost ambulance service with\nComplete ICU Backup, advance life support.\nFully Medical equipped 100% sanitised\nAmbulance Available at Your Doorstep!",
};

//LoginScreen

Map Welcome_Back = {
  'en': 'Welcome Back',
};

Map Login_Continue = {
  'en': 'Login in to Continue',
};

Map Email_Address = {
  'en': 'Email Address',
};

Map Enter_Email_Address = {
  'en': 'Enter Email Address',
};

Map Password = {
  'en': 'Password',
};

Map Enter_Password = {
  'en': 'Enter Password',
};

Map Remember = {
  'en': 'Remember',
};

Map Forgot_Password = {
  'en': 'Forgot Password?',
};

Map Login = {
  'en': 'Login',
};

Map Or = {
  'en': 'Or',
};

Map Dont_Have_Account = {
  'en': "Don't have an account?",
};

Map Register_Now = {
  'en': "Register Now",
};

Map Valid_Email = {
  'en': "Please Enter valid Email Address",
};

Map Valid_Password = {
  'en': "Please Enter valid Password",
};

Map emailValidationText = {
  'en': "Email Address can't be empty",
  // 'ar': 'لا يمكن أن يكون رقم الهاتف فارغًا',
};

//RegisterScreen

Map RegisterSubText = {
  'en': 'Please enter info to create account',
};

Map Name = {
  'en': 'Name',
};

Map Enter_Name = {
  'en': 'Enter Name',
};

Map Email = {
  'en': 'Email',
};

Map Phone_Number = {
  'en': 'Phone Number',
};

Map Enter_Phone_Number = {
  'en': 'Enter Phone Number',
};

Map Confirm_Password = {
  'en': 'Confirm Password',
};

Map Confirm_Enter_Password = {
  'en': 'Enter Confirm Password',
};

Map Register = {
  'en': 'Register',
};

Map Already_Have_Account = {
  'en': 'Already have a account?',
};

//Page Widget

Map Home = {
  'en': 'Home',
};

Map CartTxt = {
  'en': 'Cart',
};

Map Chat = {
  'en': 'Chat',
};

Map Profile = {
  'en': 'Profile',
};

//HomeScreen

Map Home_Welcome_Back = {
  'en': 'Welcome back!',
};

Map What_Are_You_Looking = {
  'en': 'What are you looking for?',
};

Map YES = {
  'en': 'Yes',
};

Map NO = {
  'en': 'No',
};

Map DO_YOU_WANT_TO_EXIT = {
  'en': 'Do you want to exit?',
};

Map Search = {
  'en': 'Search',
};

Map Laboratory_Package = {
  'en': 'Laboratory Package',
};

Map Laboratory_Package_Sub_Text = {
  'en':
      'Collection,strong,packaging,transport.All specimens  collected for laboratory investigation should be regarded as.',
};

Map Popular_Package = {
  'en': 'Popular Package',
};

Map Anaemia = {
  'en': 'Anaemia',
};

Map Anaemia_Des = {
  'en': 'Iron Deficiency anaemia',
};

Map Thyroid = {
  'en': 'Thyroid',
};

Map Thyroid_Des = {
  'en': 'Thyroid and its Diseases',
};

Map Bone = {
  'en': 'Bone',
};

Map Bone_Des = {
  'en': 'A Bone is a rigid tissue',
};

Map Obesity = {
  'en': 'Obesity',
};

Map Obesity_Des = {
  'en': 'Bariatric Endocrinology',
};

Map Acidity = {
  'en': 'Acidity',
};

Map Acidity_Des = {
  'en': 'The acid in the stomach',
};

Map Diabetes = {
  'en': 'Diabetes',
};

Map Diabetes_Des = {
  'en': 'Diabetes disease occurs',
};

//Popular Package

Map Popular_package = {
  'en': 'Popular Package',
};

Map View_Detail = {
  'en': 'View Detail',
};

//PackageDetailScreen

Map Package_Detail = {
  'en': 'Package Detail',
};

Map Book_Now = {
  'en': 'Book Now',
};

Map Test_Details = {
  'en': 'Test Details',
};

Map View1 = {
  'en': 'View',
};

Map Paramter_Included = {
  'en': 'paramter included',
};

Map Price = {
  'en': 'Price',
};

Map Sample_Collection = {
  'en': 'Sample Collection',
};

Map Doctor_Con_Fee = {
  'en': 'Doctor Consultation Fee',
};

Map Test_Booked = {
  'en': 'Test Booked',
};

Map Report_Time = {
  'en': 'Report Time',
};

Map Fasting_Time = {
  'en': 'Fasting Time',
};

Map Test_Recommanded = {
  'en': 'Test Recommended',
};

Map Recommended_Age = {
  'en': 'Recommended age',
};

Map Error = {
  'en': 'Error',
};

Map Error_Msg = {
  'en': 'Storage Permission isDenied',
};

Map Ok = {
  'en': 'Ok',
};

///----- Mahi --------------------------------------------------
///-========= profile and edit profile screen ===============
Map Edit_Profile = {
  'en': 'Edit Profile',
};

Map Book_List = {
  'en': 'Book List',
};

Map Family_Member_List = {
  'en': 'Family Member List',
};

Map Address_List = {
  'en': 'Address List',
};

Map LogOut = {
  'en': 'Logout',
};
Map ALERT = {
  'en': "Alert!",
};
Map ARE_YOU_SURE_LOGOUT_FROM_LABORATORY_APP = {
  'en': "Are you sure to logout from laboratory App ?",
};

Map YES_PROCEED = {
  'en': "Yes, proceed",
};

Map NO_WAIT = {
  'en': "No, wait",
};
Map Save = {
  'en': "Save",
};

Map Update = {
  'en': "Update",
};

///============== book list screen ====================

Map All = {
  'en': "All",
};

Map Pending = {
  'en': "Pending",
};

Map Rejected = {
  'en': "Rejected",
};

Map BOOK_ID = {
  'en': "Book ID: ",
};

Map PAYMENT_TYPE = {
  'en': "Payment type: ",
};

Map PENDING = {
  'en': "Pending",
};

Map COMPLATE = {
  'en': "Complate",
};

Map REJECT = {
  'en': "Rejected",
};

///=========== login screen ======================
const Map LOGGING_IN = {
  'en': "Logging in..",
  // 'hi': 'प्रवेश किया..',
  // 'ar': 'تسجيل الدخول..',
};
const Map PLEASE_WAIT_WHIlE_LOGGING_IN = {
  'en': "Please wait while Logging in",
  // 'hi': 'लॉग इन करते समय कृपया प्रतीक्षा करें',
  // 'ar': 'يرجى الانتظار أثناء تسجيل الدخول',
};

const Map OOPS_ERROR = {
  'en': "Oops! An Error Occurred.",
  // 'hi': 'उफ़! एक त्रुटि पाई गई',
  // 'ar': 'أُووبس! حدث خطأ.',
};
const Map PLEASE_TRY_AFTER_SOME_TIME = {
  'en': "Please try after some time.",
  // 'hi': 'कृपया कुछ देर बाद प्रयास करें',
  // 'ar': 'يرجى المحاولة بعد مرور بعض الوقت.',
};
const Map OK = {
  'en': "OK",
  // 'hi': 'ठीक है',
  // 'ar': 'نعم',
};

///============== edit profile =============

const Map UPDATING = {
  'en': "Updating",
  // 'hi': 'अद्यतन करने',
  // 'ar': 'التحديث',
};

const Map PLEASE_WAIT_WHILE_UPDATING_PROFILE = {
  'en': "Please wait while updating profile",
  // 'hi': 'कृपया प्रोफ़ाइल अपडेट करते समय प्रतीक्षा करें',
  // 'ar': 'يرجى الانتظار أثناء تحديث الملف الشخصي',
};

const Map IMAGE_PATH_CANNOT_BE_EMPTY = {
  'en': "Please select image to continue",
  // 'hi': 'जारी रखने के लिए कृपया छवि का चयन करें',
  // 'ar': 'الرجاء تحديد الصورة للمتابعة',
};

const Map SUCCESSFUL = {
  'en': "Successful",
  'hi': 'सफल',
  'ar': 'ناجح',
};

///============== Address List =============

const Map ADDRESS_LIST = {
  'en': "Address List",
  'hi': 'Address List',
  'ar': 'Address List',
};

const Map ADD_ADDRESS = {
  'en': "Add Address",
  'hi': 'Add Address',
  'ar': 'Add Address',
};

const Map EDIT_ADDRESS = {
  'en': "Update Address",
  'hi': 'Update Address',
  'ar': 'Update Address',
};

Map Location_Services_Disabled = {
  'en': "Location services are disabled.",
  'ar': 'خدمات الموقع معطلة.',
};

Map Location_Permissions_Denied = {
  'en': "Location permissions are denied",
  'ar': 'تم رفض أذونات الموقع',
};

Map Location_Permissions_Permanently_Denied = {
  'en':
      "Location permissions are permanently denied, we cannot request permissions.",
  'ar': 'أذونات الموقع مرفوضة بشكل دائم ، ولا يمكننا طلب أذونات.',
};

Map Give_Location_Permission = {
  'en': "Give location permission",
  'ar': 'إعطاء إذن الموقع',
};

Map Retry = {
  'en': "Retry",
  'ar': 'أعد المحاولة',
};

Map Open_Setting = {
  'en': "Open Setting",
  'ar': 'بيئة مفتوحة',
};

Map Your_Location = {
  'en': "Your location",
  'ar': 'Your location',
};

///============== Family Member List =============

const Map FAMILY_MEMBER_LIST = {
  'en': "Family Member List",
  'hi': 'Family Member List',
  'ar': 'AFamily Member List',
};

const Map ADD_MEMBER = {
  'en': "Add Member",
  'hi': 'Add Member',
  'ar': 'Add Member',
};

///============== Add New Family Member =============

const Map ADD_NEW_FAMILY_MEMBER = {
  'en': "Add New Family Member",
  'hi': 'Add New Family Member',
  'ar': 'Add New Family Member',
};

const Map EDIT_NEW_FAMILY_MEMBER = {
  'en': "Edit New Family Member",
  'hi': 'Edit New Family Member',
  'ar': 'Edit New Family Member',
};

const Map MOBILE_NO = {
  'en': "Mobile Number",
  'hi': 'Mobile Number',
  'ar': 'Mobile Number',
};

const Map RELATION = {
  'en': "Relation",
  'hi': 'Relation',
  'ar': 'Relation',
};

const Map GENDER = {
  'en': "Gender",
  'hi': 'Gender',
  'ar': 'Gender',
};

const Map AGE = {
  'en': "Age",
  'hi': 'Age',
  'ar': 'Age',
};

const Map DOB = {
  'en': "Date Of Birth",
  'hi': 'Date Of Birth',
  'ar': 'Date Of Birth',
};

const Map CANCEL = {
  'en': "Cancel",
  'hi': 'Cancel',
  'ar': 'Cancel',
};

const Map HINT_NAME = {
  'en': "Enter Name",
  'hi': 'Enter Name',
  'ar': 'Enter Name',
};

const Map HINT_RELATION = {
  'en': "Relation",
  'hi': 'Relation',
  'ar': 'Relation',
};

const Map HINT_PHONE = {
  'en': "Enter Mobile Number",
  'hi': 'Enter Mobile Number',
  'ar': 'Enter Mobile Number',
};

const Map HINT_EMAIL = {
  'en': "Enter Email",
  'hi': 'Enter Email',
  'ar': 'Enter Email',
};

const Map HINT_AGE = {
  'en': "Enter Age",
  'hi': 'Enter Age',
  'ar': 'Enter Age',
};

const Map MALE = {
  'en': "Male",
  'hi': 'Male',
  'ar': 'Male',
};

const Map FEMALE = {
  'en': "Female",
  'hi': 'Female',
  'ar': 'Female',
};

///============== Cart Detail =============

const Map CART_DETAIL = {
  'en': "Cart Detail",
  'hi': 'Cart Detail',
  'ar': 'Cart Detail',
};

const Map CHECKOUT = {
  'en': "Checkout",
  'hi': 'Checkout',
  'ar': 'Checkout',
};

const Map BOOK_NOW = {
  'en': "Book Now",
  'hi': 'Book Now',
  'ar': 'Book Now',
};

const Map TRACK_ORDER = {
  'en': "Track Order",
};

const Map BACK_TO_SHOP = {
  'en': "Back to shop",
};

const Map ORDER_SUCCESS_MSG2 = {
  'en': "Your items has been placed and\nis on it’s way to being\nproceed",
};

const Map SAVE = {
  'en': "Save",
  'hi': 'Save',
  'ar': 'Save',
};

const Map PARAMETERS_INCLUDED = {
  'en': "Parameters Included :",
  'hi': 'Parameters Included :',
  'ar': 'Parameters Included :',
};

const Map EMPTY_CART = {
  'en': "Cart is empty",
  'hi': 'Cart is empty',
  'ar': 'Cart is empty',
};

///============== Collect Address =============

const Map COLLECT_ADDRESS = {
  'en': "Collect Address",
  'hi': 'Collect Address',
  'ar': 'Collect Address',
};

const Map COLLECT_TO_THIS_ADDRESS = {
  'en': "Sample collect from above address",
  'hi': 'Sample collect from above address',
  'ar': 'Sample collect from above address',
};

const Map SELECT_ADDRESS = {
  'en': "Select Address",
  'hi': 'Select Address',
  'ar': 'Select Address',
};

const Map ADD_ADDRESS_ADD = {
  'en': "+ Add Address",
  'hi': '+ Add Address',
  'ar': '+ Add Address',
};

const Map DEFAULT = {
  'en': "Default",
  'hi': 'Default',
  'ar': 'Default',
};

///============== Collect Address =============

const Map FORGOT_PASSWORD = {
  'en': "Forgot Password",
  'hi': 'Forgot Password',
  'ar': 'Forgot Password',
};

const Map FORGOT_PASSWORD_DES = {
  'en': "Enter your email and will send you instruction on how reset it",
  'hi': 'Enter your email and will send you instruction on how reset it',
  'ar': 'Enter your email and will send you instruction on how reset it',
};

const Map SEND = {
  'en': "Send",
  'hi': 'Send',
  'ar': 'Send',
};

///============== Member List =============

const Map MEMBERS_LIST = {
  'en': "Members List",
  'hi': 'Members List',
  'ar': 'Members List',
};

const Map ADD_TO_CART = {
  'en': "Add to cart",
  'hi': 'Add to cart',
  'ar': 'Add to cart',
};

///============== Pamereter Details =============

const Map PARAMETER_DETAILS = {
  'en': "Parameter Details",
  'hi': 'Parameter Details',
  'ar': 'Parameter Details',
};

///============== Profile Details =============

const Map PROFILE_DETAILS = {
  'en': "Profile Details",
  'hi': 'Profile Details',
  'ar': 'Profile Details',
};

const Map OVERVIEW = {
  'en': "Overview",
  'hi': 'Overview',
  'ar': 'Overview',
};

const Map FRQ = {
  'en': "FAQ",
  'hi': 'FAQ',
  'ar': 'FAQ',
};

const Map REVIEWS = {
  'en': "Reviews",
  'hi': 'Reviews',
  'ar': 'Reviews',
};

///============== Book Details =============

const Map BOOK_DETAILS = {
  'en': "Book Details",
  'hi': 'Book Details',
  'ar': 'Book Details',
};

const Map FEEDBACK = {
  'en': "Feedback",
  'hi': 'Feedback',
  'ar': 'Feedback',
};

const Map REPORT = {
  'en': "View Reports",
  'hi': 'View Reports',
  'ar': 'View Reports',
};

const Map PLACED_ON = {
  'en': "Placed on",
  'hi': 'Placed on',
  'ar': 'Placed on',
};

const Map PAID_BY = {
  'en': "Paid by",
  'hi': 'Paid by',
  'ar': 'Paid by',
};

///============== Total Cart Details =============

const Map SUBTOTAL = {
  'en': "Sub Total",
  'hi': 'Sub Total',
  'ar': 'Sub Total',
};

const Map Txt = {
  'en': "Tax",
  'hi': 'Tax',
  'ar': 'Tax',
};

const Map TOTAL = {
  'en': "Total",
  'hi': 'Total',
  'ar': 'Total',
};

const Map SAVING_DES = {
  'en': "Your total saving on this health booking",
  'hi': 'Your total saving on this health booking',
  'ar': 'Your total saving on this health booking',
};

///============== Checkout Screen =============

const Map SELECT_TIME_DATE = {
  'en': "Select Date & Time",
  'hi': 'Select Date & Time',
  'ar': 'Select Date & Time',
};

const Map PAYMENT_OPTION = {
  'en': "Payment Option",
  'hi': 'Payment Option',
  'ar': 'Payment Option',
};
//
// const Map COD = {
//   'en': "Cash On Delivery",
//   'hi': 'Cash On Delivery',
//   'ar': 'Cash On Delivery',
// };
//
// const Map BRAINTREE_STR = {
//   'en': "Braintree",
//   'hi': 'Braintree',
//   'ar': 'Braintree',
// };
//
// const Map PAYSTACK_STR = {
//   'en': "Paystack",
//   'hi': 'Paystack',
//   'ar': 'Paystack',
// };
//
// const Map STRIPE_STR = {
//   'en': "Stripe",
//   'hi': 'Stripe',
//   'ar': 'Stripe',
// };

const Map COLLECTION_ADDRESS = {
  'en': "Collection Address",
  'hi': 'Collection Address',
  'ar': 'Collection Address',
};

const Map SELECT_ADDRESS_ADD = {
  'en': "+ Select Address",
  'hi': '+ Select Address',
  'ar': '+ Select Address',
};

const Map MOBILE = {
  'en': "Mobile: ",
  'hi': 'Mobile: ',
  'ar': 'Mobile: ',
};

/// No Data

const Map NO_DATA = {
  'en': "No Data Found",
  'hi': 'No Data Found',
  'ar': 'No Data Found',
};

/// Category Detail

const Map CATEGORY_DETAIL = {
  'en': "Detail",
  'hi': 'Detail',
  'ar': 'Detail',
};

/// Add Address Screen
const Map ADDRESS = {
  'en': "Address",
  'hi': 'Address',
  'ar': 'Address',
};

const Map HOUSENO = {
  'en': "House No",
  'hi': 'House No',
  'ar': 'House No',
};

const Map STATE = {
  'en': "State",
  'hi': 'State',
  'ar': 'State',
};

const Map PINCODE = {
  'en': "Pincode",
  'hi': 'Pincode',
  'ar': 'Pincode',
};

const Map CITY = {
  'en': "City",
  'hi': 'City',
  'ar': 'City',
};

const Map PHONE = {
  'en': "Phone Number",
  'hi': 'Phone Number',
  'ar': 'Phone Number',
};

const Map SAVEAS = {
  'en': "Save as",
  'hi': 'Save as',
  'ar': 'Save as',
};

const Map YOU_ARE_NOT_LOGGED_IN_YET = {
  'en': "You are not logged in yet",
};

const Map PLEASE_LOGIN_REGISTER = {
  'en': "please login or register to check your cart,",
};

const Map PLEASE_LOGIN_REGISTER_1 = {
  'en': "please login or register,",
};

const Map LOGIN_NOW = {
  'en': "Login Now",
};

const Map PLEASE_WAIT_WHILE_DELETING_ACCOUNT = {
  'en': "Please wait while deleting your account",
};

Map Delete_Account = {
  'en': 'Delete Account',
};
Map Confirmation = {
  'en': 'Confirmation',
};
Map Delete_Account_Msg = {
  'en': 'Are you want to Delete Account?',
};
Map LOADING = {
  'en': 'Loading',
};
