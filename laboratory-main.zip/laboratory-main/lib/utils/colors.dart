import 'package:flutter/material.dart';

const themeColor = Color(0xffd70044);
const themeSecondaryColor = Color(0xffdde6ed);
const whiteColor = Colors.white;
const redColor = Colors.red;
const blackColor = Colors.black;
const starColor = Color(0xffff8b2d);
const subTextColor = Color(0xff979798);
const containerBackGoundColor = Color(0xffdbe4ec);
const darkBlue = Color(0xff1a2e3d);
//219,228,236

MaterialColor primarySwatch = MaterialColor(0xffd70044, color);

Map<int, Color> color = {
  50: const Color.fromRGBO(27, 127, 237, .1),
  100: const Color.fromRGBO(27, 127, 237, .2),
  200: const Color.fromRGBO(27, 127, 237, .3),
  300: const Color.fromRGBO(27, 127, 237, .4),
  400: const Color.fromRGBO(27, 127, 237, .5),
  500: const Color.fromRGBO(27, 127, 237, .6),
  600: const Color.fromRGBO(27, 127, 237, .7),
  700: const Color.fromRGBO(27, 127, 237, .8),
  800: const Color.fromRGBO(27, 127, 237, .9),
  900: const Color.fromRGBO(27, 127, 237, 1),
};