// const SERVER_ADDRESS = "http://diagnobay.me/lab/api/";
// const SERVER_ADDRESS = "https://generadubai.com/lab/api/";
const SERVER_ADDRESS = "https://demo.freaktemplate.com/laboratory/api/";
String pdfPath =
    "${SERVER_ADDRESS.split("api/").first}storage/app/public/sample_report/";
String PROFILE_IMAGE_PATH =
    "${SERVER_ADDRESS.split("api/").first}storage/app/public/profile/";

String SUCCESS_PAYMENT_URL =
    "${SERVER_ADDRESS.split("api/").first}payment_success";
String FAIL_PAYMENT_URL = "${SERVER_ADDRESS.split("api/").first}payment-failed";

String ReportPath =
    '${SERVER_ADDRESS.split("api/").first}storage/app/public/report/';

const getcategory = "getcategory";
const getpopularpackage = "get_popular_package_list";
const getpackagedetail = "package_detail";
const getParameterDetail = "parameter_detail";
const getProfileDetail = "profile_detail";
const getBookList = "book_filter";
const getMemberList = "get_member_list";
const getCategoryDetail = "category_detail";
const getCartList = "get_cart";
const updateCart = "update_cart";
const getAddress = "getaddress";
const bookNowApi = "booknow";
const updaetCart = "update_cart";
const saveAddress = "saveaddress";
const saveMember = "save_member";
const deleteMemberApi = "delete_member";
const getBookDetailApi = "book_detail";
const addFeedBack = "add_feedback";
const searchCategory = "serach_category";
const getCity = "get_city";
const userLogin = "login";
const userRegister = "register";
const editProfile = "edit_profile";
const saveToken = "savetoken";
const deleteUser = "delete_user";
