import 'dart:convert';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:leboratory/Models/user_details_class.dart';
import 'package:leboratory/Screens/Custome_Widgets/custom_dialogue.dart';
import 'package:leboratory/Screens/Custome_Widgets/custome_widget.dart';
import 'package:leboratory/Screens/View/AuthScreen/login_screen.dart';
import 'package:leboratory/componant/custome_appBar.dart';
import 'package:leboratory/utils/colors.dart';
import '../../../utils/AllText.dart';
import '../../../utils/api.dart';
import '../../../utils/strings.dart';
import '../../Custome_Widgets/page_widget.dart';
import '../AddressListScreen/address_list_screen.dart';
import '../BookScreens/book_list_screen.dart';
import '../FamilyMemberListScreen/family_member_list_screen.dart';
import 'edit_profile_screen.dart';
import 'package:http/http.dart' as http;

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  // String? name;
  // String? email;
  // String? profile;
  bool isLoading = true;
  UserDetailsClass userDetails = UserDetailsClass();

  ///----- options list ----
  List<Options> options = [
    Options(
        name: Edit_Profile,
        widget: Container(),
        imagePath: "assets/profile/edit.png",
        type: 0),
    Options(
        name: Book_List,
        widget: Container(),
        imagePath: "assets/profile/booklist.png",
        type: 1,
        padding: 3),
    Options(
        name: Family_Member_List,
        widget: Container(),
        imagePath: "assets/profile/memberlist.png",
        type: 2,
        padding: 3),
    Options(
        name: Address_List,
        widget: Container(),
        imagePath: "assets/profile/addresslist.png",
        type: 3,
        padding: 3),
    Options(
        name: Delete_Account,
        widget: Container(),
        imagePath: "assets/profile/profile-delete.png",
        type: 5,
        padding: 3),
    Options(name: LogOut, imagePath: "assets/profile/logout.png", type: 4),
  ];

  // data()  {
  //   setState(() async {
  //     final prefs = await SharedPreferences.getInstance();
  //
  //     await prefs.getInt(userId);
  //     name= prefs.getString(username);
  //     email= prefs.getString(useremail);
  //     profile= prefs.getString(userprofile);
  //   });
  //
  // }
  // @override
  // void initState() {
  //   // TODO: implement initState
  //   data();
  //   super.initState();
  //
  //
  // }

  @override
  void initState() {
    super.initState();
    getUserDetails();
  }

  getUserDetails() async {
    UserDetailsClass data = await UserDetailsClass().getUserDetails();
    setState(() {
      userDetails = data;
    });
    setState(() {
      isLoading = false;
    });
  }

  deleteAccount() async {
    Navigator.pop(context);
    showLoadingMsg(
      context: context,
      msg: PLEASE_WAIT_WHILE_DELETING_ACCOUNT,
      title: LOADING,
    );

    var request =
        http.MultipartRequest('POST', Uri.parse(SERVER_ADDRESS + deleteUser));

    request.fields.addAll({
      'id': '${userDetails.userId}',
    });

    http.StreamedResponse response = await request.send().catchError((e) {
      showCustomDialog(
          context: context,
          title: SUCCESSFUL,
          msg: e.toString(),
          btnYesText: OK,
          onPressedBtnYes: () {
            Navigator.pop(context);
          });
    });

    if (response.statusCode == 200) {
      final jsonResponse = jsonDecode(await response.stream.bytesToString());
      if (jsonResponse['status'] == 1) {
        await userDetails.removeAllUserDetails();
        Navigator.popUntil(context, (route) => route.isFirst);

        Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (context) => PagesWidget()));
      } else {
        Navigator.pop(context);
        showCustomDialog(
            context: context,
            title: ALERT,
            msg: jsonResponse['msg'],
            btnYesText: OK,
            onPressedBtnYes: () {
              Navigator.pop(context);
            });
      }
    } else {
      Navigator.pop(context);
      showCustomDialog(
          context: context,
          title: SUCCESSFUL,
          msg: response.reasonPhrase,
          btnYesText: OK,
          onPressedBtnYes: () {
            Navigator.pop(context);
          });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: themeSecondaryColor,
      //
      // ///------ appbar ------
      // appBar: customeAppBar(
      //   Profile[LANGUAGE_TYPE],
      //   false,false
      // ),

      ///------ body view -----
      body: body(),
    );
  }

  body() {
    return Column(
      children: [
        CustomAppBar(
          title: Profile[LANGUAGE_TYPE],
          isArrow: false,
          isAction: false,
        ),
        Expanded(
          child: isLoading
              ? Center(
                  child: CircularProgressIndicator(
                    color: themeColor,
                  ),
                )
              : userDetails.isLoggedIn == false
                  ? Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 10.0),
                          child:
                              Image.asset("assets/profile/account_logout.png"),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        semiBoldText(
                            text: YOU_ARE_NOT_LOGGED_IN_YET[LANGUAGE_TYPE],
                            color: blackColor,
                            size: 28),
                        SizedBox(
                          height: 10,
                        ),
                        GestureDetector(
                          onTap: () {
                            Get.to(() => LoginScreen());
                          },
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              regularText(
                                  text: PLEASE_LOGIN_REGISTER_1[LANGUAGE_TYPE],
                                  color: subTextColor,
                                  size: 16),
                              SizedBox(
                                width: 3,
                              ),
                              semiBoldText(
                                  text: LOGIN_NOW[LANGUAGE_TYPE],
                                  color: themeColor,
                                  size: 17),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: Get.height * 0.15,
                        )
                      ],
                    )
                  // Center(
                  //             child: customeElevatedButton(
                  //               200,
                  //               Login[LANGUAGE_TYPE],
                  //               callback: () {
                  //                 Get.to(() => LoginScreen());
                  //               },
                  //             ),
                  //           )
                  : SingleChildScrollView(
                      // physics: BouncingScrollPhysics(),
                      child: Column(
                        children: [
                          Container(
                            height: 250,
                            decoration: const BoxDecoration(
                              image: DecorationImage(
                                image: AssetImage(
                                  "assets/login/bg.png",
                                ),
                                fit: BoxFit.fill,
                              ),
                            ),
                            child: Center(
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  SizedBox(
                                    height: 30,
                                  ),

                                  ///----- user image -----
                                  // userDetails.profile.toString() == "null" &&
                                  //         userDetails.profile.toString().isEmpty
                                  //     ? ClipRRect(
                                  //         borderRadius:
                                  //             BorderRadius.circular(50),
                                  //         child: Container(
                                  //           height: 120,
                                  //           width: 120,
                                  //           decoration: BoxDecoration(
                                  //               border: Border.all(
                                  //                   color: Colors.white,
                                  //                   width: 2),
                                  //               shape: BoxShape.circle,
                                  //               image: DecorationImage(
                                  //                   image: AssetImage(
                                  //                     "assets/home/profile.png",
                                  //                   ),
                                  //                   fit: BoxFit.cover)),
                                  //         ),
                                  //       )
                                  //     : ClipRRect(
                                  //         borderRadius:
                                  //             BorderRadius.circular(10),
                                  //         child: Container(
                                  //           height: 120,
                                  //           width: 120,
                                  //           decoration: BoxDecoration(
                                  //               border: Border.all(
                                  //                   color: Colors.white,
                                  //                   width: 2),
                                  //               shape: BoxShape.circle,
                                  //               image: DecorationImage(
                                  //                 fit: BoxFit.cover,
                                  //                 image:
                                  //                     CachedNetworkImageProvider(
                                  //                   (PROFILE_IMAGE_PATH +
                                  //                               userDetails
                                  //                                   .profile
                                  //                                   .toString())
                                  //                           .contains(
                                  //                               PROFILE_IMAGE_PATH)
                                  //                       ? userDetails.profile
                                  //                           .toString()
                                  //                       : PROFILE_IMAGE_PATH +
                                  //                           userDetails.profile
                                  //                               .toString(),
                                  //                 ),
                                  //                 // CachedNetworkImage(
                                  //                 //   imageUrl:
                                  //                 //   userDetails.profile.toString(),
                                  //                 //   fit: BoxFit.cover,
                                  //                 //
                                  //                 //
                                  //                 //   // placeholder: (context, err){
                                  //                 //   //   return placeHolder(
                                  //                 //   //     isProfile: false,
                                  //                 //   //     height: double.maxFinite,
                                  //                 //   //     width: double.maxFinite,
                                  //                 //   //   );
                                  //                 //   // },
                                  //                 //   // errorWidget: (context, err, reason){
                                  //                 //   //   return placeHolder(
                                  //                 //   //     isProfile: false,
                                  //                 //   //     height: double.maxFinite,
                                  //                 //   //     width: double.maxFinite,
                                  //                 //   //   );
                                  //                 //   // },
                                  //                 // ),
                                  //               )),
                                  //           // child: CachedNetworkImage(
                                  //           //   imageUrl:
                                  //           //   userDetails.profile.toString(),
                                  //           //   fit: BoxFit.cover,
                                  //           //
                                  //           //
                                  //           //   // placeholder: (context, err){
                                  //           //   //   return placeHolder(
                                  //           //   //     isProfile: false,
                                  //           //   //     height: double.maxFinite,
                                  //           //   //     width: double.maxFinite,
                                  //           //   //   );
                                  //           //   // },
                                  //           //   // errorWidget: (context, err, reason){
                                  //           //   //   return placeHolder(
                                  //           //   //     isProfile: false,
                                  //           //   //     height: double.maxFinite,
                                  //           //   //     width: double.maxFinite,
                                  //           //   //   );
                                  //           //   // },
                                  //           // ),
                                  //         ),
                                  //       ),
                                  userDetails.profile.toString() == "null" ||
                                          userDetails.profile.toString().isEmpty
                                      ? ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(50),
                                          child: Container(
                                            height: 100,
                                            width: 100,
                                            decoration: BoxDecoration(
                                                border: Border.all(
                                                    color: Colors.white,
                                                    width: 2),
                                                shape: BoxShape.circle,
                                                image: DecorationImage(
                                                    image: AssetImage(
                                                      "assets/home/profile.png",
                                                    ),
                                                    fit: BoxFit.cover)),
                                          ),
                                        )
                                      : ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          child: ClipOval(
                                            child: Container(
                                              height: 100,
                                              width: 100,
                                              decoration: BoxDecoration(
                                                border: Border.all(
                                                  color: Colors.white,
                                                  width: 2,
                                                ),
                                                shape: BoxShape.circle,
                                              ),
                                              child: CachedNetworkImage(
                                                errorWidget: (context, url,
                                                        error) =>
                                                    Image.asset(
                                                        "assets/home/profile.png",
                                                        fit: BoxFit.cover),
                                                imageUrl: (userDetails.profile
                                                            .toString())
                                                        .contains(
                                                            PROFILE_IMAGE_PATH)
                                                    ? userDetails.profile
                                                        .toString()
                                                    : PROFILE_IMAGE_PATH +
                                                        userDetails.profile
                                                            .toString(),
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                          ),
                                        ),

                                  SizedBox(
                                    height: 15,
                                  ),

                                  ///----- user name ----
                                  Text(
                                    "${userDetails.name}",
                                    // '$name'=='null'?'':'$name',
                                    style: const TextStyle(
                                        fontSize: 18,
                                        fontFamily: "Bold",
                                        color: whiteColor),
                                  ),
                                  SizedBox(
                                    height: 5,
                                  ),

                                  ///------- user email -----
                                  Text(
                                    "${userDetails.email}",
                                    // '$email'=='null'?'':'$email',
                                    style: const TextStyle(
                                        fontSize: 15,
                                        fontFamily: "Bold",
                                        color: Colors.grey),
                                  ),

                                  SizedBox(
                                    height: 12,
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 10,
                          ),

                          ///---------- options view ----------
                          Container(
                            margin: const EdgeInsets.only(left: 10, right: 10),
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(15),
                              color: whiteColor,
                            ),
                            child: ListView.builder(
                              padding: EdgeInsets.zero,
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              itemCount: options.length,
                              itemBuilder: (context, index) {
                                return optionCard(index: index);
                              },
                            ),
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                          // InkWell(
                          //   onTap: (){
                          //     Navigator.push(context, MaterialPageRoute(builder: (context)=>BookDetailsScreen()));
                          //   },
                          //   child: Container(
                          //     color: themeColor,
                          //     height: 50,
                          //   ),
                          // )
                        ],
                      ),
                    ),
        ),
      ],
    );
  }

  ///------- option card -----
  optionCard({required int index}) {
    return Column(
      children: [
        InkWell(
          onTap: () {
            clickToFunction(options[index].type);
          },
          child: Container(
            padding: EdgeInsets.only(
                bottom: options[index].imagePath ==
                        "assets/profile/profile-delete.png"
                    ? 8
                    : 0),
            margin: EdgeInsets.only(
              top: options[index].imagePath ==
                      "assets/profile/profile-delete.png"
                  ? 10
                  : 5,
              left: 10,
              right: 10,
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                ///------- image with name -------
                Expanded(
                    child: Row(
                  children: [
                    SizedBox(
                      width: options[index].imagePath ==
                              "assets/profile/profile-delete.png"
                          ? 5
                          : 0,
                    ),
                    Image.asset(
                      options[index].imagePath,
                      color: themeColor,
                      scale: 3.2,
                    ),
                    SizedBox(
                      width: options[index].imagePath ==
                              "assets/profile/profile-delete.png"
                          ? 5
                          : 0,
                    ),
                    semiBoldText(
                      text: options[index].name,
                      size: 13,
                      color: blackColor,
                      // alignment: TextAlign.center,
                    ),
                  ],
                )),

                ///------ back arrow -----
                options[index].widget == null
                    ? Container()
                    : Container(
                        margin: EdgeInsets.only(
                          top: 7,
                        ),
                        child: Icon(
                          Icons.arrow_forward_ios_rounded,
                          size: 18,
                        ),
                      )
              ],
            ),
          ),
        ),

        ///----- divider -----
        index == options.length - 1
            ? Container()
            : Container(
                margin: EdgeInsets.only(left: 10, right: 10),
                child: Divider(
                  height: 15,
                  thickness: 1,
                  // indent: kWIDTH * 0.12,
                  color: subTextColor.withOpacity(0.2),
                ),
              ),
      ],
    );
  }

  ///---- button click function ----------
  clickToFunction(int type) async {
    switch (type) {
      case 0:
        final result = await Navigator.push(context,
            MaterialPageRoute(builder: (context) => EditProfileScreen()));
        if (result == true) {
          getUserDetails();
        }
        break;

      case 1:
        Get.to(() => const BookListScreen());
        break;

      case 2:
        Get.to(() => const FamilyMemberList());
        break;

      case 3:
        Get.to(() => const AddressListScreen());
        // Navigator.push(context,
        //     MaterialPageRoute(builder: (context) => AddressListScreen()));
        break;

      case 5:
        showCustomDialog(
          context: context,
          title: Confirmation[LANGUAGE_TYPE],
          msg: Delete_Account_Msg[LANGUAGE_TYPE],
          btnYesText: YES[LANGUAGE_TYPE],
          onPressedBtnYes: () async {
            deleteAccount();
          },
          onPressedButtonNo: () {
            Navigator.pop(context);
          },
          btnNoText: NO[LANGUAGE_TYPE],
        );
        break;

      case 4:
        showCustomDialog(
          context: context,
          title: ALERT[LANGUAGE_TYPE],
          msg: ARE_YOU_SURE_LOGOUT_FROM_LABORATORY_APP[LANGUAGE_TYPE],
          btnYesText: YES_PROCEED[LANGUAGE_TYPE],
          onPressedBtnYes: () async {
            getUserDetails();

            await userDetails.removeAllUserDetails();
            Navigator.popUntil(context, (route) => route.isFirst);

            Navigator.pushReplacement(context,
                MaterialPageRoute(builder: (context) => PagesWidget()));
          },
          onPressedButtonNo: () {
            Navigator.pop(context);
          },
          btnNoText: NO_WAIT[LANGUAGE_TYPE],
        );
        break;
    }
  }
}

///---- option class ----------
class Options {
  dynamic name;
  Widget? widget;
  String imagePath;
  int type;
  double padding;

  Options(
      {this.name,
      this.widget,
      required this.imagePath,
      required this.type,
      this.padding = 0});
}
