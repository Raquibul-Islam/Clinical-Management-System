import 'dart:convert';

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:leboratory/Models/edit_profile_model.dart';
import 'package:leboratory/Models/user_details_class.dart';
import 'package:leboratory/Screens/Custome_Widgets/custom_dialogue.dart';
import 'package:leboratory/Screens/View/ProfileScreens/profile_screen.dart';
import 'package:leboratory/componant/custome_appBar.dart';
import 'package:leboratory/utils/colors.dart';
import '../../../componant/validation_screen.dart';
import '../../../utils/AllText.dart';
import '../../../utils/api.dart';
import '../../../utils/strings.dart';
import '../../Custome_Widgets/custome_widget.dart';
import 'package:http/http.dart' as http;

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({Key? key}) : super(key: key);

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  final key = GlobalKey<FormState>();

  ///------ controller ------
  TextEditingController nameController = TextEditingController();

  TextEditingController emailController = TextEditingController();

  TextEditingController phoneController = TextEditingController();

  ///------
  UserDetailsClass userDetails = UserDetailsClass();
  EditProfileModel? editProfileModel;

  ///------ for image -----
  String? imagePath;

  // File? imageFile;
  //
  // getFromGallery() async {
  //   PickedFile? pickedFile = await ImagePicker().getImage(
  //     source: ImageSource.gallery,
  //     maxWidth: 1800,
  //     maxHeight: 1800,
  //   );
  //   if (pickedFile != null) {
  //     imageFile = File(pickedFile.path);
  //   }
  // }

  pickImageFromGallery() async {
    final imagePicker = ImagePicker();
    XFile? file = await imagePicker.pickImage(
        source: ImageSource.gallery, imageQuality: 50);

    if (file != null) {
      setState(() {
        imagePath = file.path;
      });
    } else {}
  }

  ///-------

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getUserDetails();
  }

  getUserDetails() async {
    UserDetailsClass data = await UserDetailsClass().getUserDetails();
    setState(() {
      userDetails = data;
    });

    if (userDetails.isLoggedIn) {
      setState(() {
        nameController.text = userDetails.name!;
        phoneController.text = userDetails.phone.toString();
        emailController.text = userDetails.email!;
      });
    }
  }

// String? profile;
//   String? name;
//
//   data() async {
//     // setState(() async {
//       final prefs = await SharedPreferences.getInstance();
//       await prefs.getInt(userId);
//
//       profile= prefs.getString(userprofile);
//       name= prefs.getString(username);
//       nameController.text="${prefs.getString(username)}";
//       emailController.text="${prefs.getString(useremail)}";
//       phoneController.text= "${prefs.getString(userphone)}";
//     // });
//   }
// @override
//   void initState() {
//     // TODO: implement initState
//   data();
//     super.initState();
//   }
  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: whiteColor,

      ///------ body view -----
      body: body(width, userDetails),
    );
  }

  ///------ body view -----
  body(final width, UserDetailsClass userDetails) {
    return Column(
      children: [
        ///------ appbar ------
        CustomAppBar(
            title: Edit_Profile[LANGUAGE_TYPE], isArrow: true, isAction: false),

        ///----- bg view -----
        Expanded(
          child: SingleChildScrollView(
            child: Form(
              key: key,
              child: Column(
                children: [
                  Container(
                    height: 220,
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage(
                          "assets/login/bg.png",
                        ),
                        fit: BoxFit.fill,
                      ),
                    ),
                    child: Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            height: 30,
                          ),

                          ///-------- user image view --------------

                          Stack(
                            alignment: Alignment.bottomRight,
                            children: [
                              userDetails.profile != null &&
                                      userDetails.profile!.isNotEmpty &&
                                      imagePath == null
                                  ? ClipRRect(
                                      borderRadius: BorderRadius.circular(10),
                                      child: Container(
                                        height: 120,
                                        width: 120,
                                        decoration: BoxDecoration(
                                            border: Border.all(
                                                color: Colors.white, width: 2),
                                            shape: BoxShape.circle,
                                            image: DecorationImage(
                                              fit: BoxFit.cover,
                                              image: NetworkImage(
                                                userDetails.profile!.contains(
                                                        SERVER_ADDRESS
                                                            .split("api/")
                                                            .first)
                                                    ? userDetails.profile
                                                        .toString()
                                                    : PROFILE_IMAGE_PATH +
                                                        userDetails.profile
                                                            .toString(),
                                              ),
                                            )),
                                      ),
                                    )
                                  : imagePath == null
                                      ? ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(50),
                                          child: Container(
                                            height: 120,
                                            width: 120,
                                            decoration: BoxDecoration(
                                                // borderRadius: BorderRadius.circular(50),
                                                border: Border.all(
                                                    color: Colors.white,
                                                    width: 2),
                                                shape: BoxShape.circle,
                                                image: DecorationImage(
                                                    image: AssetImage(
                                                        "assets/home/profile.png"),
                                                    fit: BoxFit.cover)),
                                          ),
                                        )
                                      : ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(15),
                                          child: Container(
                                            height: 120,
                                            width: 120,
                                            decoration: BoxDecoration(
                                                border: Border.all(
                                                    color: Colors.white,
                                                    width: 2),
                                                shape: BoxShape.circle,
                                                image: DecorationImage(
                                                    fit: BoxFit.cover,
                                                    image: FileImage(
                                                      File(imagePath!),
                                                    ))),
                                          ),
                                        ),
                              GestureDetector(
                                  onTap: () {
                                    setState(() {
                                      pickImageFromGallery();
                                    });
                                  },
                                  child: Image.asset(
                                      "assets/profile/camera.png",
                                      height: 26)),
                            ],
                          ),

                          SizedBox(
                            height: 10,
                          ),

                          ///----- user name -----

                          Text(
                            "${userDetails.name}",
                            style: const TextStyle(
                                fontSize: 18,
                                fontFamily: "Bold",
                                color: whiteColor),
                          ),

                          SizedBox(
                            height: 12,
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 20, right: 20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        ///---- Name ----
                        textFildHeader(Enter_Name[LANGUAGE_TYPE], width),
                        editCustomTextField(
                          validateName,
                          nameController,
                          width,
                          "DeoJohan",
                        ),
                        SizedBox(
                          height: 15,
                        ),

                        ///---- email ----
                        textFildHeader(Email[LANGUAGE_TYPE], width),
                        editCustomTextField(
                          validateEmail,
                          emailController,
                          width,
                          "DeoJohan@gmail.com",
                        ),
                        SizedBox(
                          height: 15,
                        ),

                        ///---- phoneNumber ----
                        textFildHeader(Phone_Number[LANGUAGE_TYPE], width),
                        editCustomTextField(
                          validatePhone,
                          phoneController,
                          width,
                          "+913247224882",
                        ),
                        SizedBox(
                          height: 19,
                        ),

                        ///----save Button----
                        customeElevatedButton(width, Save[LANGUAGE_TYPE],
                            callback: () {
                          setState(() {
                            Get.focusScope?.unfocus();
                            validateAndUpdateProfile();
                          });
                          // Navigator.pop(context);
                        })
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  ///------ save method ------
  void validateAndUpdateProfile() {
    if (imagePath == null && userDetails.profile.toString().isEmpty) {
      showCustomDialog(
          title: ALERT,
          context: context,
          msg: IMAGE_PATH_CANNOT_BE_EMPTY,
          btnYesText: OK,
          onPressedBtnYes: () {
            Navigator.pop(context);
          });
    } else if (key.currentState!.validate()) {
      setState(() {
        updateProfile();
      });
    }
  }

  ///---- api ====
  updateProfile() async {
    showLoadingMsg(
      context: context,
      msg: PLEASE_WAIT_WHILE_UPDATING_PROFILE,
      title: UPDATING,
    );

    var request =
        http.MultipartRequest('POST', Uri.parse(SERVER_ADDRESS + editProfile));

    request.fields.addAll({
      'id': '${userDetails.userId}',
      'name': "${nameController.text}",
      'phone': phoneController.text.toString(),
      'email': '${userDetails.email}',
    });

    if (imagePath != null) {
      request.files.add(await http.MultipartFile.fromPath(
          'image', '${imagePath.toString()}'));
    }

    http.StreamedResponse response = await request.send().catchError((e) {
      showCustomDialog(
          context: context,
          title: SUCCESSFUL,
          msg: e.toString(),
          btnYesText: OK,
          onPressedBtnYes: () {
            Navigator.pop(context);
          });
    });

    if (response.statusCode == 200) {
      final jsonResponse = json.decode(await response.stream.bytesToString());
      if (jsonResponse['status'] == 1) {
        Navigator.pop(context);

        try {
          editProfileModel = EditProfileModel.fromJson(jsonResponse);
          await userDetails.setUserDetails(
            isLoggedIn: true,
            name: nameController.text,
            phone: int.parse(phoneController.text),
            email: editProfileModel!.data!.email.toString(),
            profile: editProfileModel!.data!.profilePic.toString(),
            userId: editProfileModel!.data!.id!.toInt(),
            pass: userDetails.pass!,
          );

          Navigator.pop(context, true);

          // Get.offAll(ProfileScreen());
          // Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>ProfileScreen()));
        } catch (e) {}
      } else {
        Navigator.pop(context);
        showCustomDialog(
            context: context,
            title: ALERT,
            msg: jsonResponse['msg'],
            btnYesText: OK,
            onPressedBtnYes: () {
              Navigator.pop(context);
            });
      }
    } else {
      Navigator.pop(context);
      showCustomDialog(
          context: context,
          title: SUCCESSFUL,
          msg: response.reasonPhrase,
          btnYesText: OK,
          onPressedBtnYes: () {
            Navigator.pop(context);
          });
    }
  }
}
