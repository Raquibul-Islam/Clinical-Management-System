import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_cached_pdfview/flutter_cached_pdfview.dart';
import 'package:leboratory/utils/api.dart';
import 'package:photo_view/photo_view.dart';

import '../../utils/colors.dart';
import '../Custome_Widgets/custome_widget.dart';

class ReportViewScreen extends StatelessWidget {
  final String name;

  ReportViewScreen({Key? key, required this.name}) : super(key: key);

  GlobalKey<FormState> sKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: themeSecondaryColor,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: themeColor,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Container(child: Icon(Icons.arrow_back_ios))),
            Container(
              margin: EdgeInsets.only(left: 10),
              child: boldText(text: 'Report'),
            ),
          ],
        ),
      ),
      body: name.split('.').last.toLowerCase() == 'pdf'
          ? Column(
              children: [
                Expanded(
                  child: PDF().cachedFromUrl(
                    '$ReportPath$name',
                    placeholder: (progress) =>
                        Center(child: Text('$progress %')),
                    errorWidget: (error) =>
                        Center(child: Text(error.toString())),
                  ),
                )
              ],
            )
          : PhotoView(
              key: sKey,
              imageProvider: CachedNetworkImageProvider(
                '$ReportPath$name',
              ),
              maxScale: 1.0,
              minScale: 0.2,
            ),
    );
  }
}
