import 'dart:async';
import 'dart:convert';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:leboratory/Screens/Custome_Widgets/page_widget.dart';
import 'package:leboratory/Screens/View/onBordingScreen.dart';
import 'package:leboratory/utils/colors.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../utils/api.dart';
import '../../../utils/strings.dart';

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    // TODO: implement initState

    super.initState();
    getAndStoreToken();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: blackColor,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(70, 0, 70, 0),
                child: Image.asset(
                  "assets/login/logo.png",
                  width: 200,
                  height: 200,
                ),
              ),
              // ct.semiboldText(
              //   text: ONLINE_DUKAAN,
              //   color: kWHITE,
              //   size: 35,
              // ),
            ],
          ),
        ),
      ),
    );
  }

  getAndStoreToken() async {
    await Future.delayed(Duration(seconds: 2));
    SharedPreferences.getInstance().then((value) {
      if (value.getBool("isTokenStored") ?? false) {
        FirebaseMessaging.instance.getToken().then((value) {
          storeToken(value);
        }).catchError((e) {
          value.setBool("isTokenStored", false);
        });

        goToChooseStoreCategory();
      } else if (value.getBool("isTokenStored") == null) {
        FirebaseMessaging.instance.getToken().then((value) {
          storeToken(value);
        }).catchError((e) {
          value.setBool("isTokenStored", false);
          goToChooseStoreCategory();
        });
      } else if (value.getBool("isTokenStored") == false) {
        FirebaseMessaging.instance.getToken().then((value) {
          storeToken(value);
        }).catchError((e) {
          value.setBool("isTokenStored", false);

          goToChooseStoreCategory();
        });
      }
    });
  }

  storeToken(token) async {
    await get(Uri.parse(
            SERVER_ADDRESS + saveToken + "?token=${token ?? "abc"}&type=1"))
        .then((value) {
      if (value.statusCode == 200) {
        var data = jsonDecode(value.body);
        if (data['status'] == 1) {
          SharedPreferences.getInstance().then((value) {
            value.setBool("isTokenStored", true);
            goToChooseStoreCategory();
          });
        } else {
          goToChooseStoreCategory();
        }
      }
    }).catchError((e) {
      SharedPreferences.getInstance().then((value) {
        value.setBool("isTokenStored", false);
        goToChooseStoreCategory();
      });
    });

    // await get(Uri.parse("$SERVER_ADDRESS/savetoken?token=${token ?? "abc"}&type=1"))
    //
    //     .then((value){
    //   final jsonResponse = jsonDecode(value.body);
    //   if(jsonResponse.statusCode == 200 && jsonResponse['data']['status'] == 1){
    //     SharedPreferences.getInstance().then((value){
    //       value.setBool("isTokenStored", true);
    //      goToChooseStoreCategory();
    //     });
    //   }
    //   else{
    //     goToChooseStoreCategory();
    //   }
    // }).catchError((e){
    //   SharedPreferences.getInstance().then((value){
    //     value.setBool("isTokenStored", false);
    //     goToChooseStoreCategory();
    //   });
    // });
  }

  // goToLogin(){
  //   Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> SellerLoginScreen()));
  // }
  //
  // goToHome(){
  //   Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> SellerTabScreen()));
  // }

  goToChooseStoreCategory() async {
    if (kISSTOREAPK) {
      await SharedPreferences.getInstance().then((value) {
        // if(value.getBool('isRtlView') ?? false  ){
        if (value.getBool('isLoggedIn') ?? false) {
          //
          if (mounted) {
            Navigator.pushReplacement(context,
                MaterialPageRoute(builder: (context) => PagesWidget()));
          }
        } else {
          // Navigator.pushReplacement(
          //     context, MaterialPageRoute(builder: (context) => LoginScreen()));

          if (mounted) {
            Navigator.pushReplacement(context,
                MaterialPageRoute(builder: (context) => PagesWidget()));
          }
        }

        // }else{
        //   // Navigator.pushReplacement(context,
        //   //     MaterialPageRoute(builder: (context) => SellerLoginScreen()));
        //   Navigator.pushReplacement(context,
        //       MaterialPageRoute(builder: (context) => ChangeLanguageFirstScreen()));
        // }
      });
    } else {
      Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (context) => OnBoardingScreens()));
    }
  }
}
