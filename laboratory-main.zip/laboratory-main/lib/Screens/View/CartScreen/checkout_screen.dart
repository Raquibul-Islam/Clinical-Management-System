import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:leboratory/main.dart';

import '../../../Models/address_list_model.dart';
import '../../../Models/cart_list_model.dart';
import '../../../componant/custome_appBar.dart';
import '../../../componant/validation_screen.dart';
import '../../../controller/checkout_controller.dart';
import '../../../utils/AllText.dart';
import '../../../utils/colors.dart';
import '../../../utils/strings.dart';
import '../../Custome_Widgets/custome_widget.dart';
import '../../Custome_Widgets/total_card_widget.dart';
import '../AddressListScreen/collect_address_screen.dart';

class CheckoutScreen extends StatefulWidget {
  final int subTotal;
  final int txt;
  final int total;
  final Data data;

  const CheckoutScreen(
      {Key? key,
      required this.subTotal,
      required this.txt,
      required this.total,
      required this.data})
      : super(key: key);

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  // final controller = Get.put(CheckoutController());

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    // controller.getUserDetails();
    // controller.fetchAddress();
    return Scaffold(
      backgroundColor: themeSecondaryColor,
      body: Column(
        children: [
          CustomAppBar(
              title: CHECKOUT[LANGUAGE_TYPE], isArrow: true, isAction: false),
          GetBuilder<CheckoutController>(
              init: CheckoutController(),
              builder: (controller) {
                return controller.isLoading
                    ? Center(
                        child: CircularProgressIndicator(),
                      )
                    : Expanded(
                        child: SingleChildScrollView(
                          child: Column(
                            children: [
                              /// Total Card ===
                              TotalCard(
                                width: width,
                                subTotal: '$CURRENCY${widget.subTotal}.00',
                                total: '$CURRENCY${widget.total}.00',
                                tax: '$CURRENCY${widget.txt}.00',
                              ),

                              /// Collect Address Card ===
                              CollectAddressCard(
                                width: width,
                                addressData: controller.selectedAddress,
                              ),

                              /// Select Date and Time Card ===
                              Container(
                                margin: const EdgeInsets.only(
                                    top: 15, right: 8, left: 8),
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 16, vertical: 16),
                                width: width,
                                decoration: BoxDecoration(
                                  color: whiteColor,
                                  borderRadius: BorderRadius.circular(15),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    boldText(
                                        text: SELECT_TIME_DATE[LANGUAGE_TYPE],
                                        size: 16,
                                        color: blackColor),
                                    const SizedBox(
                                      height: 10,
                                    ),
                                    selectDateField(
                                      validateDate,
                                      controller.selectDateController,
                                      width,
                                      onTap: () {
                                        controller.selectDate(context);
                                      },
                                    ),
                                    const SizedBox(
                                      height: 10,
                                    ),
                                    selectTimeField(
                                        validateTime,
                                        controller.selectTimeController,
                                        width, onTap: () {
                                      controller.selectTime(context);
                                    })
                                  ],
                                ),
                              ),

                              /// Payment Option
                              // PaymentOption(width: width)
                              Container(
                                margin: const EdgeInsets.only(
                                    top: 15, right: 8, left: 8),
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 16, vertical: 16),
                                width: width,
                                decoration: BoxDecoration(
                                  color: whiteColor,
                                  borderRadius: BorderRadius.circular(15),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    boldText(
                                      text: PAYMENT_OPTION[LANGUAGE_TYPE],
                                      color: blackColor,
                                      size: 16,
                                    ),
                                    const SizedBox(
                                      height: 5,
                                    ),
                                    const Divider(
                                      color: subTextColor,
                                    ),
                                    ListTile(
                                      onTap: () {
                                        controller.setSelectedRadio(
                                            CheckoutController.values[0]);
                                      },
                                      contentPadding: EdgeInsets.zero,
                                      leading: Image.asset(
                                        'assets/checkout/brainTree.png',
                                        height: 30,
                                      ),
                                      title: Text(
                                        'Braintree',
                                        style: TextStyle(fontFamily: 'Regular'),
                                      ),
                                      trailing: Radio(
                                        value: CheckoutController.values[0],
                                        groupValue: controller.selectedValue,
                                        activeColor: blackColor,
                                        onChanged: (val) {
                                          controller.setSelectedRadio(val);
                                        },
                                      ),
                                    ),
                                    ListTile(
                                      onTap: () {
                                        controller.setSelectedRadio(
                                            CheckoutController.values[1]);
                                      },
                                      contentPadding: EdgeInsets.zero,
                                      leading: Image.asset(
                                        'assets/checkout/payStack.png',
                                        height: 30,
                                      ),
                                      title: Text(
                                        'Paystack',
                                        style: TextStyle(fontFamily: 'Regular'),
                                      ),
                                      trailing: Radio(
                                        value: CheckoutController.values[1],
                                        groupValue: controller.selectedValue,
                                        activeColor: blackColor,
                                        onChanged: (val) {
                                          controller.setSelectedRadio(val);
                                        },
                                      ),
                                    ),
                                    ListTile(
                                      onTap: () {
                                        controller.setSelectedRadio(
                                            CheckoutController.values[2]);
                                      },
                                      contentPadding: EdgeInsets.zero,
                                      leading: Image.asset(
                                        'assets/cart/cod.png',
                                        height: 30,
                                      ),
                                      title: Text(
                                        'Cash On Delivery',
                                        style: const TextStyle(
                                            fontFamily: 'Regular'),
                                      ),
                                      trailing: Radio(
                                        value: CheckoutController.values[2],
                                        groupValue: controller.selectedValue,
                                        activeColor: blackColor,
                                        onChanged: (val) {
                                          controller.setSelectedRadio(val);
                                        },
                                      ),
                                    ),
                                    ListTile(
                                      onTap: () {
                                        controller.setSelectedRadio(
                                            CheckoutController.values[2]);
                                      },
                                      contentPadding: EdgeInsets.zero,
                                      leading: Image.asset(
                                        'assets/checkout/stripe.png',
                                        height: 30,
                                      ),
                                      title: Text(
                                        'Stripe',
                                        style: TextStyle(fontFamily: 'Regular'),
                                      ),
                                      trailing: Radio(
                                        value: CheckoutController.values[3],
                                        groupValue: controller.selectedValue,
                                        activeColor: blackColor,
                                        onChanged: (val) {
                                          controller.setSelectedRadio(val);
                                        },
                                      ),
                                    ),
                                  ],
                                ),
                              ),

                              /// Book Now
                              Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 10, vertical: 10),
                                child: controller.isBooking
                                    ? Center(
                                        child: CircularProgressIndicator(),
                                      )
                                    : customeElevatedButton(
                                        width, BOOK_NOW[LANGUAGE_TYPE],
                                        callback: () async {
                                        Get.focusScope?.unfocus();

                                        if (controller.selectedValue !=
                                            'Stripe') {
                                          controller.bookNow(
                                            subTotal: widget.subTotal,
                                            txt: widget.txt,
                                            total: widget.total,
                                            data: widget.data,
                                          );
                                        } else {
                                          controller.isBooking = true;
                                          controller.update();
                                          controller.paymentIntent =
                                              await (String amount,
                                                      String currency) async {
                                            Map<String, dynamic> body = {
                                              'amount':
                                                  ((int.parse(amount)) * 100)
                                                      .toString(),
                                              'currency': currency,
                                              'payment_method_types[]': 'card',
                                            };

                                            var response = await http.post(
                                              Uri.parse(
                                                  'https://api.stripe.com/v1/payment_intents'),
                                              headers: {
                                                'Authorization':
                                                    'Bearer $stripeSecretKey',
                                                'Content-Type':
                                                    'application/x-www-form-urlencoded'
                                              },
                                              body: body,
                                            );
                                            return jsonDecode(
                                                response.body.toString());
                                          }(widget.total.toString(),
                                                  CURRENCY_CODE);
                                          http.Client().close();
                                          print(
                                              "Here ${controller.paymentIntent}");
                                          await Stripe.instance
                                              .initPaymentSheet(
                                            paymentSheetParameters:
                                                SetupPaymentSheetParameters(
                                              paymentIntentClientSecret:
                                                  controller.paymentIntent![
                                                      'client_secret'],
                                              merchantDisplayName: 'Laboratory',
                                            ),
                                          );

                                          controller.displayPaymentSheet(
                                            subTotal: widget.subTotal,
                                            txt: widget.txt,
                                            total: widget.total,
                                            data: widget.data,
                                          );
                                        }

                                        // Navigator.pop(context);
                                      }),
                              ),
                            ],
                          ),
                        ),
                      );
              }),
        ],
      ),
    );
  }
}

class CollectAddressCard extends StatelessWidget {
  const CollectAddressCard({
    Key? key,
    required this.width,
    required this.addressData,
  }) : super(key: key);

  final double width;
  final Datum addressData;

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<CheckoutController>();
    return Container(
      margin: const EdgeInsets.only(top: 15, right: 8, left: 8),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      width: width,
      decoration: BoxDecoration(
        color: whiteColor,
        borderRadius: BorderRadius.circular(15),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              boldText(
                  text: COLLECTION_ADDRESS[LANGUAGE_TYPE],
                  color: blackColor,
                  size: 16),
              InkWell(
                onTap: () {
                  Get.to(() => CollectAddressScreen());
                  // Navigator.push(
                  //     context,
                  //     MaterialPageRoute(
                  //         builder: (context) => const CollectAddressScreen()));
                  // Select Address On Click
                },
                child: regularText(
                    text: SELECT_ADDRESS_ADD[LANGUAGE_TYPE],
                    color: themeColor,
                    size: 14),
              )
            ],
          ),
          const SizedBox(
            height: 5,
          ),
          const Divider(
            color: subTextColor,
          ),
          const SizedBox(
            height: 5,
          ),
          Get.find<CheckoutController>().isAddressLoading
              ? SizedBox()
              : controller.isAddressNull
                  ? SizedBox()
                  : boldText(
                      text: '${addressData.name}', color: blackColor, size: 16),
          const SizedBox(
            height: 10,
          ),
          Get.find<CheckoutController>().isAddressLoading
              ? Center(
                  child: CircularProgressIndicator(),
                )
              : controller.isAddressNull
                  ? customeElevatedButton(width, ADD_ADDRESS_ADD[LANGUAGE_TYPE],
                      callback: () {
                      Get.to(() => CollectAddressScreen());
                      // Navigator.pop(context);
                    })
                  : regularText(
                      // text: 'A / 234, King Plazaa, Mithakhali, Ahmedabad, Gujarat',
                      text:
                          '${addressData.houseNo}, ${addressData.address}, ${addressData.city}-${addressData.pincode}, ${addressData.state}',
                      color: blackColor),
          const SizedBox(
            height: 10,
          ),
          controller.isAddressNull
              ? SizedBox()
              : RichText(
                  text: TextSpan(
                    text: MOBILE[LANGUAGE_TYPE],
                    style: const TextStyle(
                      fontSize: 16,
                      color: blackColor,
                      fontWeight: FontWeight.w500,
                      fontFamily: "Bold",
                    ),
                    children: <TextSpan>[
                      TextSpan(
                        text: '${addressData.phone}',
                        style: TextStyle(
                          // fontSize: size,
                          color: blackColor,
                          fontSize: 14,
                          // letterSpacing: .5,
                          fontWeight: FontWeight.w500,
                          fontFamily: "Regular",
                        ),
                      ),
                    ],
                  ),
                )
        ],
      ),
    );
  }
}
