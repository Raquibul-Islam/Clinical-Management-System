import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:leboratory/controller/cart_detail_controller.dart';
import 'package:leboratory/main.dart';

import '../../../componant/custome_appBar.dart';
import '../../../utils/AllText.dart';
import '../../../utils/colors.dart';
import '../../../utils/strings.dart';
import '../../Custome_Widgets/custome_widget.dart';
import '../../Custome_Widgets/persondetail_cardview.dart';
import '../../Custome_Widgets/total_card_widget.dart';
import '../AuthScreen/login_screen.dart';
import 'checkout_screen.dart';

class CartDetailScreen extends StatefulWidget {
  const CartDetailScreen({Key? key}) : super(key: key);

  @override
  State<CartDetailScreen> createState() => _CartDetailScreenState();
}

class _CartDetailScreenState extends State<CartDetailScreen> {
  final controller = Get.put(CartDetailController());

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    controller.getUserDetails();
    // controller.fetCartPackageDetail();
    // controller.fetchCartList();
    return Scaffold(
      backgroundColor: themeSecondaryColor,
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomAppBar(
              title: CART_DETAIL[LANGUAGE_TYPE],
              isArrow: false,
              isAction: false),
          Expanded(
            child: GetBuilder<CartDetailController>(builder: (controller) {
              return controller.isLoading
                  ? Center(
                      child: CircularProgressIndicator(
                        color: themeColor,
                      ),
                    )
                  : controller.userDetails.isLoggedIn == false
                      ? Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 10.0),
                              child: Image.asset("assets/cart/cart_empty.png"),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            semiBoldText(
                                text: YOU_ARE_NOT_LOGGED_IN_YET[LANGUAGE_TYPE],
                                color: blackColor,
                                size: 28),
                            SizedBox(
                              height: 10,
                            ),
                            GestureDetector(
                              onTap: () {
                                Get.to(() => LoginScreen());
                              },
                              child: Padding(
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 5),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Expanded(
                                      child: regularText(
                                          text: PLEASE_LOGIN_REGISTER[
                                              LANGUAGE_TYPE],
                                          maxLines: 1,
                                          textOverFlow: TextOverflow.ellipsis,
                                          color: subTextColor,
                                          size: 16),
                                    ),
                                    SizedBox(
                                      width: 3,
                                    ),
                                    semiBoldText(
                                        text: LOGIN_NOW[LANGUAGE_TYPE],
                                        color: themeColor,
                                        size: 17),
                                  ],
                                ),
                              ),
                            ),
                            SizedBox(
                              height: Get.height * 0.12,
                            )
                          ],
                        )
                      // ? Center(
                      //         child: customeElevatedButton(
                      //           200,
                      //           Login[LANGUAGE_TYPE],
                      //           callback: () {
                      //             Get.to(() => LoginScreen());
                      //           },
                      //         ),
                      //       )
                      : controller.isCartEmpty
                          ? Center(
                              child: regularText(text: 'Cart is empty'),
                            )
                          : SingleChildScrollView(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  ///----- Card View ///////
                                  Container(
                                      child: ListView.builder(
                                          physics:
                                              NeverScrollableScrollPhysics(),
                                          padding: EdgeInsets.zero,
                                          shrinkWrap: true,
                                          itemCount: controller.cartListModel!
                                              .data!.cart!.length,
                                          itemBuilder: (context, index) {
                                            var userData = controller
                                                .cartListModel!
                                                .data!
                                                .cart![index];
                                            var packageData = controller
                                                .cartListModel!
                                                .data!
                                                .cart![index]
                                                .testdata;
                                            return PersonPackageDetailCardView(
                                              width: width,
                                              name:
                                                  '${userData.memberName} | ${userData.relation}  ',
                                              detail:
                                                  '${userData.gender},${userData.age} years',
                                              cardItem: 2,
                                              testdatum: packageData!,
                                              memberId: userData.memberId!,
                                            );
                                          })),
                                  // PersonPackageDetailCardView(
                                  //   width: width,
                                  //   name: 'Hetal | Self   ',
                                  //   detail: 'Female,24 years',
                                  //   cardItem: 2,
                                  // ),
                                  // PersonPackageDetailCardView(
                                  //   width: width,
                                  //   name: 'Vishal | Self   ',
                                  //   detail: 'Male,24 years',
                                  //   cardItem: 1,
                                  // ),

                                  ///----- Total Card View ///////
                                  TotalCard(
                                    width: width,
                                    subTotal:
                                        '$CURRENCY${controller.subTotal}.00',
                                    total: '$CURRENCY${controller.total}.00',
                                    tax:
                                        '$CURRENCY${controller.cartListModel!.data!.txt}.00',
                                    isShowSavingAmount: true,
                                    saving: controller.saving,
                                  ),

                                  ///----- Checkout Button ///////
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10, vertical: 10),
                                    child: customeElevatedButton(
                                      MediaQuery.of(context).size.width,
                                      CHECKOUT[LANGUAGE_TYPE],
                                      callback: () {
                                        Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    CheckoutScreen(
                                                      subTotal:
                                                          controller.subTotal,
                                                      txt: controller
                                                          .cartListModel!
                                                          .data!
                                                          .txt!,
                                                      total: controller.total,
                                                      data: controller
                                                          .cartListModel!.data!,
                                                    )));
                                        // CheckOut Button Call
                                      },
                                    ),
                                  ),
                                ],
                              ),
                            );
            }),
          ),
        ],
      ),
    );
  }
}
