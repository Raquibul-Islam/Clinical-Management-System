import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../Models/family_member_list_model.dart';
import '../../../componant/custome_appBar.dart';
import '../../../componant/validation_screen.dart';
import '../../../controller/add_family_member_controller.dart';
import '../../../utils/AllText.dart';
import '../../../utils/colors.dart';
import '../../../utils/strings.dart';
import '../../Custome_Widgets/custome_widget.dart';

class AddNewFamilyMember extends StatefulWidget {
  final isEdit;
  final Datum? data;

  const AddNewFamilyMember({Key? key, this.isEdit = false, this.data})
      : super(key: key);

  @override
  State<AddNewFamilyMember> createState() => _AddNewFamilyMemberState();
}

// enum genderEnum { Male, Female }

class _AddNewFamilyMemberState extends State<AddNewFamilyMember> {
  final key = GlobalKey<FormState>();

  final controller = Get.put(AddFamilyMemberController());

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: controller.selectedDate,
      firstDate: DateTime(1930),
      lastDate: DateTime.now(),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: themeColor,
            ),
            textButtonTheme: TextButtonThemeData(
              style: TextButton.styleFrom(
                foregroundColor: themeColor, // button text color
              ),
            ),
          ),
          child: child!,
        );
      },
    );

    if (picked != null && picked != controller.selectedDate) {
      controller.selectDate(picked);
      calculateAge();
    }
  }

  void calculateAge() {
    String birthdateString = controller.dobController.text;
    List<String> parts = birthdateString.split('-');

    if (parts.length == 3) {
      int birthDay = int.parse(parts[0]);
      int birthMonth = int.parse(parts[1]);
      int birthYear = int.parse(parts[2]);

      DateTime currentDate = DateTime.now();
      DateTime birthdate = DateTime(birthYear, birthMonth, birthDay);

      Duration difference = currentDate.difference(birthdate);
      int age = (difference.inDays / 365).floor();

      setState(() {

        controller.ageController.text = "Your Age is ${age} Years".toString();

      });
    } else {
      setState(() {
        controller.ageFinal = 'Invalid date format';
      });
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    if (widget.isEdit) {
      controller.setData(widget.data!);

      controller.selectedDate = DateTime.parse(
          "${widget.data!.dob!.split("-")[2]}-${widget.data!.dob!.split("-")[1].padLeft(2, '0')}-${widget.data!.dob!.split("-")[0].padLeft(2, '0')}");
    }
    super.initState();
    // if(mounted){
    //   if(widget.isEdit){
    //     controller.setData(widget.data!);
    //   }
    // }
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: whiteColor,
      body: Column(
        children: [
          CustomAppBar(
              title: widget.isEdit
                  ? EDIT_NEW_FAMILY_MEMBER[LANGUAGE_TYPE]
                  : ADD_NEW_FAMILY_MEMBER[LANGUAGE_TYPE],
              isArrow: true,
              isAction: false),
          GetBuilder<AddFamilyMemberController>(builder: (controller) {
            return Expanded(
                child: SingleChildScrollView(
              child: Form(
                key: key,
                child: Container(
                  margin:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      ///---- Name ----
                      textFildHeader(Enter_Name[LANGUAGE_TYPE], width),
                      editCustomTextField(
                        validateName,
                        controller.nameController,
                        width,
                        HINT_NAME[LANGUAGE_TYPE],
                      ),

                      ///--- Relation ---
                      const SizedBox(
                        height: 19,
                      ),
                      textFildHeader(RELATION[LANGUAGE_TYPE], width),
                      DropdownButtonFormField<String>(
                        value: controller.relationController.text,
                        style: TextStyle(
                          fontWeight: FontWeight.w400,
                          fontSize: width > 360 ? 16 : 14,
                          color: blackColor,
                          fontFamily: "Regular",
                        ),
                        decoration: const InputDecoration(
                          border: UnderlineInputBorder(
                            borderSide: BorderSide(color: blackColor),
                          ),
                          enabledBorder: UnderlineInputBorder(
                            borderSide: BorderSide(color: subTextColor),
                          ),
                          focusedBorder: UnderlineInputBorder(
                            borderSide: BorderSide(color: blackColor),
                          ),
                          focusColor: blackColor,
                          fillColor: blackColor,
                        ),
                        items: [
                          'Father',
                          'Self',
                          'Parent',
                          'Friend',
                          'Mother',
                          'Son',
                          'Daughter',
                          'Uncle',
                          'Aunty',
                          'Other'
                        ]
                            .map((label) => DropdownMenuItem(
                                  child: Text(label.toString()),
                                  value: label,
                                ))
                            .toList(),
                        hint: Text(HINT_RELATION[LANGUAGE_TYPE]),
                        onChanged: (value) {
                          setState(() {
                            controller.relationController.text = value!;
                          });
                        },
                      ),

                      const SizedBox(
                        height: 19,
                      ),

                      ///---- phoneNumber ----
                      textFildHeader(MOBILE_NO[LANGUAGE_TYPE], width),
                      editCustomTextField(
                          validatePhone,
                          controller.mobileNumberController,
                          width,
                          HINT_PHONE[LANGUAGE_TYPE],
                          textInputType: TextInputType.number),

                      const SizedBox(
                        height: 19,
                      ),

                      ///---- email ----
                      textFildHeader(Email[LANGUAGE_TYPE], width),
                      editCustomTextField(
                          validateEmail,
                          controller.emailController,
                          width,
                          HINT_EMAIL[LANGUAGE_TYPE],
                          textInputType: TextInputType.emailAddress),
                      const SizedBox(
                        height: 19,
                      ),

                      /// --- DOB ---
                      textFildHeader(DOB[LANGUAGE_TYPE], width),
                      dboTextField(
                        validateDOB,
                        controller.dobController,
                        width,
                        onTap: () {
                          _selectDate(context);

                        },
                        text: controller.ageController.text,
                      ),
                      SizedBox(
                        height: controller.ageController.text.isEmpty ? 0 : 19,
                      ),
                      textFildHeader(GENDER[LANGUAGE_TYPE], width),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Wrap(
                            alignment: WrapAlignment.start,
                            runAlignment: WrapAlignment.start,
                            crossAxisAlignment: WrapCrossAlignment.center,
                            children: [
                              Radio<genderEnum>(
                                fillColor: MaterialStateColor.resolveWith(
                                    (states) => blackColor),
                                value: genderEnum.Male,
                                groupValue: controller.gender,
                                onChanged: (genderEnum? value) {
                                  controller.selectGender(value);
                                  // setState(() {
                                  //   _gender = value;
                                  // });
                                },
                              ),
                              regularText(
                                  text: MALE[LANGUAGE_TYPE],
                                  color: subTextColor,
                                  size: 16),
                            ],
                          ),
                          Wrap(
                            alignment: WrapAlignment.center,
                            crossAxisAlignment: WrapCrossAlignment.center,
                            children: [
                              Radio<genderEnum>(
                                fillColor: MaterialStateColor.resolveWith(
                                    (states) => blackColor),
                                value: genderEnum.Female,
                                groupValue: controller.gender,
                                onChanged: (genderEnum? value) {
                                  controller.selectGender(value);
                                  // setState(() {
                                  //   _gender = value;
                                  // });
                                },
                              ),
                              regularText(
                                  text: FEMALE[LANGUAGE_TYPE],
                                  color: subTextColor,
                                  size: 16),
                            ],
                          )
                        ],
                      ),
                      const SizedBox(
                        height: 29,
                      ),
                      controller.isSaveLoading
                          ? Center(
                              child: CircularProgressIndicator(),
                            )
                          : Row(
                              children: [
                                customeElevatedButtonOutLine(
                                    width / 2.3, CANCEL[LANGUAGE_TYPE],
                                    callback: () {
                                  controller.resetForm();
                                  Get.back(result: false);
                                }),
                                const Spacer(),
                                customeElevatedButton(
                                    width / 2.3, Save[LANGUAGE_TYPE],
                                    callback: () {
                                  if (key.currentState!.validate()) {
                                    if (widget.isEdit) {
                                      controller.addNewMember(
                                          isEdit: true,
                                          memberId: widget.data!.id);
                                    } else {
                                      controller.addNewMember();
                                    }
                                  }
                                })
                              ],
                            ),
                    ],
                  ),
                ),
              ),
            ));
          })
        ],
      ),
    );
  }
}
