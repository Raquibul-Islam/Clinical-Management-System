import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_state_manager/src/simple/get_state.dart';
import 'package:leboratory/Models/family_member_list_model.dart';
import 'package:leboratory/Models/local_package_detail_model.dart';

import '../../../componant/custome_appBar.dart';
import '../../../controller/member_list_controller.dart';
import '../../../utils/AllText.dart';
import '../../../utils/colors.dart';
import '../../../utils/strings.dart';
import '../../Custome_Widgets/custome_widget.dart';
import 'add_new_family_member.dart';

class MemberList extends StatelessWidget {
  LocalPackageModel localPackageModel;

  MemberList({Key? key, required this.localPackageModel}) : super(key: key);

  final controller = Get.put(MemberListClass());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: themeSecondaryColor,
      body: SingleChildScrollView(
        child: Column(
          children: [
            CustomAppBar(
                title: MEMBERS_LIST[LANGUAGE_TYPE],
                isArrow: true,
                isAction: false),

            /// New
            Container(
              child: GetBuilder<MemberListClass>(builder: (controller) {
                return controller.isLoading
                    ? const Center(
                        child: Padding(
                          padding: EdgeInsets.only(top: 60.0),
                          child: CircularProgressIndicator(
                            color: themeColor,
                          ),
                        ),
                      )
                    : SingleChildScrollView(
                        child: Column(
                          children: [
                            controller.isDataNotFound ||
                                    controller.familyMemberList.isEmpty
                                ? Column(
                                    children: [
                                      SizedBox(
                                        height: 35,
                                      ),
                                      Container(
                                        // margin: EdgeInsets.only(top:70,bottom: 70),
                                        child: regularTextSecond(
                                            text: 'Member Not Found', size: 18),
                                      ),
                                      SizedBox(
                                        height: 10,
                                      ),
                                      Container(
                                        padding: EdgeInsets.symmetric(
                                            horizontal: 15),
                                        alignment: Alignment.center,
                                        child: Center(
                                          child: regularTextThird(
                                              text:
                                                  'You must add family member or add yourself as member to book Test.',
                                              size: 16),
                                        ),
                                      ),
                                    ],
                                  )
                                : Container(
                                    child: ListView.builder(
                                        physics: const BouncingScrollPhysics(),
                                        shrinkWrap: true,
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 10, vertical: 10),
                                        itemCount:
                                            controller.familyMemberList.length,
                                        itemBuilder: (context, index) {
                                          bool isFirst =
                                              index == 0 ? true : false;
                                          bool isLast = controller
                                                          .familyMemberList
                                                          .length -
                                                      1 ==
                                                  index
                                              ? true
                                              : false;
                                          var data = controller
                                              .familyMemberList[index];
                                          String subTitle =
                                              '${data.gender},${data.age} years';
                                          return FamilyMemberListCard(
                                            data: data,
                                            index: index,
                                            isFirst: isFirst,
                                            isLast: isLast,
                                            title: data.name!,
                                            subTitle: subTitle,
                                            onTap: (bool) {
                                              controller.selectMember(
                                                  index, bool!);
                                            },
                                            isSelected: data.isSelected!,
                                          );
                                        }),
                                  ),
                            controller.isButtonLoading
                                ? Center(
                                    child: CircularProgressIndicator(),
                                  )
                                : Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10, vertical: 20),
                                    child: customeElevatedButtonOutLine(
                                      MediaQuery.of(context).size.width,
                                      ADD_MEMBER[LANGUAGE_TYPE],
                                      callback: () async {
                                        bool isResult = await Get.to(
                                            () => AddNewFamilyMember());
                                        if (isResult) {
                                          controller.setLoadingTrue();
                                          controller.getFamilyMemberList();
                                        }
                                      },
                                      color: themeSecondaryColor,
                                    ),
                                  ),
                            controller.isButtonLoading
                                ? SizedBox()
                                : controller.isDataNotFound ||
                                        controller.familyMemberList.isEmpty
                                    ? SizedBox()
                                    : Padding(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 10, vertical: 5),
                                        child: customeElevatedButton(
                                            MediaQuery.of(context).size.width,
                                            ADD_TO_CART[LANGUAGE_TYPE],
                                            callback: () {
                                          controller
                                              .addToCart(localPackageModel);
                                        }),
                                      ),
                            const SizedBox(
                              height: 10,
                            ),
                          ],
                        ),
                      );
              }),
            ),

            /// Old
            // Expanded(
            //   child: ListView.builder(
            //       padding:
            //           const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
            //       itemCount: member.length + 1,
            //       itemBuilder: (context, index) {
            //         bool isFirst = index == 0 ? true : false;
            //         bool isLast = member.length - 1 == index ? true : false;
            //         return member.length != index
            //             ? FamilyMemberListCard(
            //                 index: index,
            //                 isFirst: isFirst,
            //                 isLast: isLast,
            //                 title: member[index].title!,
            //                 subTitle: member[index].subTitle!,
            //                 isSelected: member[index].isSelected,
            //                 onTap: (value) {
            //                   setState(() {
            //                     member[index].isSelected = value!;
            //                   });
            //                 },
            //               )
            //             : Column(
            //                 children: [
            //                   const SizedBox(
            //                     height: 10,
            //                   ),
            //                   Padding(
            //                     padding: const EdgeInsets.symmetric(
            //                         horizontal: 0, vertical: 5),
            //                     child: customeElevatedButtonOutLine(
            //                       MediaQuery.of(context).size.width,
            //                       ADD_MEMBER[LANGUAGE_TYPE],
            //                       callback: () {
            //                         Navigator.push(
            //                             context,
            //                             MaterialPageRoute(
            //                                 builder: (context) =>
            //                                     AddNewFamilyMember()));
            //                         // Navigator.pop(context);
            //                       },
            //                       color: themeSecondaryColor,
            //                     ),
            //                   ),
            //                   Padding(
            //                     padding: const EdgeInsets.symmetric(
            //                         horizontal: 0, vertical: 5),
            //                     child: customeElevatedButton(
            //                         MediaQuery.of(context).size.width,
            //                         ADD_TO_CART[LANGUAGE_TYPE], callback: () {
            //                       // Navigator.pop(context);
            //                     }),
            //                   ),
            //                   const SizedBox(
            //                     height: 10,
            //                   ),
            //                 ],
            //               );
            //       }),
            // )
          ],
        ),
      ),
    );
  }
}

class FamilyMemberListCard extends StatelessWidget {
  final int index;
  final bool isFirst;
  final bool isLast;
  final String title;
  final String subTitle;
  final bool isSelected;
  final Function(bool?) onTap;
  final Datum data;

  const FamilyMemberListCard({
    Key? key,
    required this.index,
    required this.isFirst,
    required this.isLast,
    required this.title,
    required this.subTitle,
    required this.isSelected,
    required this.onTap,
    required this.data,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: whiteColor,
        borderRadius: isFirst && isLast
            ? const BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
                bottomLeft: Radius.circular(20),
                bottomRight: Radius.circular(20))
            : isFirst
                ? const BorderRadius.only(
                    topLeft: Radius.circular(20), topRight: Radius.circular(20))
                : isLast
                    ? const BorderRadius.only(
                        bottomRight: Radius.circular(20),
                        bottomLeft: Radius.circular(20))
                    : BorderRadius.circular(0),
      ),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 0, vertical: 15),
        margin: const EdgeInsets.symmetric(horizontal: 10),
        decoration: BoxDecoration(
          border: isLast
              ? const Border()
              : const Border(bottom: BorderSide(color: subTextColor, width: 1)),
        ),
        child: Row(
          children: [
            Checkbox(
              value: isSelected,
              onChanged: onTap,
              // fillColor: MaterialStateProperty.all(blackColor),
              side: const BorderSide(color: subTextColor),
              activeColor: Colors.black,
            ),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  boldText(
                    text: title + " (${data.relation})",
                    size: 16,
                    color: blackColor,
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  // Text(title),
                  regularText(text: subTitle, color: subTextColor, size: 14),
                  // Text(subTitle),
                ],
              ),
            ),
            Row(
              children: [
                InkWell(
                  onTap: () async {
                    bool isResult = await Get.to(() => AddNewFamilyMember(
                          isEdit: true,
                          data: data,
                        ));
                    if (isResult) {
                      Get.find<MemberListClass>().getFamilyMemberList();
                    }
                    //
                  },
                  child: Image.asset(
                    'assets/address_list/edit.png',
                    height: 35,
                  ),
                ),
                InkWell(
                  onTap: () {
                    Get.find<MemberListClass>()
                        .deleteMember(memberId: data.id!);
                  },
                  child: Image.asset(
                    'assets/address_list/delete.png',
                    height: 30,
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}

class FamilyMemberModel {
  String? title;
  String? subTitle;
  bool isSelected;

  FamilyMemberModel({this.title, this.subTitle, this.isSelected = false});
}
