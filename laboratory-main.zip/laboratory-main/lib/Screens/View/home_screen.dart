import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:leboratory/Models/categoryModel.dart';
import 'package:leboratory/Screens/View/HomeScreens/popular_package_screen.dart';
import 'package:leboratory/controller/category_Controller.dart';
import 'package:leboratory/utils/AllText.dart';
import 'package:leboratory/utils/App_Images.dart';
import 'package:leboratory/utils/colors.dart';
import 'package:leboratory/utils/strings.dart';

import 'HomeScreens/category_detail_screen.dart';

class HomeScreen extends StatefulWidget {
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  CategoryController categoryListController = Get.put(CategoryController());

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    categoryListController.getCategory();
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final height = MediaQuery.of(context).size.height;
    return Scaffold(
      body: Container(
        height: height,
        width: width,
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: MediaQuery.of(context).padding.top,
                ),
                Text(
                  Home_Welcome_Back[LANGUAGE_TYPE],
                  style: const TextStyle(
                    color: themeColor,
                    fontSize: 16,
                    fontFamily: "Light",
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                Text(
                  What_Are_You_Looking[LANGUAGE_TYPE],
                  style: const TextStyle(
                    color: blackColor,
                    fontSize: 26,
                    fontFamily: "Bold",
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),

                ///---- Search ----

                TextField(
                  cursorColor: subTextColor,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(15),
                      borderSide: const BorderSide(color: subTextColor),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: const BorderSide(color: subTextColor),
                      borderRadius: BorderRadius.circular(15),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: const BorderSide(color: subTextColor),
                      borderRadius: BorderRadius.circular(15),
                    ),
                    isDense: true,
                    prefixIcon: const Icon(
                      Icons.search,
                      color: subTextColor,
                      size: 24,
                    ),
                    hintText: Search[LANGUAGE_TYPE],
                    hintStyle: const TextStyle(
                      color: subTextColor,
                      fontSize: 16,
                      // fontWeight: FontWeight.w300,
                      // letterSpacing: 2.0,
                      fontFamily: "Regular",
                    ),
                  ),
                  onChanged: (value) {
                    if (value == "") {
                      categoryListController.getCategory();
                    } else {
                      categoryListController.searchData(value);
                    }
                  },
                ),
                const SizedBox(
                  height: 20,
                ),

                ///---- Laboratory Package ----
                Container(
                  height: 170,
                  // width: width,
                  decoration: const BoxDecoration(
                    // color: containerBackGoundColor,
                    // borderRadius: BorderRadius.circular(30),
                    image: DecorationImage(
                      image: AssetImage(
                        "assets/home/bg.png",
                      ),
                      fit: BoxFit.fill,
                    ),
                  ),
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 15),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Text(
                              Laboratory_Package[LANGUAGE_TYPE],
                              style: const TextStyle(
                                fontSize: 18,
                                fontFamily: "Bold",
                              ),
                            ),
                            SizedBox(
                              width: width / 1.9,
                              child: Text(
                                Laboratory_Package_Sub_Text[LANGUAGE_TYPE],
                                style: const TextStyle(
                                  fontSize: 12,
                                  color: subTextColor,
                                  fontFamily: "Regular",
                                ),
                              ),
                            ),
                            ElevatedButton(
                              onPressed: () {
                                Get.to(() => PopularPackageScreen());
                                // Navigator.push(
                                //   context,
                                //   MaterialPageRoute(
                                //     builder: (context) =>
                                //         PopularPackageScreen(),
                                //   ),
                                // );
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: themeColor,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(50),
                                ),
                              ),
                              child: Row(
                                children: [
                                  Text(
                                    Popular_Package[LANGUAGE_TYPE],
                                    style: const TextStyle(
                                        fontSize: 12, fontFamily: "Regular"),
                                  ),
                                  const SizedBox(
                                    width: 5,
                                  ),
                                  const Icon(
                                    Icons.arrow_forward,
                                    size: 16,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                ///---- Laboratory Category ----
                Container(
                  child: GetBuilder<CategoryController>(
                    init: CategoryController(),
                    builder: (controller) {
                      return controller.isLoading
                          ? const Center(
                              child: SizedBox(
                                height: 150,
                                width: 35,
                                child: Center(
                                    child: CircularProgressIndicator(
                                  color: themeColor,
                                )),
                              ),
                            )
                          : categoryListController.categoryModelList!.isEmpty
                              ? Container(
                                  alignment: Alignment.center,
                                  child: const Text(
                                    'No Data Found',
                                    style: TextStyle(
                                      color: blackColor,
                                      fontSize: 15,
                                      fontWeight: FontWeight.w300,
                                    ),
                                  ),
                                )
                              : GridView.builder(
                                  padding: EdgeInsets.zero,
                                  itemCount: categoryListController
                                      .categoryModelList!.length,
                                  gridDelegate:
                                      const SliverGridDelegateWithFixedCrossAxisCount(
                                    crossAxisCount: 2,
                                    crossAxisSpacing: 10.0,
                                    childAspectRatio: 1,
                                    mainAxisSpacing: 10.0,
                                  ),
                                  physics: const NeverScrollableScrollPhysics(),
                                  shrinkWrap: true,
                                  itemBuilder: (context, index) {
                                    return GestureDetector(
                                      onTap: () {
                                        Get.to(() => CategoryDetailScreen(
                                              id: categoryListController
                                                  .categoryModelList![index]
                                                  .id!,
                                            ));
                                      },
                                      child: Container(
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(30),
                                          image: const DecorationImage(
                                            fit: BoxFit.fill,
                                            image: AssetImage(
                                              AppImages.defaultImage,
                                            ),
                                          ),
                                        ),
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 15, vertical: 15),
                                          child: Column(
                                            // mainAxisAlignment: MainAxisAlignment.spaceAround,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              SizedBox(
                                                height: 10,
                                              ),
                                              Expanded(
                                                child: Image.network(
                                                  categoryListController
                                                      .categoryModelList![index]
                                                      .image,
                                                ),
                                              ),
                                              SizedBox(
                                                height: 10,
                                              ),
                                              Text(
                                                categoryListController
                                                    .categoryModelList![index]
                                                    .name
                                                    .toString(),
                                                style: const TextStyle(
                                                  fontFamily: "Bold",
                                                  color: whiteColor,
                                                  fontSize: 20,
                                                ),
                                              ),
                                              SizedBox(
                                                height: 7,
                                              ),
                                              Text(
                                                categoryListController
                                                    .categoryModelList![index]
                                                    .short_desc
                                                    .toString(),
                                                style: const TextStyle(
                                                  fontFamily: "Regular",
                                                  color: whiteColor,
                                                  fontSize: 13,
                                                ),
                                                maxLines: 2,
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    );
                                  },
                                );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
