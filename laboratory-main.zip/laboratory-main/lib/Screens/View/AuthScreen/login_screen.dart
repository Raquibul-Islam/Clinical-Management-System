import 'dart:convert';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:leboratory/Screens/Custome_Widgets/custom_dialogue.dart';
import 'package:leboratory/Screens/Custome_Widgets/custome_widget.dart';
import 'package:leboratory/Screens/Custome_Widgets/page_widget.dart';
import 'package:leboratory/Screens/View/AuthScreen/register_screen.dart';
import 'package:leboratory/componant/validation_screen.dart';
import 'package:leboratory/utils/AllText.dart';
import 'package:leboratory/utils/App_Images.dart';
import 'package:leboratory/utils/colors.dart';
import 'package:leboratory/utils/strings.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../../../Services/create_crash_report_service.dart';
import '../../../main.dart';
import '../../../utils/api.dart';
import 'forgot_password_screen.dart';

class LoginScreen extends StatefulWidget {
  // String? select;
  // LoginScreen(this.select)
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final key = GlobalKey<FormState>();
  TextEditingController emailController = TextEditingController();

  TextEditingController passController = TextEditingController();
  String email = "";
  String pass = "";
  bool _obscureText = true;
  String? token;
  bool isRemember = false;

  getToken() async {
    FirebaseMessaging.instance.getToken().then((value) {
      setState(() {
        token = value;
      });
    });
  }

  // Toggles the password show status
  void _toggle() {
    setState(() {
      _obscureText = !_obscureText;
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    // String? x = widget.select;
    // if(x != null){
    //   setState(() {
    //     kLANGUAGETYPE = x;
    //   });
    // }
    getToken();
    getRememberValue();
  }

  getRememberValue() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    bool tmpRemember = preferences.getBool('isRemember') ?? false;
    String tmpEmail = preferences.getString('reEmail') ?? '';
    String tmpPassword = preferences.getString('rePassword') ?? '';

    if (tmpRemember) {
      setState(() {
        isRemember = tmpRemember;
        emailController.text = tmpEmail;
        passController.text = tmpPassword;
      });
    }

    // await SharedPreferences.getInstance().then((value) {
    //   isRemember = value.getBool('isRemember')??false;
    //   email = value.getString('reEmail') ?? "";
    //   pass = value.getString('rePassword') ?? "";
    // });
    // if(isRemember){
    //   emailController.text = email;
    //   passController.text = pass;
    // }
    //
    // setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final height = MediaQuery.of(context).size.height;
    return Scaffold(
      body: Container(
        height: height,
        width: width,
        decoration: const BoxDecoration(
          image: DecorationImage(
            fit: BoxFit.cover,
            image: AssetImage(
              AppImages.defaultImage,
            ),
          ),
        ),
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Form(
              key: key,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(
                    height: 70,
                  ),

                  ///---- Logo ----
                  Image.asset(
                    "assets/login/logo.png",
                    height: 150,
                    width: 90,
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  loginText(Welcome_Back[LANGUAGE_TYPE]),
                  const SizedBox(
                    height: 6,
                  ),
                  loginSubText(Login_Continue[LANGUAGE_TYPE]),
                  const SizedBox(
                    height: 30,
                  ),

                  ///---- Email textField -----
                  textFildHeader(Enter_Email_Address[LANGUAGE_TYPE], width),
                  customeTextFild(validateEmail, emailController, width, "",
                      TextInputType.emailAddress),
                  const SizedBox(
                    height: 10,
                  ),

                  ///---- Password textField -----
                  textFildHeader(Enter_Password[LANGUAGE_TYPE], width),
                  customePasswordTextFild(validatePass, passController, width,
                      "", _obscureText, _toggle),

                  const SizedBox(
                    height: 10,
                  ),

                  ///----forgot Password----

                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Checkbox(
                            checkColor: whiteColor,
                            activeColor: themeColor,
                            fillColor: MaterialStateProperty.all(subTextColor),
                            value: isRemember,
                            onChanged: (bool? value) {
                              setState(() {
                                isRemember = value!;
                              });
                            },
                          ),
                          Text(
                            Remember[LANGUAGE_TYPE],
                            style: const TextStyle(
                              color: subTextColor,
                              fontFamily: "Regular",
                            ),
                          ),
                        ],
                      ),
                      InkWell(
                        onTap: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      ForgotPasswordScreen()));
                        },
                        child: Text(
                          Forgot_Password[LANGUAGE_TYPE],
                          style: const TextStyle(
                            color: whiteColor,
                            fontSize: 16,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),

                  ///----Login Button----
                  customeElevatedButton(width, Login[LANGUAGE_TYPE],
                      callback: () async {
                    if (key.currentState!.validate()) {
                      email = emailController.text;
                      pass = passController.text;
                      if (isRemember) {
                        SharedPreferences.getInstance().then((value) async {
                          await value.setBool('isRemember', true);
                          await value.setString('reEmail', email);
                          await value.setString('rePassword', pass);
                        });
                      } else {
                        SharedPreferences.getInstance().then((value) async {
                          await value.remove('isRemember');
                          await value.remove('reEmail');
                          await value.remove('rePassword');
                        });
                      }
                      login("1");
                    }
                    // Navigator.of(context).pushReplacement(
                    //     MaterialPageRoute(builder: (context) => PagesWidget()))
                  }),
                  const SizedBox(
                    height: 20,
                  ),

                  ///---- or ----
                  Row(
                    children: [
                      Expanded(
                        child: Container(
                          margin:
                              const EdgeInsets.only(left: 10.0, right: 10.0),
                          height: 2,
                          color: Colors.grey,
                        ),
                      ),
                      Text(
                        Or[LANGUAGE_TYPE],
                        style: const TextStyle(
                          color: subTextColor,
                          fontSize: 18,
                          fontFamily: "Regular",
                        ),
                      ),
                      Expanded(
                        child: Container(
                          margin:
                              const EdgeInsets.only(left: 10.0, right: 10.0),
                          height: 2,
                          color: Colors.grey,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 20,
                  ),

                  ///---- don't have account/register ----
                  Padding(
                    padding: const EdgeInsets.only(bottom: 26),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          Dont_Have_Account[LANGUAGE_TYPE],
                          style: TextStyle(
                            color: subTextColor,
                            fontFamily: "Regular",
                            fontSize: MediaQuery.of(context).size.width > 360
                                ? 16
                                : 14,
                          ),
                        ),
                        const SizedBox(
                          width: 5,
                        ),
                        GestureDetector(
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => RegisterScreen()));
                            // Get.off(const Registration());
                          },
                          child: Padding(
                            padding: const EdgeInsets.only(right: 8),
                            child: Text(
                              Register_Now[LANGUAGE_TYPE],
                              style: TextStyle(
                                color: whiteColor,
                                fontFamily: "Regular",
                                fontSize:
                                    MediaQuery.of(context).size.width > 360
                                        ? 16
                                        : 14,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  ///--------------- login button --------------
  login(String type) async {
    Get.focusScope?.unfocus();
    showLoadingMsg(
        context: context,
        title: LOGGING_IN[LANGUAGE_TYPE],
        msg: PLEASE_WAIT_WHIlE_LOGGING_IN[LANGUAGE_TYPE]);
    final _response = await http.post(Uri.parse(SERVER_ADDRESS +
        userLogin +
        "?email=$email&password=$pass&token=${(token)}&token_type=1&login_type=1"));

    try {
      if (_response.statusCode == 200) {
        if (jsonDecode(_response.body)['status'] == 1) {
          var data = jsonDecode(_response.body);
          await userDetailsClass.setUserDetails(
            userId: data['register']['user_id'],
            name: data['register']['name'],
            profile: data['register']['profile_pic'] ?? '',
            phone: data['register']['phone'],
            email: emailController.text,
            isLoggedIn: true,
            pass: passController.text,
          );
          Navigator.popUntil(context, (route) => route.isFirst);
          await Future.delayed(Duration.zero);
          Navigator.pushReplacement(
              context, MaterialPageRoute(builder: (context) => PagesWidget()));
        } else if (jsonDecode(_response.body)['status'] == 0) {
          Navigator.pop(context);
          showCustomDialog(
              context: context,
              title: OOPS_ERROR,
              msg: jsonDecode(_response.body)['msg'],
              btnYesText: OK,
              onPressedBtnYes: () {
                Navigator.pop(context);
              });
        } else {
          CreateCrashService.createReport(
            url: "${_response.request?.url}",
            code: "${_response.statusCode}",
            reason: "${_response.reasonPhrase}",
            body: _response.body,
            catchError: "",
          );
          Navigator.pop(context);
          showCustomDialog(
              context: context,
              title: OOPS_ERROR,
              msg: PLEASE_TRY_AFTER_SOME_TIME,
              btnYesText: OK,
              onPressedBtnYes: () {
                Navigator.pop(context);
              });
        }
      } else {
        CreateCrashService.createReport(
          url: "${_response.request?.url}",
          code: "${_response.statusCode}",
          reason: "${_response.reasonPhrase}",
          body: _response.body,
          catchError: "",
        );
        Navigator.pop(context);
        showCustomDialog(
            context: context,
            title: OOPS_ERROR,
            msg: PLEASE_TRY_AFTER_SOME_TIME,
            btnYesText: OK,
            onPressedBtnYes: () {
              Navigator.pop(context);
            });
      }
    } catch (e, stackTrace) {
      CreateCrashService.createReport(
        url: "${_response.request?.url}",
        code: "${_response.statusCode}",
        reason: "${_response.reasonPhrase}",
        body: _response.body,
        stackTrace: "$stackTrace",
        catchError: "$e",
      );
      Navigator.pop(context);
      showCustomDialog(
          context: context,
          title: OOPS_ERROR,
          msg: PLEASE_TRY_AFTER_SOME_TIME,
          btnYesText: OK,
          onPressedBtnYes: () {
            Navigator.pop(context);
          });
    }
  }
}
