import 'dart:convert';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:leboratory/Screens/Custome_Widgets/custome_widget.dart';
import 'package:leboratory/Screens/Custome_Widgets/page_widget.dart';
import 'package:leboratory/Screens/View/AuthScreen/login_screen.dart';
import 'package:leboratory/Services/create_crash_report_service.dart';
import 'package:leboratory/componant/validation_screen.dart';
import 'package:leboratory/utils/AllText.dart';
import 'package:leboratory/utils/App_Images.dart';
import 'package:leboratory/utils/colors.dart';
import 'package:leboratory/utils/strings.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../../../main.dart';
import '../../../utils/api.dart';
import '../../Custome_Widgets/custom_dialogue.dart';

class RegisterScreen extends StatefulWidget {
  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final key = GlobalKey<FormState>();
  String? email;
  String? pass;
  String? confirmpass;
  String? name;
  String? phone;

  DateTime now = new DateTime.now();
  String token = "";
  TextEditingController nameController = TextEditingController();

  TextEditingController emailController = TextEditingController();

  TextEditingController phoneController = TextEditingController();

  TextEditingController passwordController = TextEditingController();

  TextEditingController confirmPasswordController = TextEditingController();

  bool _obscureText = true;

  ///========== Toggles the password show status
  void _toggle() {
    setState(() {
      _obscureText = !_obscureText;
    });
  }

  bool _obscureConfirmText = true;

  ///========= Toggles the password show status
  void _toggleConfirm() {
    setState(() {
      _obscureConfirmText = !_obscureConfirmText;
    });
  }

  ///------------- get token ----
  getToken() async {
    FirebaseMessaging.instance.getToken().then((value) {
      setState(() {
        token = value!;
      });
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getToken();
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    return Scaffold(
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        decoration: const BoxDecoration(
          image: DecorationImage(
            fit: BoxFit.cover,
            image: AssetImage(
              AppImages.defaultImage,
            ),
          ),
        ),
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Form(
              key: key,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(
                    height: 20,
                  ),
                  IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: const Icon(
                      Icons.arrow_back_ios,
                      color: whiteColor,
                      size: 18,
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),

                  ///---- Logo ----
                  Image.asset(
                    "assets/login/logo.png",
                    height: 150,
                    width: 90,
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  loginText(Register_Now[LANGUAGE_TYPE]),
                  const SizedBox(
                    height: 6,
                  ),
                  loginSubText(RegisterSubText[LANGUAGE_TYPE]),
                  const SizedBox(
                    height: 30,
                  ),

                  ///---- Name ----
                  textFildHeader(Enter_Name[LANGUAGE_TYPE], width),
                  customeTextFild(validateName, nameController, width, "",
                      TextInputType.text),
                  const SizedBox(
                    height: 10,
                  ),

                  ///---- Email ----
                  textFildHeader(Enter_Email_Address[LANGUAGE_TYPE], width),
                  customeTextFild(validateEmail, emailController, width, "",
                      TextInputType.emailAddress),
                  const SizedBox(
                    height: 10,
                  ),

                  ///---- Phone Number ----
                  textFildHeader(Enter_Phone_Number[LANGUAGE_TYPE], width),
                  customeTextFild(validatePhone, phoneController, width, "",
                      TextInputType.phone),
                  const SizedBox(
                    height: 10,
                  ),

                  ///---- Password ----
                  textFildHeader(Enter_Password[LANGUAGE_TYPE], width),
                  customePasswordTextFild(
                    validatePass,
                    passwordController,
                    width,
                    "",
                    _obscureText,
                    _toggle,
                  ),
                  const SizedBox(
                    height: 10,
                  ),

                  ///---- Confirm Password ----
                  textFildHeader(Confirm_Enter_Password[LANGUAGE_TYPE], width),
                  customePasswordTextFild(
                      validatePass,
                      confirmPasswordController,
                      width,
                      "",
                      _obscureConfirmText,
                      _toggleConfirm),
                  // customeTextFild(validateName, confirmPasswordController, width,
                  //     Confirm_Enter_Password[LANGUAGE_TYPE]),
                  const SizedBox(
                    height: 30,
                  ),

                  ///----Register Button----
                  customeElevatedButton(width, Register[LANGUAGE_TYPE],
                      callback: () {
                    if (key.currentState!.validate()) {
                      if (passwordController.text ==
                          confirmPasswordController.text) {
                        name = nameController.text;

                        email = emailController.text;

                        phone = phoneController.text;
                        pass = passwordController.text;
                        confirmpass = confirmPasswordController.text;
                        // dob = dobController.text;
                        signUp();
                      } else {
                        Get.snackbar(
                          "Failed data",
                          "Password does not match",
                          snackPosition: SnackPosition.BOTTOM,
                          backgroundColor: redColor,
                        );
                      }
                    }
                    // Navigator.of(context).pushReplacement(
                    //     MaterialPageRoute(builder: (context) => PagesWidget()));
                  }
                      // setState(() {
                      //   // isLoading = value;
                      // });
                      ),
                  const SizedBox(
                    height: 20,
                  ),

                  ///---- Already have account/login ----
                  Padding(
                    padding: const EdgeInsets.only(bottom: 26),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          Already_Have_Account[LANGUAGE_TYPE],
                          style: TextStyle(
                            color: subTextColor,
                            fontFamily: "Regular",
                            fontSize: MediaQuery.of(context).size.width > 360
                                ? 16
                                : 14,
                          ),
                        ),
                        const SizedBox(
                          width: 5,
                        ),
                        GestureDetector(
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => LoginScreen()));
                            // Get.off(const Registration());
                          },
                          child: Padding(
                            padding: const EdgeInsets.only(right: 8),
                            child: Text(
                              Login[LANGUAGE_TYPE],
                              style: TextStyle(
                                color: whiteColor,
                                fontFamily: "Regular",
                                fontSize:
                                    MediaQuery.of(context).size.width > 360
                                        ? 16
                                        : 14,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // --------- Methods ----------------

  signUp() async {
    Get.focusScope?.unfocus();
    showLoadingMsg(
        context: context,
        title: LOGGING_IN[LANGUAGE_TYPE],
        msg: PLEASE_WAIT_WHIlE_LOGGING_IN[LANGUAGE_TYPE]);
    final _response = await http.post(Uri.parse(SERVER_ADDRESS +
        userRegister +
        "?email=$email&password=$pass&name=$name&phone=$phone&token=${(token)}&type=1"));

    try {
      if (_response.statusCode == 200) {
        if (jsonDecode(_response.body)['status'] == 1) {
          var data = jsonDecode(_response.body);
          await userDetailsClass.setUserDetails(
            userId: data['register']['user_id'],
            name: data['register']['name'],
            profile: data['register']['profile_pic'] ?? '',
            phone: int.parse(phoneController.text),
            email: data['register']['email'],
            isLoggedIn: true,
            pass: passwordController.text,
          );

          Navigator.popUntil(context, (route) => route.isFirst);
          await Future.delayed(Duration.zero);
          Navigator.pushReplacement(
              context, MaterialPageRoute(builder: (context) => PagesWidget()));
        } else if (jsonDecode(_response.body)['status'] == 0) {
          Navigator.pop(context);
          showCustomDialog(
              context: context,
              title: OOPS_ERROR,
              msg: jsonDecode(_response.body)['msg'],
              btnYesText: OK,
              onPressedBtnYes: () {
                Navigator.pop(context);
              });
        } else {
          CreateCrashService.createReport(
            url: "${_response.request?.url}",
            code: "${_response.statusCode}",
            reason: "${_response.reasonPhrase}",
            body: _response.body,
            catchError: "",
          );
          Navigator.pop(context);
          showCustomDialog(
              context: context,
              title: OOPS_ERROR,
              msg: PLEASE_TRY_AFTER_SOME_TIME,
              btnYesText: OK,
              onPressedBtnYes: () {
                Navigator.pop(context);
              });
        }
      } else {
        CreateCrashService.createReport(
          url: "${_response.request?.url}",
          code: "${_response.statusCode}",
          reason: "${_response.reasonPhrase}",
          body: _response.body,
          catchError: "",
        );
        Navigator.pop(context);
        showCustomDialog(
            context: context,
            title: OOPS_ERROR,
            msg:
                "${_response.statusCode}\n${_response.reasonPhrase}\n${_response.body}",
            btnYesText: OK,
            onPressedBtnYes: () {
              Navigator.pop(context);
            });
      }
    } catch (e, stackTrace) {
      CreateCrashService.createReport(
        url: "${_response.request?.url}",
        code: "${_response.statusCode}",
        reason: "${_response.reasonPhrase}",
        body: _response.body,
        stackTrace: "$stackTrace",
        catchError: "$e",
      );
      Navigator.pop(context);
      showCustomDialog(
          context: context,
          title: OOPS_ERROR,
          msg: PLEASE_TRY_AFTER_SOME_TIME,
          btnYesText: OK,
          onPressedBtnYes: () {
            Navigator.pop(context);
          });
    }
  }
}
