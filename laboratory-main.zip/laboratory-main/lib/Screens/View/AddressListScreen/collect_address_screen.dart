import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:leboratory/Screens/View/AddressListScreen/add_address_screen.dart';
import 'package:leboratory/utils/colors.dart';

import '../../../componant/custome_appBar.dart';
import '../../../controller/checkout_controller.dart';
import '../../../utils/AllText.dart';
import '../../../utils/strings.dart';
import '../../Custome_Widgets/custome_widget.dart';

class CollectAddressScreen extends StatefulWidget {
  const CollectAddressScreen({Key? key}) : super(key: key);

  @override
  State<CollectAddressScreen> createState() => _CollectAddressScreenState();
}

class _CollectAddressScreenState extends State<CollectAddressScreen> {
  // static const values = <int>[1, 2, 3,4];

  // int selectedValue = values.first;

  // setSelectedRadio(val) {
  //   setState(() {
  //     selectedValue = val;
  //   });
  // }

  final controller = Get.find<CheckoutController>();

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: themeSecondaryColor,
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomAppBar(
              title: COLLECT_ADDRESS[LANGUAGE_TYPE],
              isArrow: true,
              isAction: false),
          Expanded(
            child: GetBuilder<CheckoutController>(builder: (controller) {
              return controller.isAddressLoading
                  ? Center(
                      child: CircularProgressIndicator(),
                    )
                  : controller.isAddressNull
                      ? Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 10),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              customeElevatedButton(
                                  width, ADD_ADDRESS_ADD[LANGUAGE_TYPE],
                                  callback: () async {
                                bool result =
                                    await Get.to(() => AddAddressScreen());
                                if (result) {
                                  controller.fetchAddress();
                                }
                              })
                            ],
                          ),
                        )
                      : SingleChildScrollView(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 10),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                controller.isAddressNull
                                    ? SizedBox()
                                    : Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          boldText(
                                              text:
                                                  SELECT_ADDRESS[LANGUAGE_TYPE],
                                              size: 20),
                                          InkWell(
                                            onTap: () async {
                                              bool result = await Get.to(
                                                  () => AddAddressScreen());
                                              if (result) {
                                                controller.fetchAddress();
                                              }
                                            },
                                            child: regularText(
                                                text: ADD_ADDRESS_ADD[
                                                    LANGUAGE_TYPE],
                                                size: 14,
                                                color: themeColor),
                                          ),
                                        ],
                                      ),
                                controller.isAddressNull
                                    ? SizedBox()
                                    : Container(
                                        margin: const EdgeInsets.only(top: 10),
                                        child: ListView.builder(
                                            physics:
                                                const BouncingScrollPhysics(),
                                            padding: EdgeInsets.zero,
                                            shrinkWrap: true,
                                            itemCount: controller
                                                .addressListModel!.data!.length,
                                            itemBuilder: (context, index) {
                                              var data = controller
                                                  .addressListModel!
                                                  .data![index];
                                              bool isDefault = controller
                                                          .addressListModel!
                                                          .data![index]
                                                          .isDefault ==
                                                      1
                                                  ? true
                                                  : false;
                                              return Container(
                                                margin: const EdgeInsets.only(
                                                    top: 5, bottom: 5),
                                                // padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                                                padding: const EdgeInsets.only(
                                                    right: 10,
                                                    left: 0,
                                                    bottom: 10,
                                                    top: 5),
                                                decoration: BoxDecoration(
                                                    color: whiteColor,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            15)),
                                                child: Column(
                                                  children: [
                                                    if (isDefault)
                                                      Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .only(left: 15),
                                                        child: Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceBetween,
                                                          children: [
                                                            // Flexible(child: Text('Home')),
                                                            Flexible(
                                                              child: boldText(
                                                                text: DEFAULT[
                                                                    LANGUAGE_TYPE],
                                                                size: 18,
                                                                color:
                                                                    blackColor,
                                                              ),
                                                            ),
                                                            Row(
                                                              children: [
                                                                InkWell(
                                                                  onTap:
                                                                      () async {
                                                                    bool
                                                                        result =
                                                                        await Get.to(() =>
                                                                            AddAddressScreen(
                                                                              isEdit: true,
                                                                              address: data,
                                                                            ));
                                                                    if (result) {
                                                                      controller
                                                                          .fetchAddress();
                                                                    }
                                                                  },
                                                                  child: Image
                                                                      .asset(
                                                                    'assets/address_list/edit.png',
                                                                    height: 35,
                                                                  ),
                                                                ),
                                                                InkWell(
                                                                  onTap: () {
                                                                    controller.DeleteAddress(
                                                                        id: data
                                                                            .id);
                                                                  },
                                                                  child: Image
                                                                      .asset(
                                                                    'assets/address_list/delete.png',
                                                                    height: 30,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    if (isDefault)
                                                      const Padding(
                                                        padding:
                                                            EdgeInsets.only(
                                                                left: 16,
                                                                right: 8),
                                                        child: Divider(
                                                            color:
                                                                subTextColor),
                                                      ),
                                                    Row(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        Radio(
                                                          value: data.id
                                                              .toString(),
                                                          groupValue: controller
                                                              .selectedAddress
                                                              .id
                                                              .toString(),
                                                          activeColor:
                                                              blackColor,
                                                          onChanged: (val) {
                                                            controller
                                                                .changeSelectedAddress(
                                                                    data);
                                                            // setSelectedRadio(val);
                                                          },
                                                        ),
                                                        Expanded(
                                                          child: Column(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            children: [
                                                              Row(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .spaceBetween,
                                                                children: [
                                                                  // Flexible(child: Text('Home')),
                                                                  Flexible(
                                                                    child:
                                                                        boldText(
                                                                      text:
                                                                          '${data.name}',
                                                                      size: 16,
                                                                      color:
                                                                          blackColor,
                                                                    ),
                                                                  ),
                                                                  // if (index != 0)
                                                                  if (!isDefault)
                                                                    Row(
                                                                      children: [
                                                                        InkWell(
                                                                          onTap:
                                                                              () async {
                                                                            bool result = await Get.to(() =>
                                                                                AddAddressScreen(
                                                                                  isEdit: true,
                                                                                  address: data,
                                                                                ));
                                                                            if (result) {
                                                                              controller.fetchAddress();
                                                                            }
                                                                            //
                                                                          },
                                                                          child:
                                                                              Image.asset(
                                                                            'assets/address_list/edit.png',
                                                                            height:
                                                                                35,
                                                                          ),
                                                                        ),
                                                                        InkWell(
                                                                          onTap:
                                                                              () {
                                                                            controller.DeleteAddress(id: data.id);
                                                                            //
                                                                          },
                                                                          child:
                                                                              Image.asset(
                                                                            'assets/address_list/delete.png',
                                                                            height:
                                                                                30,
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                ],
                                                              ),
                                                              regularText(
                                                                // text: 'A/234,King Plazaa, Mithakhali, Ahmedabad - 363655, Gujarat, India',
                                                                text:
                                                                    '${data.houseNo}, ${data.address}, ${data.city}-${data.pincode}, ${data.state}',
                                                                color:
                                                                    subTextColor,
                                                              ),
                                                              const SizedBox(
                                                                height: 10,
                                                              ),
                                                              RichText(
                                                                text: TextSpan(
                                                                  text: MOBILE[
                                                                      LANGUAGE_TYPE],
                                                                  style:
                                                                      const TextStyle(
                                                                    fontSize:
                                                                        16,
                                                                    color:
                                                                        blackColor,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w500,
                                                                    fontFamily:
                                                                        "Bold",
                                                                  ),
                                                                  children: <TextSpan>[
                                                                    TextSpan(
                                                                      text: data.phone ==
                                                                              null
                                                                          ? ''
                                                                          : '${data.phone}',
                                                                      style:
                                                                          TextStyle(
                                                                        // fontSize: size,
                                                                        color:
                                                                            subTextColor,
                                                                        fontSize:
                                                                            16,
                                                                        // letterSpacing: .5,
                                                                        fontWeight:
                                                                            FontWeight.w500,
                                                                        fontFamily:
                                                                            "Regular",
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              )
                                                            ],
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ],
                                                ),
                                              );
                                            }),
                                      ),
                                controller.isAddressNull
                                    ? customeElevatedButton(
                                        width, ADD_ADDRESS_ADD[LANGUAGE_TYPE],
                                        callback: () async {
                                        bool result = await Get.to(
                                            () => AddAddressScreen());
                                        if (result) {
                                          controller.fetchAddress();
                                        }
                                      })
                                    : SizedBox(
                                        height: 15,
                                      ),
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 0, vertical: 5),
                                  child: customeElevatedButtonSecond(
                                      MediaQuery.of(context).size.width,
                                      COLLECT_TO_THIS_ADDRESS[LANGUAGE_TYPE],
                                      callback: () {
                                    Get.back();
                                    // Navigator.pop(context);
                                  }),
                                ),
                              ],
                            ),
                          ),
                        );
            }),
          )
        ],
      ),
      // body: Column(
      //   children: [
      //     Text('${data.houseNo}'),
      //   ],
      // ),
    );
  }
}
