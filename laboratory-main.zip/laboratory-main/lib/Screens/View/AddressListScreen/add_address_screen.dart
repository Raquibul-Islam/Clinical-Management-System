import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:leboratory/Screens/Custome_Widgets/custome_widget.dart';

import '../../../Models/address_list_model.dart';
import '../../../componant/custome_appBar.dart';
import '../../../componant/validation_screen.dart';
import '../../../controller/add_address_controller.dart';
import '../../../utils/AllText.dart';
import '../../../utils/colors.dart';
import '../../../utils/strings.dart';

final formKey = GlobalKey<FormState>();

class AddAddressScreen extends StatelessWidget {
  final bool isEdit;
  final Datum? address;
  AddAddressScreen({Key? key, this.isEdit = false, this.address})
      : super(key: key);

  // final addAddressController = Get.put();

  @override
  Widget build(BuildContext context) {
    // addAddressController.init();
    final width = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: whiteColor,
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomAppBar(
              title: isEdit
                  ? EDIT_ADDRESS[LANGUAGE_TYPE]
                  : ADD_ADDRESS[LANGUAGE_TYPE],
              isArrow: true,
              isAction: false),
          GetBuilder<AddAddressController>(
            init: AddAddressController(address),
            builder: (controller) {
              return Expanded(
                child: SingleChildScrollView(
                  child: Form(
                    key: formKey,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            height: 450,
                            child: controller.isGoogleMapLoading
                                ? const Center(
                                    child: CircularProgressIndicator(),
                                  )
                                : GoogleMap(
                                    onMapCreated: controller.onMapCreated,
                                    scrollGesturesEnabled: true,
                                    initialCameraPosition: CameraPosition(
                                      target: controller.center!,
                                      zoom: 15.0,
                                    ),
                                    onTap: (latLang) {
                                      controller.onMapTap(latLang);
                                      //Toast.show(latLang.toString(), context,duration: 2);
                                    },
                                    buildingsEnabled: true,
                                    compassEnabled: true,
                                    markers: controller.markers.values.toSet(),
                                  ),
                          ),
                          // SizedBox(height: 10,),
                          Row(
                            children: [
                              regularText(text: 'Default Address'),
                              Checkbox(
                                fillColor: MaterialStateColor.resolveWith(
                                    (states) => blackColor),
                                value: controller.isDefaultAddress,
                                onChanged: (bool? value) {
                                  controller.changeIsDefaultAddress();
                                },
                              )
                            ],
                          ),
                          textFildHeader(ADDRESS[LANGUAGE_TYPE], width),
                          editCustomTextField(
                            validateAddress,
                            controller.tcAddress,
                            width,
                            ADDRESS[LANGUAGE_TYPE],
                          ),
                          SizedBox(
                            height: 19,
                          ),
                          Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    textFildHeader(
                                        HOUSENO[LANGUAGE_TYPE], width),
                                    editCustomTextField(
                                      validateHousNo,
                                      controller.tcHouseNo,
                                      width,
                                      HOUSENO[LANGUAGE_TYPE],
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                width: 15,
                              ),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    textFildHeader(STATE[LANGUAGE_TYPE], width),
                                    editCustomTextField(
                                      validateState,
                                      controller.tcState,
                                      width,
                                      STATE[LANGUAGE_TYPE],
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                width: 15,
                              ),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    textFildHeader(
                                        PINCODE[LANGUAGE_TYPE], width),
                                    editCustomTextField(
                                      textInputType: TextInputType.number,
                                      validatePinCode,
                                      controller.tcPincode,
                                      width,
                                      PINCODE[LANGUAGE_TYPE],
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 19),
                          textFildHeader(CITY[LANGUAGE_TYPE], width),
                          controller.isGettingManagersCity
                              ? const Center(
                                  child: CircularProgressIndicator(),
                                )
                              : DropdownButtonFormField<String>(
                                  value: controller.tcCity.text,
                                  validator: validateCity,
                                  style: TextStyle(
                                    fontWeight: FontWeight.w400,
                                    fontSize: width > 360 ? 16 : 14,
                                    color: blackColor,
                                    fontFamily: "Regular",
                                  ),
                                  decoration: const InputDecoration(
                                    border: UnderlineInputBorder(
                                      borderSide: BorderSide(color: blackColor),
                                    ),
                                    enabledBorder: UnderlineInputBorder(
                                      borderSide:
                                          BorderSide(color: subTextColor),
                                    ),
                                    focusedBorder: UnderlineInputBorder(
                                      borderSide: BorderSide(color: blackColor),
                                    ),
                                    focusColor: blackColor,
                                    fillColor: blackColor,
                                  ),
                                  items: controller.manageCityModel!.data!
                                      .map((label) => DropdownMenuItem<String>(
                                            child: Text(label!.name.toString()),
                                            value: label.name,
                                          ))
                                      .toList(),
                                  hint: Text(HINT_RELATION[LANGUAGE_TYPE]),
                                  onChanged: (value) {
                                    controller.changeCity(value);
                                  },
                                ),
                          // editCustomTextField(
                          //   validateCity,
                          //   controller.tcCity,
                          //   width,
                          //   CITY[LANGUAGE_TYPE],
                          // ),
                          SizedBox(height: 19),
                          textFildHeader(PHONE[LANGUAGE_TYPE], width),
                          editCustomTextField(
                            validatePhone,
                            controller.tcPhone,
                            width,
                            PHONE[LANGUAGE_TYPE],
                            textInputType: TextInputType.number,
                          ),
                          SizedBox(height: 19),
                          textFildHeader(SAVEAS[LANGUAGE_TYPE], width),
                          editCustomTextField(
                            validateSaveAS,
                            controller.tcSaveAS,
                            width,
                            SAVEAS[LANGUAGE_TYPE],
                          ),
                          SizedBox(height: 19),
                          controller.isAddingAddress
                              ? Center(
                                  child: CircularProgressIndicator(),
                                )
                              : customeElevatedButton(
                                  width,
                                  isEdit
                                      ? Update[LANGUAGE_TYPE]
                                      : Save[LANGUAGE_TYPE],
                                  callback: () {
                                    if (formKey.currentState!.validate()) {
                                      // controller.addNewMember();
                                      if (isEdit) {
                                        controller.addAddress(
                                            isEdit: true,
                                            addressId: address!.id);
                                      } else {
                                        controller.addAddress();
                                      }
                                    }
                                  },
                                ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
