import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:leboratory/controller/address_list_controller.dart';
import '../../../componant/custome_appBar.dart';
import '../../../utils/AllText.dart';
import '../../../utils/colors.dart';
import '../../../utils/strings.dart';
import '../../Custome_Widgets/custome_widget.dart';
import 'add_address_screen.dart';

class AddressListScreen extends StatefulWidget {
  const AddressListScreen({Key? key}) : super(key: key);

  @override
  State<AddressListScreen> createState() => _AddressListScreenState();
}

class _AddressListScreenState extends State<AddressListScreen> {
  int listLength = 5;
  AddressListController addressListController =
      Get.put(AddressListController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: themeSecondaryColor,
      body: Column(
        children: [
          ///------ appbar ------
          CustomAppBar(
              title: ADDRESS_LIST[LANGUAGE_TYPE],
              isArrow: true,
              isAction: false),
          Expanded(child: GetBuilder<AddressListController>(
            builder: (controller) {
              return controller.isLoading
                  ? const Center(
                      child: SizedBox(
                        height: 150,
                        width: 35,
                        child: Center(
                            child:
                                CircularProgressIndicator(color: themeColor)),
                      ),
                    )
                  : controller.data.isEmpty
                      ? FittedBox(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 20, vertical: 10),
                            child: customeElevatedButton(
                                MediaQuery.of(context).size.width,
                                ADD_ADDRESS[LANGUAGE_TYPE], callback: () async {
                              // Get.to(()=>AddAddressScreen());
                              bool result =
                                  await Get.to(() => AddAddressScreen());
                              if (result) {
                                controller.AddressList();
                              }
                              // Navigator.pop(context);
                            }),
                          ),
                        )
                      // Container(
                      //             alignment: Alignment.center,
                      //             child: const Text('No Data Found',
                      //                 style: TextStyle(
                      //                   color: blackColor,
                      //                   fontSize: 15,
                      //                   fontWeight: FontWeight.w300,
                      //                 )),
                      //           )
                      : ListView.builder(
                          // physics: NeverScrollableScrollPhysics(),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 10),
                          // itemCount: listLength + 1,
                          itemCount: addressListController.data.length + 1,
                          shrinkWrap: true,
                          itemBuilder: (context, index) {
                            return addressListController.data.length != index
                                ? AddressDetailCard(
                                    data: addressListController.data[index])
                                : Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 0, vertical: 10),
                                    child: customeElevatedButton(
                                        MediaQuery.of(context).size.width,
                                        ADD_ADDRESS[LANGUAGE_TYPE],
                                        callback: () async {
                                      bool result = await Get.to(
                                          () => AddAddressScreen());
                                      if (result) {
                                        controller.AddressList();
                                      }
                                      // Navigator.pop(context);
                                    }),
                                  );
                          },
                        );
            },
          )),
        ],
      ),
    );
  }
}

class AddressDetailCard extends StatelessWidget {
  var data;

  AddressDetailCard({this.data});

  AddressListController addressListController =
      Get.put(AddressListController());

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(top: 5, bottom: 5),
      // padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      padding: const EdgeInsets.only(right: 10, left: 10, bottom: 10, top: 5),
      decoration: BoxDecoration(
          color: whiteColor, borderRadius: BorderRadius.circular(15)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // Flexible(child: Text('Home')),
              Flexible(
                child: boldText(
                  text: data.name,
                  size: 16,
                  color: blackColor,
                ),
              ),
              Row(
                children: [
                  InkWell(
                    onTap: () async {
                      bool result = await Get.to(() => AddAddressScreen(
                            isEdit: true,
                            address: data,
                          ));
                      if (result) {
                        addressListController.AddressList();
                      }
                      // Get.to(()=>AddAddressScreen(isEdit: true,address: data,));
                    },
                    child: Image.asset(
                      'assets/address_list/edit.png',
                      height: 35,
                    ),
                  ),
                  addressListController.isDeleteLoading == true
                      ? Container(
                          height: 15,
                          width: 15,
                          child: CircularProgressIndicator())
                      : InkWell(
                          onTap: () async {
                            bool result =
                                await addressListController.DeleteAddress(
                                    id: data.id);
                            if (result) {
                              addressListController.AddressList();
                            }
                            //
                          },
                          child: Image.asset(
                            'assets/address_list/delete.png',
                            height: 30,
                          ),
                        ),
                ],
              ),
            ],
          ),
          regularText(
            text: data.address,
            color: subTextColor,
          ),
          const SizedBox(
            height: 10,
          ),
          RichText(
            text: TextSpan(
              text: 'Mobile: ',
              style: TextStyle(
                fontSize: 16,
                color: blackColor,
                fontWeight: FontWeight.w500,
                fontFamily: "Bold",
              ),
              children: <TextSpan>[
                TextSpan(
                  text: data.phone == null ? '' : '${data.phone}',
                  style: TextStyle(
                    // fontSize: size,
                    color: subTextColor,
                    fontSize: 16,
                    // letterSpacing: .5,
                    fontWeight: FontWeight.w500,
                    fontFamily: "Regular",
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
