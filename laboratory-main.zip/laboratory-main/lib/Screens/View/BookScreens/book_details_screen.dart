import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:intl/intl.dart';
import 'package:leboratory/Screens/Custome_Widgets/custome_widget.dart';
import 'package:leboratory/main.dart';
import 'package:leboratory/utils/colors.dart';
import 'package:map_launcher/map_launcher.dart';
import 'package:timelines/timelines.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../componant/custome_appBar.dart';
import '../../../controller/book_detail_controller.dart';
import '../../../utils/AllText.dart';
import '../../../utils/App_Images.dart';
import '../../../utils/strings.dart';
import '../../Custome_Widgets/persondetail_cardview.dart';
import '../../Custome_Widgets/total_card_widget.dart';
import '../report_view_screen.dart';
import 'package:google_maps_flutter_platform_interface/src/types/ui.dart';

class BookDetailsScreen extends StatelessWidget {
  final String orderId;

  BookDetailsScreen({Key? key, required this.orderId}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: themeSecondaryColor,
      body: Column(
        children: [
          CustomAppBar(
              title: BOOK_DETAILS[LANGUAGE_TYPE],
              isArrow: true,
              isAction: false),
          Expanded(
            child: GetBuilder<BookDetailController>(
                init: BookDetailController(orderId),
                builder: (controller) {
                  return controller.isLoading
                      ? Center(
                          child: CircularProgressIndicator(),
                        )
                      : SingleChildScrollView(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              /// Order Detail
                              Container(
                                margin: const EdgeInsets.all(10),
                                padding: const EdgeInsets.all(8.0),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(15),
                                  image: const DecorationImage(
                                    fit: BoxFit.fill,
                                    image: AssetImage(
                                      AppImages.defaultImage,
                                    ),
                                  ),
                                ),
                                child: Row(
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.all(10),
                                      decoration: const BoxDecoration(
                                        color: whiteColor,
                                        shape: BoxShape.circle,
                                      ),
                                      child: const Icon(
                                        Icons.book_outlined,
                                        size: 50,
                                      ),
                                    ),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          boldText(
                                              text:
                                                  '${BOOK_ID[LANGUAGE_TYPE]} #${controller.bookingDetailModel?.data!.id}',
                                              color: whiteColor,
                                              size: 14),
                                          const SizedBox(
                                            height: 5,
                                          ),
                                          regularText(
                                              text:
                                                  // '${PLACED_ON[LANGUAGE_TYPE]} Jan 29,2021',
                                                  '${PLACED_ON[LANGUAGE_TYPE]} ${DateFormat.yMMMMd().format(controller.bookingDetailModel?.data?.date ?? DateTime.now())}',
                                              size: 12,
                                              color: subTextColor),
                                          const SizedBox(
                                            height: 5,
                                          ),
                                          regularText(
                                              text:
                                                  '$CURRENCY${controller.bookingDetailModel!.data!.finalTotal} ${PAID_BY[LANGUAGE_TYPE]} ${controller.bookingDetailModel!.data!.paymentMethod}',
                                              color: whiteColor,
                                              size: 12),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),

                              /// Time Line

                              // Reject time line
                              controller.bookingDetailModel!.data!.status ==
                                          3 ||
                                      controller.bookingDetailModel!.data!
                                              .status ==
                                          4
                                  ? Container(
                                      width: width,
                                      margin: const EdgeInsets.only(
                                          top: 05,
                                          bottom: 15,
                                          right: 10,
                                          left: 10),
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 8.0, vertical: 12),
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(15),
                                        color: whiteColor,
                                      ),
                                      child: FixedTimeline.tileBuilder(
                                        theme: TimelineThemeData(
                                          nodePosition: 0.18,
                                          color: themeColor,
                                        ),
                                        builder: TimelineTileBuilder.connected(
                                          contentsAlign: ContentsAlign.basic,
                                          oppositeContentsBuilder:
                                              (context, index) => Padding(
                                            padding: const EdgeInsets.only(
                                                left: 10,
                                                bottom: 20,
                                                top: 10,
                                                right: 10),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                regularText(
                                                    text: controller
                                                        .rejectTimeLineDetail[
                                                            index]
                                                        .time)
                                              ],
                                            ),
                                          ),
                                          contentsBuilder: (context, index) =>
                                              Padding(
                                            padding: const EdgeInsets.only(
                                                left: 10, bottom: 20, top: 8),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                boldText(
                                                    text: controller
                                                        .rejectTimeLineDetail[
                                                            index]
                                                        .title,
                                                    color: blackColor),
                                                regularText(
                                                    text: controller
                                                        .rejectTimeLineDetail[
                                                            index]
                                                        .des,
                                                    color: subTextColor,
                                                    size: 12)
                                              ],
                                            ),
                                          ),
                                          indicatorPositionBuilder:
                                              (context, index) => 0.18,
                                          itemCount: controller
                                              .rejectTimeLineDetail.length,
                                          indicatorBuilder: (_, index) {
                                            if (controller
                                                .rejectTimeLineDetail[index]
                                                .isTrue) {
                                              return const DotIndicator(
                                                color: themeColor,
                                                child: Icon(
                                                  Icons.check,
                                                  color: Colors.white,
                                                  size: 15.0,
                                                ),
                                              );
                                            } else {
                                              return const OutlinedDotIndicator(
                                                borderWidth: 1,
                                                color: subTextColor,
                                              );
                                            }
                                          },
                                          connectorBuilder: (_, index, ___) =>
                                              DashedLineConnector(
                                            gap: 4,
                                            thickness: 1,
                                            dash: 2,
                                            color: controller
                                                    .rejectTimeLineDetail[index]
                                                    .isTrue
                                                ? themeColor
                                                : subTextColor,
                                          ),
                                        ),
                                      ),
                                    )
                                  : Container(
                                      width: width,
                                      margin: const EdgeInsets.only(
                                          top: 05,
                                          bottom: 15,
                                          right: 10,
                                          left: 10),
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 8.0, vertical: 12),
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(15),
                                        color: whiteColor,
                                      ),
                                      child: FixedTimeline.tileBuilder(
                                        theme: TimelineThemeData(
                                          nodePosition: 0.18,
                                          color: themeColor,
                                        ),
                                        builder: TimelineTileBuilder.connected(
                                          contentsAlign: ContentsAlign.basic,
                                          oppositeContentsBuilder:
                                              (context, index) => Padding(
                                            padding: const EdgeInsets.only(
                                                left: 10,
                                                bottom: 20,
                                                top: 10,
                                                right: 10),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                regularText(
                                                    text: controller
                                                        .timeLineDetail[index]
                                                        .time)
                                              ],
                                            ),
                                          ),
                                          contentsBuilder: (context, index) =>
                                              Padding(
                                            padding: const EdgeInsets.only(
                                                left: 10, bottom: 20, top: 8),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                boldText(
                                                    text: controller
                                                        .timeLineDetail[index]
                                                        .title,
                                                    color: blackColor),
                                                regularText(
                                                    text: controller
                                                        .timeLineDetail[index]
                                                        .des,
                                                    color: subTextColor,
                                                    size: 12)
                                              ],
                                            ),
                                          ),
                                          indicatorPositionBuilder:
                                              (context, index) => 0.18,
                                          itemCount:
                                              controller.timeLineDetail.length,
                                          indicatorBuilder: (_, index) {
                                            if (controller
                                                .timeLineDetail[index].isTrue) {
                                              return const DotIndicator(
                                                color: themeColor,
                                                child: Icon(
                                                  Icons.check,
                                                  color: Colors.white,
                                                  size: 15.0,
                                                ),
                                              );
                                            } else {
                                              return const OutlinedDotIndicator(
                                                borderWidth: 1,
                                                color: subTextColor,
                                              );
                                            }
                                          },
                                          connectorBuilder: (_, index, ___) =>
                                              DashedLineConnector(
                                            gap: 4,
                                            thickness: 1,
                                            dash: 2,
                                            color: controller
                                                    .timeLineDetail[index]
                                                    .isTrue
                                                ? themeColor
                                                : subTextColor,
                                          ),
                                        ),
                                      ),
                                    ),

                              /// Collection Address
                              Container(
                                width: width,
                                margin: const EdgeInsets.only(
                                    top: 0, bottom: 05, right: 10, left: 10),
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 8.0, vertical: 12),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(15),
                                  color: whiteColor,
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    boldText(
                                        text: COLLECTION_ADDRESS[LANGUAGE_TYPE],
                                        size: 16),
                                    const Divider(
                                      color: subTextColor,
                                    ),
                                    Row(
                                      children: [
                                        Container(
                                          height: 110,
                                          width: 110,
                                          child: InkWell(
                                            onTap: () async {
                                              // controller.launchMap();
                                              final availableMaps =
                                                  await MapLauncher
                                                      .installedMaps;
                                              await availableMaps[0].showMarker(
                                                coords: controller.coords!,
                                                title: "Your Location",
                                              );
                                            },
                                            child: Stack(
                                              children: [
                                                ClipRRect(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            10),
                                                    child: Image.asset(
                                                      "assets/book_detail/map.jpg",
                                                      fit: BoxFit.fill,
                                                      // height: 110,
                                                      // width: 130,
                                                    )),
                                                Align(
                                                  alignment: Alignment.center,
                                                  child: Center(
                                                    child: Image.asset(
                                                      "assets/pin.png",
                                                      height: 30,
                                                      width: 30,
                                                    ),
                                                  ),
                                                )
                                              ],
                                            ),
                                          ),
                                        ),
                                        Expanded(
                                          flex: 2,
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Row(
                                                // mainAxisAlignment: MainAxisAlignment.start,
                                                children: [
                                                  // for (var map in availableMaps)
                                                  //   ListTile(
                                                  //     onTap: () => map.showMarker(
                                                  //       coords: coords,
                                                  //       title: title,
                                                  //     ),
                                                  //     title: Text(map.mapName),
                                                  //     leading: SvgPicture.asset(
                                                  //       map.icon,
                                                  //       height: 30.0,
                                                  //       width: 30.0,
                                                  //     ),
                                                  //   ),
                                                  Image.asset(
                                                    'assets/book_detail/location.png',
                                                    height: 40,
                                                  ),
                                                  Flexible(
                                                    child: regularText(
                                                        text: controller
                                                                    .bookingDetailModel!
                                                                    .data!
                                                                    .useraddressdetails ==
                                                                null
                                                            ? ""
                                                            : '${controller.bookingDetailModel!.data!.useraddressdetails!.houseNo}, ${controller.bookingDetailModel!.data!.useraddressdetails!.address}, ${controller.bookingDetailModel!.data!.useraddressdetails!.city}-${controller.bookingDetailModel!.data!.useraddressdetails!.pincode}, ${controller.bookingDetailModel!.data!.useraddressdetails!.state} ',
                                                        size: 12,
                                                        color: blackColor),
                                                  ),
                                                ],
                                              ),
                                              Row(
                                                children: [
                                                  Image.asset(
                                                    'assets/book_detail/contact.png',
                                                    height: 40,
                                                  ),
                                                  Flexible(
                                                    child: regularText(
                                                        text:
                                                            '${controller.bookingDetailModel!.data!.phone.toString()}',
                                                        color: blackColor,
                                                        size: 12),
                                                  ),
                                                ],
                                              ),
                                              Padding(
                                                padding: const EdgeInsets.only(
                                                    left: 13),
                                                child: Row(
                                                  children: [
                                                    Row(
                                                      children: [
                                                        Image.asset(
                                                          'assets/book_detail/date.png',
                                                          height: 15,
                                                        ),
                                                        const SizedBox(
                                                          width: 10,
                                                        ),
                                                        regularText(
                                                            text:
                                                                '${DateFormat.yMMMMd().format(controller.bookingDetailModel!.data!.date!)}',
                                                            color: blackColor,
                                                            size: 12),
                                                      ],
                                                    ),
                                                    const SizedBox(
                                                      width: 15,
                                                    ),
                                                    Row(
                                                      children: [
                                                        Image.asset(
                                                          'assets/book_detail/time.png',
                                                          height: 15,
                                                        ),
                                                        const SizedBox(
                                                          width: 10,
                                                        ),
                                                        regularText(
                                                            text:
                                                                '${controller.bookingDetailModel!.data!.time}',
                                                            size: 12,
                                                            color: blackColor),
                                                      ],
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        )
                                      ],
                                    )
                                  ],
                                ),
                              ),

                              /// Person Detail CardView
                              Container(
                                child: ListView.builder(
                                    padding: EdgeInsets.zero,
                                    shrinkWrap: true,
                                    physics: NeverScrollableScrollPhysics(),
                                    itemCount: controller.bookingDetailModel!
                                        .data!.orderdata!.length,
                                    itemBuilder: (context, index) {
                                      var userData = controller
                                          .bookingDetailModel!
                                          .data!
                                          .orderdata![index];
                                      var packageData = controller
                                          .bookingDetailModel!
                                          .data!
                                          .orderdata![index]
                                          .testdata!;
                                      return PersonPackageDetailCardView(
                                        width: width,
                                        name:
                                            '${userData.memberName} | ${userData.relation}   ',
                                        detail:
                                            '${userData.gender},${userData.age} years',
                                        cardItem: 2,
                                        isSimple: true,
                                        testdatum: packageData,
                                        memberId: 2,
                                      );
                                    }),
                              ),
                              // PersonPackageDetailCardView(
                              //   width: width,
                              //   name: 'Hetal | Self   ',
                              //   detail: 'Female,24 years',
                              //   cardItem: 2,
                              //   isSimple: true, testdatum: controller.bookingDetailModel!.data.orderdata.,
                              // ),
                              // PersonPackageDetailCardView(
                              //   width: width,
                              //   name: 'Vishal | Self   ',
                              //   detail: 'Male,24 years',
                              //   cardItem: 1,
                              //   isSimple: true,
                              // ),

                              const SizedBox(
                                height: 5,
                              ),

                              /// Total Card
                              TotalCard(
                                subTotal:
                                    '$CURRENCY${controller.bookingDetailModel!.data!.subtotal}.00',
                                total:
                                    '$CURRENCY${controller.bookingDetailModel!.data!.finalTotal}.00',
                                tax:
                                    '$CURRENCY${controller.bookingDetailModel!.data!.tax}.00',
                                isShowSavingAmount: false,
                                width: width,
                              ),

                              /// Button
                              controller.bookingDetailModel!.data!.status == 7
                                  ? controller.isFeedbackLoading
                                      ? Center(
                                          child: Padding(
                                            padding: const EdgeInsets.only(
                                                top: 15.0,
                                                right: 10,
                                                left: 10,
                                                bottom: 15),
                                            child: CircularProgressIndicator(),
                                          ),
                                        )
                                      : Padding(
                                          padding: const EdgeInsets.only(
                                              top: 15.0,
                                              right: 10,
                                              left: 10,
                                              bottom: 15),
                                          child: Row(
                                            children: [
                                              customeElevatedButtonOutLine(
                                                  width / 2.20,
                                                  FEEDBACK[LANGUAGE_TYPE],
                                                  color: themeSecondaryColor,
                                                  callback: () {
                                                feedBackDialog(context);
                                                // save();
                                                // Navigator.pop(context);
                                              }),
                                              const Spacer(),
                                              customeElevatedButton(
                                                width / 2.20,
                                                REPORT[LANGUAGE_TYPE],
                                                callback: () {
                                                  if (controller
                                                              .bookingDetailModel!
                                                              .data!
                                                              .report ==
                                                          null ||
                                                      controller
                                                              .bookingDetailModel!
                                                              .data!
                                                              .report ==
                                                          '') {
                                                    Get.snackbar(
                                                      'Report not uploaded yet!',
                                                      'Report show after upload',
                                                      snackPosition:
                                                          SnackPosition.BOTTOM,
                                                      backgroundColor:
                                                          Colors.red,
                                                    );
                                                  } else {
                                                    Get.to(
                                                        () => ReportViewScreen(
                                                              name: controller
                                                                  .bookingDetailModel!
                                                                  .data!
                                                                  .report,
                                                            ));

                                                  }
                                                  // Navigator.pop(context);
                                                },
                                              ),
                                            ],
                                          ),
                                        )
                                  : Container(),
                              SizedBox(
                                height: 10,
                              )
                            ],
                          ),
                        );
                }),
          )
        ],
      ),
    );
  }

  feedBackDialog(context) {
    final controller = Get.find<BookDetailController>();
    Get.dialog(
      Center(
        child: Container(
          margin: EdgeInsets.symmetric(horizontal: 20),
          padding: EdgeInsets.symmetric(vertical: 20),
          width: MediaQuery.of(context).size.width,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: darkBlue,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  boldText(text: 'Give Feedback', color: whiteColor, size: 26),
                  SizedBox(
                    width: 5,
                  ),
                  Image.asset(
                    'assets/book_detail/happy.png',
                    height: 24,
                  )
                ],
              ),
              SizedBox(
                height: 10,
              ),
              regularText(
                  text: 'What do you thhink of the editing tool?',
                  size: 16,
                  color: subTextColor),
              SizedBox(
                height: 20,
              ),
              // Row(
              //   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              //   children: [
              //     controller.selectedRating >= 1? Image.asset(controller.s1,height: controller.iconSize,):Image.asset(controller.us1,height: controller.iconSize,),
              //     controller.selectedRating >= 2? Image.asset(controller.s2,height: controller.iconSize,):Image.asset(controller.us2,height: controller.iconSize,),
              //     controller.selectedRating >= 3? Image.asset(controller.s3,height: controller.iconSize,):Image.asset(controller.us3,height: controller.iconSize,),
              //     controller.selectedRating >= 4? Image.asset(controller.s4,height: controller.iconSize,):Image.asset(controller.us4,height: controller.iconSize,),
              //     controller.selectedRating >= 5? Image.asset(controller.s5,height: controller.iconSize,):Image.asset(controller.us5,height: controller.iconSize,),
              //   ],
              // ),
              RatingBar.builder(
                initialRating: controller.selectedRating,
                itemCount: 5,
                itemSize: 50,
                itemPadding: EdgeInsets.symmetric(horizontal: 5),
                unratedColor: Colors.grey,
                itemBuilder: (context, index) {
                  switch (index) {
                    case 0:
                      return Icon(
                        Icons.sentiment_very_dissatisfied,
                        color: Colors.amber,
                      );
                    case 1:
                      return Icon(
                        Icons.sentiment_dissatisfied,
                        color: Colors.amber,
                      );
                    case 2:
                      return Icon(
                        Icons.sentiment_neutral,
                        color: Colors.amber,
                      );
                    case 3:
                      return Icon(
                        Icons.sentiment_satisfied,
                        color: Colors.amber,
                      );
                    case 4:
                      return Icon(
                        Icons.sentiment_very_satisfied,
                        color: Colors.amber,
                      );
                    default:
                      return Container();
                  }
                },
                onRatingUpdate: (rating) {
                  //
                  controller.selectedRating = rating;

                },
              ),
              SizedBox(
                height: 20,
              ),
              Material(
                color: darkBlue,
                child: Container(
                  color: whiteColor,
                  margin: EdgeInsets.symmetric(horizontal: 20),
                  padding: EdgeInsets.symmetric(horizontal: 10),
                  child: TextField(
                    textInputAction: TextInputAction.done,
                    style: TextStyle(
                      fontFamily: "Regular",
                      fontSize: 14,
                    ),
                    controller: controller.tcFeedback,
                    maxLines: 5,
                    decoration: InputDecoration(
                        focusedBorder: InputBorder.none,
                        focusedErrorBorder: InputBorder.none,
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        hintText: 'Type Something you want here...',
                        hintStyle: TextStyle(
                          fontFamily: "Regular",
                          fontSize: 12,
                        )),
                  ),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  children: [
                    Expanded(
                      child: customeElevatedButtonOutLine(
                          double.infinity, 'Cancel', callback: () {
                        controller.tcFeedback.clear();
                        controller.selectedRating = 4;
                        Get.back();
                      },
                          color: darkBlue,
                          textColor: whiteColor,
                          borderColor: whiteColor),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Expanded(
                      child: customeElevatedButtonOutLine(
                          double.infinity, 'Submit', callback: () {
                        controller.submitFeedback();
                      }, color: whiteColor, borderColor: whiteColor),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );

    // Widget ratingIcon(int i){
    //   return  Image.asset(controller.s1,height: controller.iconSize,);
    // }
  }
}

class TimeLineDetail {
  String time;
  String title;
  String des;
  bool isTrue;

  TimeLineDetail(
      {required this.time,
      required this.title,
      required this.des,
      required this.isTrue});
}
