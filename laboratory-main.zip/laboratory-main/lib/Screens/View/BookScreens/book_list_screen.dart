import 'package:dotted_line/dotted_line.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:leboratory/componant/custome_appBar.dart';
import 'package:leboratory/main.dart';
import '../../../controller/book_controller.dart';
import '../../../utils/AllText.dart';
import '../../../utils/colors.dart';
import '../../../utils/strings.dart';
import '../../Custome_Widgets/custome_widget.dart';
import 'book_details_screen.dart';

class BookListScreen extends StatefulWidget {
  const BookListScreen({Key? key}) : super(key: key);

  @override
  State<BookListScreen> createState() => _BookListScreenState();
}

class _BookListScreenState extends State<BookListScreen>
    with SingleTickerProviderStateMixin {
  TabController? _tabController;
  int isSelected = 0;

  List<int> list = [0, 1, 1, 2, 0, 1, 2];

  BookController categoryListController = Get.put(BookController());

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _tabController?.addListener(_handleTabSelection);
    // categoryListController.dataCall();
  }

  _handleTabSelection() {
    if (!_tabController!.indexIsChanging) {
      categoryListController.changeTabIndex(_tabController!.index);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: themeSecondaryColor,
      body: GetBuilder<BookController>(builder: (controller) {
        return Container(
          child: Column(
            children: [
              ///------ appbar ------
              CustomAppBar(
                title: Book_List[LANGUAGE_TYPE],
                isArrow: true,
                isAction: true,
                isCustomWidget: true,
                // widget: PopupMenuButton(
                //   offset: const Offset(30, 50),
                //   shape: RoundedRectangleBorder(
                //     borderRadius: BorderRadius.circular(10),
                //   ),
                //   icon: Image.asset(
                //     'assets/profile/filter.png',
                //     scale: 3.5,
                //   ),
                //   //don't specify icon if you want 3 dot menu
                //   color: darkBlue,
                //   itemBuilder: (context) => [
                //     PopupMenuItem<BookListFilterENUM>(
                //       onTap: () {
                //         controller.changeFilter(BookListFilterENUM.upcoming);
                //       },
                //       value: BookListFilterENUM.upcoming,
                //       child: Row(
                //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
                //         children: [
                //           regularText(text: 'Upcoming', color: whiteColor),
                //           Radio(
                //             activeColor: whiteColor,
                //             value: BookListFilterENUM.upcoming,
                //             groupValue: controller.bookListFilterENUM,
                //             onChanged: (BookListFilterENUM? value) {
                //               controller.changeFilter(value);
                //               Navigator.pop(context);
                //             },
                //             fillColor: MaterialStateColor.resolveWith(
                //                 (states) => whiteColor),
                //           ),
                //         ],
                //       ),
                //     ),
                //     PopupMenuItem<BookListFilterENUM>(
                //       onTap: () {
                //         controller.changeFilter(BookListFilterENUM.past);
                //       },
                //       value: BookListFilterENUM.past,
                //       child: Row(
                //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
                //         children: [
                //           regularText(text: 'Past', color: whiteColor),
                //           Radio(
                //             activeColor: whiteColor,
                //             value: BookListFilterENUM.past,
                //             groupValue: controller.bookListFilterENUM,
                //             onChanged: (BookListFilterENUM? value) {
                //               controller.changeFilter(value);
                //               Navigator.pop(context);
                //             },
                //             fillColor: MaterialStateColor.resolveWith(
                //                 (states) => whiteColor),
                //           ),
                //         ],
                //       ),
                //     ),
                //     PopupMenuItem<BookListFilterENUM>(
                //       onTap: () {
                //         controller.changeFilter(BookListFilterENUM.today);
                //       },
                //       value: BookListFilterENUM.today,
                //       child: Row(
                //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
                //         children: [
                //           regularText(text: 'Today', color: whiteColor),
                //           Radio(
                //             activeColor: whiteColor,
                //             value: BookListFilterENUM.today,
                //             groupValue: controller.bookListFilterENUM,
                //             onChanged: (BookListFilterENUM? value) {
                //               controller.changeFilter(value);
                //               Navigator.pop(context);
                //             },
                //             fillColor: MaterialStateColor.resolveWith(
                //                 (states) => whiteColor),
                //           ),
                //         ],
                //       ),
                //     ),
                //   ],
                //   onSelected: (item) => {print(item)},
                // ),
                widget: Container(),
              ),
              Expanded(
                child: Column(
                  children: [
                    Container(
                      margin: const EdgeInsets.only(left: 10, right: 10),
                      child: TabBar(
                        indicatorPadding:
                            const EdgeInsets.only(left: 10, right: 10),
                        indicatorWeight: 3,
                        indicatorColor: blackColor,
                        labelColor: blackColor,
                        unselectedLabelColor: subTextColor,
                        labelStyle: const TextStyle(
                            fontSize: 18, fontFamily: 'Regular'),
                        controller: _tabController,
                        tabs: [
                          Tab(
                            text: All[LANGUAGE_TYPE],
                          ),
                          Tab(
                            text: Pending[LANGUAGE_TYPE],
                          ),
                          Tab(
                            text: Rejected[LANGUAGE_TYPE],
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: TabBarView(
                        controller: _tabController,
                        children: <Widget>[
                          GetBuilder<BookController>(
                              builder: (BookController controller) {
                            return controller.isFirstLoading
                                ? loadingWidget()
                                : allData(controller);
                          }),
                          GetBuilder<BookController>(
                              builder: (BookController controller) {
                            return controller.isSecondLoading
                                ? loadingWidget()
                                : allData(controller);
                          }),
                          GetBuilder<BookController>(
                              builder: (BookController controller) {
                            return controller.isThirdLoading
                                ? loadingWidget()
                                : allData(controller);
                          }),
                          // const Center(
                          //   child: Text("Coming Soon"),
                          // ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      }),
    );
  }

  Column loadingWidget() {
    return Column(
      children: const [
        Center(
            child: Padding(
          padding: EdgeInsets.only(top: 60.0),
          child: CircularProgressIndicator(
            color: themeColor,
          ),
        )),
      ],
    );
  }

  Widget allData(BookController controller) {
    return SingleChildScrollView(
      controller: controller.scrollController,
      child: Column(
        children: [
          Container(
            child: controller.isLoading
                ? const Center(
                    child: Padding(
                      padding: EdgeInsets.only(top: 60.0),
                      child: CircularProgressIndicator(
                        color: themeColor,
                      ),
                    ),
                  )
                : controller.orderData!.isEmpty
                    ? Center(
                        child: Padding(
                        padding: const EdgeInsets.only(top: 60.0),
                        child: regularText(text: NO_DATA[LANGUAGE_TYPE]),
                      ))
                    : ListView.builder(
                        physics: const BouncingScrollPhysics(),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 10),
                        shrinkWrap: true,
                        itemCount: controller.orderData!.length,
                        itemBuilder: (context, index) {
                          var data = controller.orderData![index];
                          return DetailCard(
                            status: data.status!,
                            paymentType: data.paymentMethod!,
                            date: data.date!,
                            orderId: data.id.toString(),
                            time: data.time!,
                            amount: data.finalTotal!,
                          );
                        },
                      ),
          ),
          if (controller.isListLoading && !controller.isLoading)
            const Center(
              child: Padding(
                padding: EdgeInsets.only(bottom: 8.0),
                child: CircularProgressIndicator(
                  color: themeColor,
                ),
              ),
            )
        ],
      ),
    );
  }
}

class DetailCard extends StatelessWidget {
  const DetailCard({
    Key? key,
    required this.status,
    required this.orderId,
    required this.date,
    required this.time,
    required this.paymentType,
    required this.amount,
  }) : super(key: key);

  final String orderId;
  final DateTime date;
  final String time;
  final String paymentType;
  final int status;
  final double amount;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Get.to(() => BookDetailsScreen(
              orderId: orderId,
            ));
      },
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 5),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        decoration: BoxDecoration(
            color: whiteColor, borderRadius: BorderRadius.circular(15)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                RichText(
                  text: TextSpan(
                    text: BOOK_ID[LANGUAGE_TYPE],
                    style: const TextStyle(
                      fontFamily: "Bold",
                      color: blackColor,
                    ),
                    children: <TextSpan>[
                      TextSpan(
                          text: '#$orderId',
                          style: const TextStyle(
                              fontFamily: 'bold', color: blackColor)),
                    ],
                  ),
                ),
                regularTextSecond(
                    text: '$CURRENCY${amount}', color: blackColor),
              ],
            ),
            const SizedBox(
              height: 10,
            ),
            Row(
              children: [
                Image.asset(
                  'assets/book_list/date.png',
                  height: 15,
                ),
                const SizedBox(
                  width: 5,
                ),
                regularText(
                  text: DateFormat.yMMMMd().format(date),
                  color: subTextColor,
                ),
                const SizedBox(
                  width: 15,
                ),
                Image.asset(
                  'assets/book_list/time.png',
                  height: 15,
                ),
                const SizedBox(
                  width: 5,
                ),
                // regularText(text: '02 : 27 PM', color: subTextColor),
                regularText(
                    text: DateFormat.jm()
                        .format(DateFormat("hh:mm:ss").parse(time + ':00')),
                    color: subTextColor),
              ],
            ),
            const SizedBox(
              height: 10,
            ),
            const DottedLine(
              direction: Axis.horizontal,
              lineLength: double.infinity,
              lineThickness: 1.0,
              dashLength: 4.0,
              dashColor: subTextColor,
              dashRadius: 0.0,
              dashGapLength: 4.0,
              dashGapRadius: 0.0,
            ),
            const SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                RichText(
                  text: TextSpan(
                    text: PAYMENT_TYPE[LANGUAGE_TYPE],
                    style: const TextStyle(
                      fontFamily: "Regular",
                      color: subTextColor,
                    ),
                    children: <TextSpan>[
                      TextSpan(
                          text: paymentType,
                          style: const TextStyle(
                              fontFamily: 'Bold', color: blackColor)),
                    ],
                  ),
                ),
                statusWidget(status),
              ],
            )
          ],
        ),
      ),
    );
  }

  ///1=>pending,2=>accept,3=>reject,4=>refund,5=>collected,6=>preparing,7=>complete
  Color findBgColor(int status) {
    if (status == 1) {
      return const Color(0xffffe5b5);
    } else if (status == 7) {
      return const Color(0xffc8efd0);
    } else if (status == 3) {
      return const Color(0xffffbcbc);
    } else if (status == 2) {
      return const Color(0xffffe5b5);
    } else if (status == 4) {
      return const Color(0xffc8efd0);
    } else if (status == 5) {
      return const Color(0xffc8efd0);
    } else if (status == 6) {
      return const Color(0xffc8efd0);
    }
    return Colors.transparent;
  }

  ///1=>pending,2=>accept,3=>reject,4=>refund,5=>collected,6=>preparing,7=>complete
  Color findTextColor(int status) {
    if (status == 1) {
      return const Color(0xfff87c01);
    } else if (status == 7) {
      return const Color(0xff19742b);
    } else if (status == 3) {
      return const Color(0xffea0404);
    } else if (status == 2) {
      return const Color(0xfff87c01);
    } else if (status == 4) {
      return const Color(0xff19742b);
    } else if (status == 5) {
      return const Color(0xff19742b);
    } else if (status == 6) {
      return const Color(0xff19742b);
    }
    return Colors.transparent;
  }

  ///1=>pending,2=>accept,3=>reject,4=>refund,5=>collected,6=>preparing,7=>complete
  String findText(int status) {
    if (status == 1) {
      return PENDING[LANGUAGE_TYPE];
    } else if (status == 7) {
      return COMPLATE[LANGUAGE_TYPE];
    } else if (status == 3) {
      return REJECT[LANGUAGE_TYPE];
    } else if (status == 2) {
      return 'Accept';
    } else if (status == 4) {
      return 'Refund';
    } else if (status == 5) {
      return 'Collected';
    } else if (status == 6) {
      return 'Preparing';
    }
    return '';
  }

  Widget statusWidget(int status) {
    ///1=>pending,2=>accept,3=>reject,4=>refund,5=>collected,6=>preparing,7=>complete
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
      decoration: BoxDecoration(
          color: findBgColor(status), borderRadius: BorderRadius.circular(5)),
      child: Text(
        findText(status),
        style: TextStyle(
            color: findTextColor(status), fontFamily: 'Regular', fontSize: 10),
      ),
    );
  }
}
