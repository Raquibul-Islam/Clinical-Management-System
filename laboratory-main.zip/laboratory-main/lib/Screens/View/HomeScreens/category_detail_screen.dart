import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:get/get.dart';
import 'package:leboratory/Screens/Custome_Widgets/custome_widget.dart';
import 'package:leboratory/Screens/View/HomeScreens/package_details_screen.dart';
import 'package:leboratory/Screens/View/HomeScreens/parameter_details_screen.dart';
import 'package:leboratory/Screens/View/HomeScreens/profile_details_screen.dart';
import 'package:leboratory/controller/category_detail_controller.dart';
import 'package:leboratory/main.dart';
import 'package:leboratory/utils/colors.dart';

import '../../../Models/popularPackageModel.dart';
import '../../../componant/custome_appBar.dart';
import '../../../utils/AllText.dart';
import '../../../utils/App_Images.dart';
import '../../../utils/strings.dart';

class CategoryDetailScreen extends StatelessWidget {
  final int id;

  CategoryDetailScreen({Key? key, required this.id}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: themeSecondaryColor,
      body: GetBuilder<CategoryDetailController>(
          init: CategoryDetailController(id),
          builder: (controller) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CustomAppBar(
                    title: controller.categoryDetailModel == null
                        ? CATEGORY_DETAIL[LANGUAGE_TYPE]
                        : controller.categoryDetailModel!.data!.name,
                    isArrow: true,
                    isAction: false),
                Expanded(
                    child: controller.isLoading
                        ? Center(
                            child: CircularProgressIndicator(
                              color: themeColor,
                            ),
                          )
                        : Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 10),
                            child: SingleChildScrollView(
                              controller: controller.scrollController,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  /// Des

                                  SizedBox(
                                    height: 10,
                                  ),
                                  Padding(
                                    padding:
                                        EdgeInsets.symmetric(horizontal: 10),
                                    child: boldText(
                                        text:
                                            "${controller.categoryDetailModel!.data!.name} Package",
                                        size: 20),
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),

                                  /// Grid View
                                  Container(
                                    color: themeSecondaryColor,
                                    child: Padding(
                                      padding: const EdgeInsets.all(5.0),
                                      child: GridView.builder(
                                          physics:
                                              NeverScrollableScrollPhysics(),
                                          padding: EdgeInsets.zero,
                                          shrinkWrap: true,
                                          gridDelegate:
                                              const SliverGridDelegateWithFixedCrossAxisCount(
                                            crossAxisCount: 2,
                                            crossAxisSpacing: 10.0,
                                            childAspectRatio: 0.7,
                                            mainAxisSpacing: 10.0,
                                          ),
                                          itemCount:
                                              controller.packageDetail!.length,
                                          itemBuilder: (context, index) {
                                            var data = controller
                                                .packageDetail![index];
                                            return Container(
                                              decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(15),
                                                image: const DecorationImage(
                                                  fit: BoxFit.fill,
                                                  image: AssetImage(
                                                    AppImages.defaultImage,
                                                  ),
                                                ),
                                              ),
                                              child: Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .only(
                                                          left: 8,
                                                          right: 8,
                                                          top: 12,
                                                          bottom: 3,
                                                        ),
                                                        child: Text(
                                                          data.name!,
                                                          maxLines: 2,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          style:
                                                              const TextStyle(
                                                            fontFamily: "Bold",
                                                            color: whiteColor,
                                                          ),
                                                        ),
                                                      ),
                                                      Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .only(
                                                                left: 8,
                                                                right: 8),
                                                        child: Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceBetween,
                                                          children: [
                                                            Row(
                                                              children: [
                                                                Text(
                                                                  "$CURRENCY" +
                                                                      data.mrp
                                                                          .toString() +
                                                                      ".00",
                                                                  style:
                                                                      const TextStyle(
                                                                    fontFamily:
                                                                        "Regular",
                                                                    color:
                                                                        whiteColor,
                                                                    fontSize:
                                                                        11,
                                                                    decoration:
                                                                        TextDecoration
                                                                            .lineThrough,
                                                                  ),
                                                                ),
                                                                const Text(
                                                                  " / ",
                                                                  style:
                                                                      TextStyle(
                                                                    color:
                                                                        whiteColor,
                                                                  ),
                                                                ),
                                                                Text(
                                                                  "$CURRENCY" +
                                                                      data.price
                                                                          .toString() +
                                                                      ".00",
                                                                  style:
                                                                      const TextStyle(
                                                                    fontFamily:
                                                                        "Regular",
                                                                    color:
                                                                        whiteColor,
                                                                    fontSize:
                                                                        11,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                            Container(
                                                              height: 25,
                                                              width: 35,
                                                              decoration:
                                                                  const BoxDecoration(
                                                                image:
                                                                    DecorationImage(
                                                                  image:
                                                                      AssetImage(
                                                                    "assets/popular_package/discount.png",
                                                                  ),
                                                                ),
                                                              ),
                                                              child: Center(
                                                                child: Text(
                                                                  "$CURRENCY${data.discount}",
                                                                  style:
                                                                      TextStyle(
                                                                    color:
                                                                        whiteColor,
                                                                    fontSize:
                                                                        10,
                                                                    fontFamily:
                                                                        "Regular",
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .only(
                                                                left: 8,
                                                                right: 8,
                                                                bottom: 1),
                                                        child: Text(
                                                          "Include : " +
                                                              '${data.noOfParameter}' +
                                                              " Parameteres",
                                                          style:
                                                              const TextStyle(
                                                            fontSize: 12,
                                                            fontFamily:
                                                                "Regular",
                                                            color: subTextColor,
                                                          ),
                                                        ),
                                                      ),
                                                      const Divider(
                                                          color: whiteColor),
                                                      ...(data.parameterList)!
                                                          .map((e) {
                                                        return Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                  .only(
                                                                  left: 8,
                                                                  right: 8,
                                                                  top: 1,
                                                                  bottom: 1),
                                                          child: Row(
                                                            children: [
                                                              const Icon(
                                                                Icons.done,
                                                                color: redColor,
                                                                size: 10,
                                                              ),
                                                              const SizedBox(
                                                                width: 10,
                                                              ),
                                                              Flexible(
                                                                child: Text(
                                                                  e,
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                  maxLines: 1,
                                                                  style:
                                                                      const TextStyle(
                                                                    color:
                                                                        whiteColor,
                                                                    fontSize:
                                                                        10,
                                                                    fontFamily:
                                                                        "Regular",
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        );
                                                      }).toList(),
                                                    ],
                                                  ),
                                                  Center(
                                                    child: Padding(
                                                      padding:
                                                          const EdgeInsets.only(
                                                              bottom: 5),
                                                      child: ElevatedButton(
                                                        onPressed: () {
                                                          int type = data.type!;
                                                          if (type == 1) {
                                                            Get.to(() =>
                                                                PackageDetailScreen(
                                                                    data.id!));
                                                          } else if (type ==
                                                              2) {
                                                            Get.to(() =>
                                                                ParameterDetailScreen(
                                                                    data.id!));
                                                          } else if (type ==
                                                              3) {
                                                            Get.to(() =>
                                                                ProfileDetailScreen(
                                                                    data.id!));
                                                          }
                                                        },
                                                        style: ElevatedButton
                                                            .styleFrom(
                                                          backgroundColor:
                                                              whiteColor,
                                                          shape:
                                                              RoundedRectangleBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        50),
                                                          ),
                                                          maximumSize:
                                                              const Size(
                                                                  130, 40),
                                                        ),
                                                        child: Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceAround,
                                                          children: [
                                                            Text(
                                                              View_Detail[
                                                                  LANGUAGE_TYPE],
                                                              style:
                                                                  const TextStyle(
                                                                color:
                                                                    blackColor,
                                                                fontFamily:
                                                                    "Regular",
                                                              ),
                                                            ),
                                                            // SizedBox(width: 10,),
                                                            const Icon(
                                                              Icons
                                                                  .arrow_forward,
                                                              color: blackColor,
                                                              size: 16,
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            );
                                          }),
                                    ),
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Padding(
                                    padding:
                                        EdgeInsets.symmetric(horizontal: 10),
                                    child: boldText(
                                        text:
                                            "${controller.categoryDetailModel!.data!.name} Description",
                                        size: 20),
                                  ),
                                  Container(
                                    width: double.infinity,
                                    margin: const EdgeInsets.symmetric(
                                        horizontal: 5, vertical: 10),
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 15, vertical: 15),
                                    decoration: BoxDecoration(
                                        color: whiteColor,
                                        borderRadius:
                                            BorderRadius.circular(15)),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        boldText(
                                            text:
                                                "${controller.categoryDetailModel!.data!.name} Test",
                                            size: 18),
                                        // const SizedBox(
                                        //   height: 10,
                                        // ),
                                        Html(
                                          data: controller.categoryDetailModel!
                                              .data!.description,
                                          style: {
                                            "p": Style(
                                              color: subTextColor,
                                              fontFamily: "Regular",
                                            ),
                                          },
                                        ),
                                        // regularText(
                                        //     text:
                                        //         'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which dont look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isnt anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.')
                                      ],
                                    ),
                                  ),

                                  // if (controller.isListLoading &&
                                  //     !controller.isLoading)
                                  //   Padding(
                                  //     padding: const EdgeInsets.only(
                                  //         top: 10.0, bottom: 10),
                                  //     child: Center(
                                  //       child: CircularProgressIndicator(
                                  //         color: themeColor,
                                  //       ),
                                  //     ),
                                  //   )
                                ],
                              ),
                            ),
                          ))
              ],
            );
          }),
    );
  }
}
