import 'package:flutter/material.dart';
import 'package:flutter_share/flutter_share.dart';
import 'package:leboratory/Models/packageDetails.dart';
import 'package:leboratory/utils/colors.dart';
import 'package:leboratory/utils/strings.dart';

loginText(welcome_back) {
  return Text(
    welcome_back,
    style: const TextStyle(
      color: whiteColor,
      fontFamily: "Bold",
      fontSize: 28,
    ),
  );
}

loginSubText(login_continue) {
  return Text(
    login_continue,
    style: const TextStyle(
      color: subTextColor,
      fontSize: 16,
      fontFamily: "Regular",
    ),
  );
}

textFildHeader(email_addres, double width) {
  return Text(
    email_addres,
    style: TextStyle(
      fontSize: width > 360 ? 16 : 14,
      color: subTextColor,
      fontFamily: "Regular",
    ),
  );
}

customeTextFild(
    String? Function(String? email) validateEmail,
    TextEditingController emailController,
    double width,
    enter_email_addres,
    textInputType) {
  return TextFormField(
    validator: validateEmail,
    controller: emailController,
    style: TextStyle(
      fontWeight: FontWeight.w400,
      fontSize: width > 360 ? 16 : 14,
      color: whiteColor,
      fontFamily: "Regular",
    ),
    keyboardType: textInputType,
    cursorColor: whiteColor,
    decoration: InputDecoration(
      border: const UnderlineInputBorder(
        borderSide: BorderSide(color: whiteColor),
      ),
      enabledBorder: const UnderlineInputBorder(
        borderSide: BorderSide(color: subTextColor),
      ),
      focusedBorder: const UnderlineInputBorder(
        borderSide: BorderSide(color: whiteColor),
      ),
      focusColor: whiteColor,
      fillColor: whiteColor,
      hintText: enter_email_addres,
      hintStyle: const TextStyle(
        color: subTextColor,
        fontSize: 14,
        // fontWeight: FontWeight.w300,
        fontFamily: "Regular",
        // letterSpacing: 2.0,
      ),
    ),
  );
}

customePasswordTextFild(
    String? Function(String? email) validateName,
    TextEditingController passwordController,
    double width,
    enter_password,
    bool obscureText,
    void Function() toggle) {
  return TextFormField(
    validator: validateName,
    controller: passwordController,
    obscureText: obscureText,
    style: TextStyle(
      fontWeight: FontWeight.w400,
      fontSize: width > 360 ? 16 : 14,
      color: whiteColor,
      fontFamily: "Regular",
    ),
    cursorColor: whiteColor,
    decoration: InputDecoration(
      border: const UnderlineInputBorder(
        borderSide: BorderSide(color: whiteColor),
      ),
      enabledBorder: const UnderlineInputBorder(
        borderSide: BorderSide(color: subTextColor),
      ),
      focusedBorder: const UnderlineInputBorder(
        borderSide: BorderSide(color: whiteColor),
      ),
      suffixIcon: InkWell(
        onTap: toggle,
        child: Icon(
          obscureText ? Icons.visibility : Icons.visibility_off,
          color: whiteColor,
        ),
      ),
      focusColor: whiteColor,
      fillColor: whiteColor,
      hintText: enter_password,
      hintStyle: const TextStyle(
        color: subTextColor,
        fontSize: 14,
        // fontWeight: FontWeight.w300,
        // letterSpacing: 2.0,
        fontFamily: "Regular",
      ),
    ),
  );
}

customeElevatedButton(double width, login, {required VoidCallback callback}) {
  return ElevatedButton(
    style: ElevatedButton.styleFrom(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      backgroundColor: themeColor,
      // onPrimary: themeColor,
      minimumSize: Size(width, 50),
    ),
    onPressed: () => callback(),
    child: Text(
      login,
      style: const TextStyle(
        color: whiteColor,
        fontFamily: "Bold",
        fontSize: 20,
      ),
    ),
  );
}

customeElevatedButtonSecond(double width, login,
    {required VoidCallback callback}) {
  return ElevatedButton(
    style: ElevatedButton.styleFrom(
      padding: EdgeInsets.symmetric(vertical: 10, horizontal: 8),
      backgroundColor: themeColor,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      // onPrimary: themeColor,
      minimumSize: Size(width, 50),
    ),
    onPressed: () => callback(),
    child: Text(
      login,
      maxLines: 2,
      textAlign: TextAlign.center,
      style: const TextStyle(
        color: whiteColor,
        fontFamily: "Bold",
        fontSize: 20,
      ),
    ),
  );
}

customeElevatedButtonOutLine(double width, login,
    {required VoidCallback callback,
    Color color = whiteColor,
    Color? textColor,
    Color? borderColor}) {
  return ElevatedButton(
    style: ElevatedButton.styleFrom(
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
          side: BorderSide(
              color: borderColor != null ? borderColor : themeColor, width: 2)),
      backgroundColor: color,
      disabledForegroundColor: color.withOpacity(0.38),
      disabledBackgroundColor: color.withOpacity(0.12),
      // onPrimary: themeColor,
      minimumSize: Size(width, 50),
    ),
    onPressed: () => callback(),
    child: Text(
      login,
      style: TextStyle(
        color: textColor != null ? textColor : themeColor,
        fontFamily: "Bold",
        fontSize: 20,
      ),
    ),
  );
}

customeAppBar(String title) {
  return AppBar(
    backgroundColor: themeColor,
    title: Text(title),
  );
}

customeGrid(String gridImage1, paramter_included, String? paramterIncluded) {
  return Container(
    height: 80,
    width: 80,
    decoration: BoxDecoration(
      color: whiteColor,
      borderRadius: BorderRadius.circular(15),
    ),
    child: Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Image.asset(
            gridImage1,
            height: 20,
            width: 20,
            fit: BoxFit.fill,
          ),
          Text(
            paramter_included,
            style: const TextStyle(
              color: blackColor,
              fontFamily: "Regular",
              fontSize: 8,
            ),
            textAlign: TextAlign.center,
          ),
          Text(
            paramterIncluded.toString(),
            style: const TextStyle(
              color: blackColor,
              fontFamily: "Regular",
              fontSize: 10,
            ),
          ),
        ],
      ),
    ),
  );
}

Future<void> shareApp(Data? data) async {
  await FlutterShare.share(
      title: data!.name,
      text: data.name,
      linkUrl: data.shortDesc,
      chooserTitle: 'Example Chooser Title');
}

///----- mahi -----
semiBoldText(
    {dynamic text,
    double? size,
    Color? color,
    TextOverflow? textOverFlow,
    TextAlign? alignment,
    TextDecoration? decoration,
    int? maxLines}) {
  return Container(
      child: Text(
    text is Map ? text[LANGUAGE_TYPE] : text,
    style: TextStyle(
        fontSize: size,
        color: color,
        // letterSpacing: .5,
        fontWeight: FontWeight.w500,
        fontFamily: "Semibold",
        decoration: decoration ?? TextDecoration.none),
    textAlign: alignment ?? TextAlign.start,
    overflow: textOverFlow,
    maxLines: maxLines,
  ));
}

boldText(
    {dynamic text,
    double? size,
    Color? color,
    TextOverflow? textOverFlow,
    TextAlign? alignment,
    TextDecoration? decoration,
    int? maxLines}) {
  return Container(
      child: Text(
    text is Map ? text[LANGUAGE_TYPE] : text,
    style: TextStyle(
        fontSize: size,
        color: color,
        // letterSpacing: .5,
        fontWeight: FontWeight.w500,
        fontFamily: "Bold",
        decoration: decoration ?? TextDecoration.none),
    textAlign: alignment ?? TextAlign.start,
    overflow: textOverFlow,
    maxLines: maxLines,
  ));
}

editCustomTextField(String? Function(String? email) validateEmail,
    TextEditingController Controller, double width, hintText,
    {TextInputType? textInputType,
    int? maxLen,
    VoidCallback? onTap,
    bool? readonly}) {
  return TextFormField(
    onTap: onTap,
    maxLength: maxLen,
    readOnly: readonly ?? false,
    keyboardType: textInputType ?? TextInputType.text,
    validator: validateEmail,
    controller: Controller,
    style: TextStyle(
      fontWeight: FontWeight.w400,
      fontSize: width > 360 ? 16 : 14,
      color: blackColor,
      fontFamily: "Regular",
    ),
    cursorColor: blackColor,
    decoration: InputDecoration(
      border: const UnderlineInputBorder(
        borderSide: BorderSide(color: blackColor),
      ),
      enabledBorder: const UnderlineInputBorder(
        borderSide: BorderSide(color: subTextColor),
      ),
      focusedBorder: const UnderlineInputBorder(
        borderSide: BorderSide(color: blackColor),
      ),
      focusColor: blackColor,
      fillColor: blackColor,
      counterText: '',
      // hintText: hintText,
      hintStyle: const TextStyle(
        color: subTextColor,
        fontSize: 14,
        // fontWeight: FontWeight.w300,
        fontFamily: "Regular",
        // letterSpacing: 2.0,
      ),
    ),
  );
}

dboTextField(String? Function(String? email) validate,
    TextEditingController controller, double width,
    {VoidCallback? onTap, Function()? onchange, String? text}) {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      TextFormField(
        onChanged: (value) => onchange,
        readOnly: true,
        onTap: onTap,
        controller: controller,
        validator: validate,
        style: TextStyle(
          fontWeight: FontWeight.w400,
          fontSize: width > 360 ? 16 : 14,
          color: blackColor,
          fontFamily: "Regular",
        ),
        cursorColor: blackColor,
        decoration: InputDecoration(
          border: const UnderlineInputBorder(
            borderSide: BorderSide(color: blackColor),
          ),
          enabledBorder: const UnderlineInputBorder(
            borderSide: BorderSide(color: subTextColor),
          ),
          focusedBorder: const UnderlineInputBorder(
            borderSide: BorderSide(color: blackColor),
          ),
          focusColor: blackColor,
          fillColor: blackColor,
          counterText: '',
          hintText: 'Date Of Birth*',
          suffixIconConstraints:
              const BoxConstraints(maxHeight: 24, maxWidth: 24),
          suffixIcon: Image.asset(
            'assets/add_member/date.png',
            height: 25,
            width: 25,
          ),
          // suffix: InkWell(
          //     onTap: onTap,
          //     child: Image.asset('assets/add_member/date.png',height: 20,)),
          hintStyle: const TextStyle(
            color: blackColor,
            fontSize: 14,
            fontFamily: "Regular",
            // letterSpacing: 2.0,
          ),
        ),
      ),
      text!.isEmpty
          ? Container()
          : SizedBox(
              height: 20,
            ),
      Text(
        "${text}",
        style:
            TextStyle(color: Colors.black, fontFamily: "Regular", fontSize: 15),
      ),
    ],
  );
}

selectDateField(String? Function(String? date) validate,
    TextEditingController controller, double width,
    {VoidCallback? onTap}) {
  return ClipRRect(
    borderRadius: BorderRadius.circular(10),
    child: TextFormField(
      controller: controller,
      readOnly: true,
      onTap: onTap,
      validator: validate,
      style: TextStyle(
        fontWeight: FontWeight.w400,
        fontSize: width > 360 ? 16 : 14,
        color: blackColor,
        fontFamily: "Regular",
      ),
      cursorColor: blackColor,
      decoration: InputDecoration(
        border: InputBorder.none,
        enabledBorder: InputBorder.none,
        focusedBorder: InputBorder.none,
        focusColor: blackColor,
        fillColor: themeSecondaryColor,
        filled: true,
        counterText: '',
        hintText: 'Select Date',
        suffixIconConstraints:
            const BoxConstraints(maxHeight: 24, maxWidth: 24),
        suffixIcon: Padding(
          padding: const EdgeInsets.only(right: 5),
          child: Image.asset(
            'assets/add_member/date.png',
            color: themeColor,
          ),
        ),
        hintStyle: const TextStyle(
          color: blackColor,
          fontSize: 14,
          fontFamily: "Regular",
          // letterSpacing: 2.0,
        ),
      ),
    ),
  );
}

selectTimeField(String? Function(String? date) validate,
    TextEditingController controller, double width,
    {VoidCallback? onTap}) {
  return ClipRRect(
    borderRadius: BorderRadius.circular(10),
    child: TextFormField(
      controller: controller,
      readOnly: true,
      onTap: onTap,
      validator: validate,
      style: TextStyle(
        fontWeight: FontWeight.w400,
        fontSize: width > 360 ? 16 : 14,
        color: blackColor,
        fontFamily: "Regular",
      ),
      cursorColor: blackColor,
      decoration: InputDecoration(
        border: InputBorder.none,
        enabledBorder: InputBorder.none,
        focusedBorder: InputBorder.none,
        focusColor: blackColor,
        fillColor: themeSecondaryColor,
        filled: true,
        counterText: '',
        hintText: 'Select Time',
        suffixIconConstraints:
            const BoxConstraints(maxHeight: 24, maxWidth: 24),
        suffixIcon: Padding(
          padding: const EdgeInsets.only(right: 5),
          child: Image.asset(
            'assets/cart/time.png',
            color: themeColor,
          ),
        ),
        hintStyle: const TextStyle(
          color: blackColor,
          fontSize: 14,
          fontFamily: "Regular",
          // letterSpacing: 2.0,
        ),
      ),
    ),
  );
}

regularText(
    {dynamic text,
    double? size,
    Color? color,
    TextOverflow? textOverFlow,
    TextAlign? alignment,
    TextDecoration? decoration,
    int? maxLines}) {
  return Container(
      child: Text(
    text is Map ? text[LANGUAGE_TYPE] : text,
    style: TextStyle(
        fontSize: size,
        color: color,
        // letterSpacing: .5,
        fontWeight: FontWeight.w500,
        fontFamily: "Regular",
        decoration: decoration ?? TextDecoration.none),
    textAlign: alignment ?? TextAlign.start,
    overflow: textOverFlow,
    maxLines: maxLines,
  ));
}

regularTextSecond(
    {dynamic text,
    double? size,
    Color? color,
    TextOverflow? textOverFlow,
    TextAlign? alignment,
    TextDecoration? decoration,
    int? maxLines}) {
  return Container(
      alignment: Alignment.center,
      child: Text(
        text is Map ? text[LANGUAGE_TYPE] : text,
        style: TextStyle(
            fontSize: size,
            color: color,
            // letterSpacing: .5,
            fontFamily: "Bold",
            decoration: decoration ?? TextDecoration.none),
        textAlign: alignment ?? TextAlign.start,
        overflow: textOverFlow,
        maxLines: maxLines,
      ));
}

regularTextThird(
    {dynamic text,
    double? size,
    Color? color,
    TextOverflow? textOverFlow,
    TextAlign? alignment,
    TextDecoration? decoration,
    int? maxLines}) {
  return Container(
      child: Text(
    text is Map ? text[LANGUAGE_TYPE] : text,
    style: TextStyle(
        fontSize: size,
        color: color,
        // letterSpacing: .5,
        fontWeight: FontWeight.w500,
        fontFamily: "Regular",
        decoration: decoration ?? TextDecoration.none),
    textAlign: alignment ?? TextAlign.center,
    overflow: textOverFlow,
    maxLines: maxLines,
  ));
}
