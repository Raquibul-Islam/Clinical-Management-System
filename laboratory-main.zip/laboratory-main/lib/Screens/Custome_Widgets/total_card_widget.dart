import 'package:flutter/material.dart';
import 'package:leboratory/Screens/Custome_Widgets/custome_widget.dart';
import 'package:leboratory/main.dart';
import 'package:leboratory/utils/strings.dart';
import '../../utils/AllText.dart';
import '../../utils/colors.dart';

class TotalCard extends StatelessWidget {
  final String subTotal;
  final String total;
  final String tax;
  final double width;
  final int saving;
  final bool isShowSavingAmount;

  const TotalCard({
    Key? key,
    required this.width,
    required this.subTotal,
    required this.total,
    required this.tax,
    this.isShowSavingAmount = false,
    this.saving = 0,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(top: 8, right: 8, left: 8),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      width: width,
      decoration: BoxDecoration(
        color: whiteColor,
        borderRadius: BorderRadius.circular(15),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              boldText(text: SUBTOTAL[LANGUAGE_TYPE], color: blackColor),
              regularText(text: subTotal, color: blackColor),
            ],
          ),
          const SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              boldText(text: Txt[LANGUAGE_TYPE], color: blackColor),
              regularText(text: tax, color: blackColor),
            ],
          ),
          const Divider(
            color: subTextColor,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              boldText(text: TOTAL[LANGUAGE_TYPE], size: 16, color: blackColor),
              boldText(text: total, size: 16, color: blackColor),
            ],
          ),
          if (isShowSavingAmount)
            const SizedBox(
              height: 15,
            ),
          if (isShowSavingAmount)
            regularText(
                text: '${SAVING_DES[LANGUAGE_TYPE]} $CURRENCY${saving}',
                color: const Color(0xff088018),
                size: 12),
        ],
      ),
    );
  }
}
