import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:leboratory/Screens/Custome_Widgets/custome_widget.dart';
import 'package:leboratory/controller/cart_detail_controller.dart';
import 'package:leboratory/main.dart';
import 'package:leboratory/utils/strings.dart';

import '../../Models/cart_list_model.dart';
import '../../Models/local_package_detail_model.dart';
import '../../utils/AllText.dart';
import '../../utils/App_Images.dart';
import '../../utils/colors.dart';

class PersonPackageDetailCardView extends StatelessWidget {
  final String name;
  final int cardItem;
  final String detail;
  final bool isSimple;
  final List testdatum;
  final int memberId;

  const PersonPackageDetailCardView({
    Key? key,
    required this.width,
    required this.name,
    required this.cardItem,
    required this.detail,
    required this.testdatum,
    this.isSimple = false, required this.memberId,
  }) : super(key: key);

  final double width;

  @override
  Widget build(BuildContext context) {
    return Container(
      // margin:const EdgeInsets.all(8),
      margin: const EdgeInsets.only(top: 8, right: 8, left: 8),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      width: width,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
        image: const DecorationImage(
          fit: BoxFit.fill,
          image: AssetImage(
            AppImages.defaultImage,
          ),
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            RichText(
              text: TextSpan(
                text: name,
                style: const TextStyle(color: whiteColor, fontFamily: "Bold"),
                children: <TextSpan>[
                  TextSpan(
                    text: detail,
                    style: const TextStyle(
                      color: subTextColor,
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                      fontFamily: "Regular",
                    ),
                  ),
                ],
              ),
            ),
            isSimple?
            Container(
              child: ListView.builder(
                  physics: const NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  padding: EdgeInsets.zero,
                  itemCount: testdatum.length,
                  itemBuilder: (context, index) {
                    var data = testdatum[index];
                    return PackageDetailSimple(
                      name: data.testName!,
                      parameters: data.parameter.toString(),
                      mrp: data.mrp.toString(),
                      price: data.price.toString(),
                      discount: '10S', onTap: () {  },
                    );
                  }),
            )
                :
            Container(
              child: ListView.builder(
                  physics: const NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  padding: EdgeInsets.zero,
                  itemCount: testdatum.length,
                  itemBuilder: (context, index) {
                    var data = testdatum[index];
                    return PackageDetail(
                      name: data.testName!,
                      parameters: data.parameter.toString(),
                      mrp: data.mrp.toString(),
                      price: data.price.toString(),
                      discount: '10S',
                      onTap: () async{
                        Get.find<CartDetailController>().deletePackage(data,memberId);
                        // var delete = Get.find<CartDetailController>().deletePackageFromCart(packageType: data.packageType,packageId: data.packageId,userId: data.userId);
                      },
                    );
                  }),
            ),
            // const PackageDetail(),
            // const PackageDetail(),
          ],
        ),
      ),
    );
  }
}

class PackageDetail extends StatelessWidget {
  const PackageDetail({
    Key? key,required this.name,required this.parameters, required this.mrp,required this.price,required this.discount,required this.onTap,
  }) : super(key: key);

  final String name;
  final String parameters;
  final String mrp;
  final String price;
  final String discount;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.only(top: 5),
      child: Column(
        children: [
          const Divider(
            color: whiteColor,
            thickness: 1,
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    boldText(text: '$name',color: whiteColor),
                    const SizedBox(
                      height: 5,
                    ),
                    regularText(text:  'Parameters Included : $parameters',size: 12,color: subTextColor),
                    const SizedBox(
                      height: 10,
                    ),
                    RichText(
                      text:  TextSpan(
                        text: '$CURRENCY${mrp}.00',
                        style: TextStyle(
                          decoration: TextDecoration.lineThrough,
                          fontSize: 14,
                          color: themeColor,
                          fontWeight: FontWeight.w500,
                          fontFamily: "Regular",
                        ),
                        children: <TextSpan>[
                          TextSpan(
                            text: '/ $CURRENCY${price}.00',
                            style: TextStyle(
                              // fontSize: size,
                                color: whiteColor,
                                fontSize: 14,
                                // letterSpacing: .5,
                                fontWeight: FontWeight.w500,
                                fontFamily: "Regular",
                                decoration: TextDecoration.none),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
              Container(
                child: Column(
                  // mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // Container(
                    //   padding: const EdgeInsets.symmetric(
                    //       horizontal: 5, vertical: 2),
                    //   color: const Color(0xff088018),
                    //   child:
                    //   regularText(text: '${SAVE[LANGUAGE_TYPE]} ${discount}%',color: whiteColor,size: 12),
                    // ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 5, vertical: 2),
                      color: Colors.transparent,
                      child: SizedBox(height: 12,),
                    ),
                    const SizedBox(
                      height: 25,
                    ),
                    InkWell(
                        onTap: onTap,
                        child: Image.asset(
                          'assets/cart/delete.png',
                          height: 20,
                        ))
                  ],
                ),
              )
            ],
          )
        ],
      ),
    );
  }
}

class PackageDetailSimple extends StatelessWidget {
  const PackageDetailSimple({
    Key? key,required this.name,required this.parameters,required this.mrp,required this.price,required this.discount,required this.onTap,
  }) : super(key: key);

  final String name;
  final String parameters;
  final String mrp;
  final String price;
  final String discount;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.only(top: 5),
      child: Column(
        children: [
          const Divider(
            color: whiteColor,
            thickness: 1,
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    boldText(text: '$name',color: whiteColor),
                    const SizedBox(
                      height: 5,
                    ),
                    regularText(text: '${PARAMETERS_INCLUDED[LANGUAGE_TYPE]} $parameters',color: subTextColor,size: 14),
                  ],
                ),
              ),
              regularText(text: '$CURRENCY$price.00',color: whiteColor)
            ],
          )
        ],
      ),
    );
  }
}