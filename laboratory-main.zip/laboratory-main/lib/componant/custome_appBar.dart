import 'package:flutter/material.dart';

import '../Screens/Custome_Widgets/custome_widget.dart';
import '../utils/colors.dart';

class CustomAppBar extends StatelessWidget {
  String title;
  bool isArrow, isAction, isCustomWidget;
  Widget? widget;

  // bool isOnPress;
  CustomAppBar({
    required this.title,
    required this.isArrow,
    required this.isAction,
    this.isCustomWidget = false,
    this.widget,
  });

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: themeColor,
      title: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          isArrow == true
              ? GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Container(child: Icon(Icons.arrow_back_ios)))
              : Container(),
          Container(
            margin: EdgeInsets.only(left: 10),
            child: boldText(text: title),
          ),
        ],
      ),
      automaticallyImplyLeading: false,
      actions: [
        isAction == true
            ? isCustomWidget == true
                ? widget!
                : Container(
                    margin: const EdgeInsets.only(right: 5),
                    child: Image.asset(
                      'assets/profile/filter.png',
                      scale: 3.5,
                    ))
            : Container(),
      ],
    );
  }
}
